"""
Refund API
   - validate membership id
   - validate category
      - check if category falls under `sales`
        - check if business_trigger falls under `CATEGORY_SALES_TRIGGERS`
            - get `TransactionEarnSale` record
            - set property_net_value as `self.value` for lms
   - request lms for refund with given info
"""
from requests import codes, RequestException

from api.lms_v1.refund_api.validation import refund_validator
from app_configurations.settings import LMS_APIS_LOG_PATH
from common.callbacks_base_resource import BasePostResource
from common.constants import AED, MISSING_PARAMETER_ERR_CODE, LMS_SOURCE
from models.aldar_app.category import Category
from models.aldar_app.concept_id_mapping import ConceptIdMapping
from models.aldar_app.transaction_earn_sale import TransactionEarnSale
from models.aldar_app.user import User
from models.entertainer_web.outlet import Outlet
from utils.lms_manager import lms_manager
from utils.translation_manager import TranslationManager


class RefundApi(BasePostResource):
    request_parser = refund_validator
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=LMS_APIS_LOG_PATH,
            file_path='lms_refund_api/lms_refund_api.log',
        ),
        'name': 'lms_refund_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.membership_id = self.request_args.get('membership_number')
        self.locale = self.request_args.get('language')
        self.business_category = self.request_args.get('business_category')
        self.business_trigger = self.request_args.get('business_trigger')
        self.transaction_id = self.request_args.get('transaction_id')
        self.refund_points_mode = self.request_args.get('refund_points_mode')
        self.value = self.request_args.get('value')
        self.concept_id = self.request_args.get('concept_id')
        self.sales_order_id = self.request_args.get('sales_order_id')
        self.external_user_id = self.request_args.get('external_user_id')
        self.external_user_name = self.request_args.get('external_user_name')
        self.description = self.request_args.get('description')
        self.currency = self.request_args.get('currency', AED)

    def initialize_local_veriables(self):
        """
        Initializes local variables
        - concat concept_id and transaction id and set as transaction_id (to avoid refund failure)
        """
        self.transaction_id = '{}#{}'.format(self.concept_id, self.transaction_id)
        self.user = None
        self.category = None
        self.property_net_value = None
        self.concept_name = ''
        self.response_data = {}

    def validate_membership_id(self):
        self.user = User.get_active_by_membership_id(self.membership_id)
        if not self.user:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Member not found', custom_code=2)
            return
        self.lms_id = self.user.lms_membership_id

    def validate_concept_id(self):
        """
        - get lms_concept_id from concept_id_mapping table
        - verify if concept id exists in Outlets
        """
        concept_id_mapping = ConceptIdMapping.get_lms_concept_id(self.business_category, self.concept_id)
        if concept_id_mapping:
            self.concept_id = concept_id_mapping.lms_concept_id
            self.concept_name = concept_id_mapping.lms_concept_name

        outlet = Outlet.get_info_by_concept_id(self.concept_id)
        if not outlet:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Concept Id not found', custom_code=3)

    def validate_category(self):
        """
        - validate and fetch category
          - check if category falls under `sales`
            - check if business_trigger falls under `CATEGORY_SALES_TRIGGERS`
                - get `TransactionEarnSale` record
                - set property_net_value as `self.value` for lms
        - TODO: Category validation will be dealt in phase two
        """
        category = Category.get_by_business_asset(self.business_category)
        if not category:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Invalid "business_category"')

        # category -> Sales check
        if category.business_asset.lower() == Category.CATEGORY_SALES.lower():
            # checking request param business_trigger not category.business_trigger
            if self.business_trigger in Category.CATEGORY_SALES_TRIGGERS:
                if self.sales_order_id:
                    transaction = TransactionEarnSale.get_transaction_by_sales_order_id(self.sales_order_id)
                    if not transaction:
                        self.send_response_flag = True
                        self.status_code = codes.UNPROCESSABLE_ENTITY
                        self.response = self.generate_response_dict(
                            message="No earn transaction found for the sale order. Refund can't be processed",
                            custom_code=2
                        )
                        return

                    # set property net_value
                    self.property_net_value = transaction.property_net_value

                else:
                    self.send_response_flag = True
                    self.status_code = codes.UNPROCESSABLE_ENTITY
                    self.response = self.generate_response_dict(
                        message="sales_order_id: missing required parameter for business category {}".format(
                            Category.CATEGORY_SALES
                        ),
                        custom_code=MISSING_PARAMETER_ERR_CODE
                    )
                    return

    def lms_refund(self):
        """
        request lms for refund wih given info
        """
        try:
            refund_response = lms_manager.refund(
                self.lms_id,
                self.business_category,
                self.business_trigger,
                self.transaction_id,
                self.refund_points_mode,
                self.value,
                self.currency,
                self.description,
                property_net_value=self.property_net_value,
                external_user_id=self.external_user_id,
                external_user_name=self.external_user_name,
                source=LMS_SOURCE,
                concept_id=self.concept_id,
                concept_name=self.concept_name,
                user_id=self.user.id
            )
            try:
                del refund_response['member_id']
                del refund_response['email']
                del refund_response['channel_id']
            except KeyError:
                pass
            self.response_data.update(refund_response)
        except RequestException as re:
            self.send_response_flag = True
            message = 'Unable to refund {}.'.format(self.refund_points_mode)
            for error in re.response.json().get('errors', []):
                message = error.get('message', message)
                break
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message=message)
        except Exception:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict('Unable to refund {}.'.format(self.refund_points_mode))

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        if not self.response:
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.SUCCESS,
                    self.locale
                ),
                success_flag=True,
                data=self.response_data
            )
            self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables()
        self.validate_membership_id()
        if self.send_response_flag:
            return
        self.validate_concept_id()
        if self.send_response_flag:
            return
        self.validate_category()
        if self.send_response_flag:
            return
        self.lms_refund()
        self.generate_final_response()
