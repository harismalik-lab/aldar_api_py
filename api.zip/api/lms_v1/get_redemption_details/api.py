"""
Get Redemption Details API
    - Get redemption detail record from `aldar_app.transaction_burn` table by joining it with `User` by user_id
    - generate and return response
"""

from requests import codes

from api.lms_v1.get_redemption_details.validation import get_redemption_details_parser
from app_configurations.settings import LMS_APIS_LOG_PATH
from common.callbacks_base_resource import BaseGetResource
from common.constants import UPTO_TWO_DECIMALS
from models.aldar_app.transaction_burn import TransactionBurn
from utils.translation_manager import TranslationManager


class RedemptionDetails(BaseGetResource):
    request_parser = get_redemption_details_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=LMS_APIS_LOG_PATH,
            file_path='get_redemption_details/get_redemption_details_api.log',
        ),
        'name': 'get_redemption_details_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')

    def initialize_local_veriables(self, **kwargs):
        """
        Initializes local variables
        """
        self.redemption_id = kwargs['redemption_id']
        self.transaction_details = None
        self.response_data = {}

    def get_redemption_details(self):
        """
        query TransactionBurn table for redemption details based on lms_redemption_id
        """
        self.transaction_details = TransactionBurn.get_by_lms_transaction_id(self.redemption_id)
        if not self.transaction_details:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="No redemption details found against '{}' redemption id".format(self.redemption_id),
                custom_code=2
            )
            return

    def generate_final_response(self):
        """
        Generates final response
        """
        if self.transaction_details:
            self.response_data = {
                "email": self.transaction_details.email,
                "concept_id": self.transaction_details.concept_id,
                "redemption_id": self.redemption_id,
                "redemption_reference_code": self.transaction_details.lms_redemption_reference_code,
                "amount": UPTO_TWO_DECIMALS.format(self.transaction_details.amount_burned),
                "burn_rate": UPTO_TWO_DECIMALS.format(self.transaction_details.burn_rate),
                "points": self.transaction_details.points_burned,
                "redemption_mode": self.transaction_details.redemption_mode,
                "date_created": self.transaction_details.date_created.strftime('%Y-%m-%d %H:%M:%S'),
            }
        self.send_response_flag = True
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=self.response_data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables(**kwargs)
        self.get_redemption_details()
        if self.send_response_flag:
            return
        self.generate_final_response()
