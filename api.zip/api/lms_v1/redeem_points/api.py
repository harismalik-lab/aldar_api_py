"""
Redeem Points/Amount API
   - validate membership id
   - validate category
   - request lms to redeem points with given info
"""
from requests import codes, RequestException

from api.lms_v1.redeem_points.validation import redeem_points_validator
from app_configurations.settings import LMS_APIS_LOG_PATH
from common.callbacks_base_resource import BasePostResource
from common.constants import AED, LMS_SOURCE
from models.aldar_app.category import Category
from models.aldar_app.concept_id_mapping import ConceptIdMapping
from models.aldar_app.user import User
from models.entertainer_web.outlet import Outlet
from utils.lms_manager import lms_manager
from utils.translation_manager import TranslationManager


class RedeemPointsApi(BasePostResource):
    request_parser = redeem_points_validator
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=LMS_APIS_LOG_PATH,
            file_path='lms_redeem_points_api/lms_redeem_points_api.log',
        ),
        'name': 'lms_redeem_points_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.membership_id = self.request_args.get('membership_number')
        self.locale = self.request_args.get('language')
        self.business_category = self.request_args.get('business_category')
        self.business_trigger = self.request_args.get('business_trigger')
        self.transaction_id = self.request_args.get('transaction_id')
        self.concept_id = self.request_args.get('concept_id')
        self.redemption_mode = self.request_args.get('redemption_mode')
        self.value = self.request_args.get('value')
        self.external_user_id = self.request_args.get('external_user_id')
        self.external_user_name = self.request_args.get('external_user_name')
        self.description = self.request_args.get('description')

    def initialize_local_veriables(self):
        """
        Initializes local variables
        """
        self.currency = AED
        self.category = None
        self.concept_name = ''
        self.response_data = {}

    def validate_membership_id(self):
        self.user = User.get_active_by_membership_id(self.membership_id)
        if not self.user:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Member not found', custom_code=2)
            return
        self.lms_id = self.user.lms_membership_id

    def validate_concept_id(self):
        """
        - get lms_concept_id from concept_id_mapping table
        - verify if concept id exists in Outlets
        """
        concept_id_mapping = ConceptIdMapping.get_lms_concept_id(self.business_category, self.concept_id)
        if concept_id_mapping:
            self.concept_id = concept_id_mapping.lms_concept_id
            self.concept_name = concept_id_mapping.lms_concept_name

        outlet = Outlet.get_info_by_concept_id(self.concept_id)
        if not outlet:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Concept Id not found', custom_code=3)

    def validate_category(self):
        """
        - validate and fetch category
        - get user points info from lms
        - set user points
        - TODO: will be dealt in phase two
        """
        self.category = Category.get_by_business_asset(self.business_category)
        if not self.category:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Invalid "business_category"')

    def lms_redeem_points(self):
        """
        request lms to redeem points/amount wih given info
        """
        try:
            redeem_response = lms_manager.burn_points(
                lms_member_id=self.lms_id,
                business_category=self.business_category,
                business_trigger=self.business_trigger,
                transaction_id=self.transaction_id,
                concept_id=self.concept_id,
                concept_name=self.concept_name,
                redemption_mode=self.redemption_mode,
                value=self.value,
                currency=self.currency,
                description=self.description,
                external_user_id=self.external_user_id,
                external_user_name=self.external_user_name,
                source=LMS_SOURCE,
                user_id=self.user.id
            )
            self.response_data = redeem_response.get('redemption', {})
        except RequestException as re:
            self.send_response_flag = True
            message = 'Unable to redeem {}.'.format(self.redemption_mode)
            for error in re.response.json().get('errors', []):
                message = error.get('message', message)
                break
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message=message)
        except Exception:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Unable to redeem {}.'.format(self.redemption_mode))

    def generate_final_response(self):
        """
        - Add burn rate from category -> subcategory
        - remove extra keys from lms response
        Generates final response
        """
        try:
            del self.response_data['points_balance']
            del self.response_data['channel_id']
            del self.response_data['currency']
            del self.response_data['member_id']
        except KeyError:
            pass

        self.send_response_flag = True
        if not self.response:
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.SUCCESS,
                    self.locale
                ),
                success_flag=True,
                data=self.response_data
            )
            self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables()
        self.validate_membership_id()
        if self.send_response_flag:
            return
        self.validate_category()
        if self.send_response_flag:
            return
        self.validate_concept_id()
        if self.send_response_flag:
            return
        self.lms_redeem_points()
        self.generate_final_response()
