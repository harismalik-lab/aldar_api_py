"""
Redeem Points/Amount validation
"""
import re

from flask_restful import reqparse
from flask_restful.inputs import regex

from utils.custom_request_parsers import language, check_positive

redeem_points_validator = reqparse.RequestParser(bundle_errors=True)

redeem_points_validator.add_argument(
    'membership_number',
    type=str,
    required=True,
    location='json'
)
redeem_points_validator.add_argument(
    'language',
    type=language,
    default='en',
    required=False,
    location='json'
)
redeem_points_validator.add_argument(
    'business_category',
    type=str,
    required=True,
    location='json'
)
redeem_points_validator.add_argument(
    'business_trigger',
    type=str,
    required=True,
    location='json'
)
redeem_points_validator.add_argument(
    'transaction_id',
    type=str,
    required=True,
    location='json'
)
redeem_points_validator.add_argument(
    'concept_id',
    type=str,
    location='json',
    required=True
)
redeem_points_validator.add_argument(
    'redemption_mode',
    type=regex('(amount|points)', flags=re.IGNORECASE),
    required=True,
    location='json'
)
redeem_points_validator.add_argument(
    'value',
    type=check_positive,
    required=True,
    location='json'
)
redeem_points_validator.add_argument(
    'description',
    type=str,
    required=False,
    location='json'
)
redeem_points_validator.add_argument(
    'external_user_id',
    type=str,
    required=True,
    location='json'
)
redeem_points_validator.add_argument(
    'external_user_name',
    type=str,
    required=True,
    location='json'
)
redeem_points_validator.add_argument(
    'description',
    type=str,
    required=True,
    location='json'
)
