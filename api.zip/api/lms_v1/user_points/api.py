"""
Get User Points API
   - get user points by validating business category and requesting lms
"""
import math

from requests import codes, RequestException

from api.lms_v1.user_points.validation import user_points_parser
from app_configurations.settings import LMS_APIS_LOG_PATH
from common.callbacks_base_resource import BasePostResource
from common.constants import AED, UPTO_TWO_DECIMALS
from models.aldar_app.category import Category
from models.aldar_app.user import User
from utils.lms_manager import lms_manager
from utils.translation_manager import TranslationManager


class UserPointsAPI(BasePostResource):
    request_parser = user_points_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=LMS_APIS_LOG_PATH,
            file_path='get_user_points/get_user_points.log',
        ),
        'name': 'get_user_points'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.business_category = self.request_args.get('business_category')
        self.business_trigger = self.request_args.get('business_trigger')

    def initialize_local_veriables(self, **kwargs):
        """
        Initializes local variables
        """
        self.membership_id = kwargs['membership_id']
        self.category = None
        self.user_points = {}

    def validate_membership_id(self):
        user = User.get_active_by_membership_id(self.membership_id)
        if not user:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Member not found', custom_code=2)
            return
        self.lms_id = user.lms_membership_id

    def get_user_points_from_lms(self):
        """
        - validate and fetch category
        - get user points info from lms
        - set user points
        """
        self.category = Category.get_by_api_name(self.business_category)
        if not self.category:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Invalid "business_category"')
            return

        try:
            points = lms_manager.get_user_points(self.lms_id, self.business_trigger, self.business_category)
            self.user_points = {
                "available_points": points['total_available_points'],
                "amount": math.floor(points['total_available_points']/10),  # TODO
                "currency": AED,
                "minimum_redeemable_points": UPTO_TWO_DECIMALS.format(self.category.minimum_redeemable_points),
                "minimum_redeemable_amount": UPTO_TWO_DECIMALS.format(self.category.minimum_redeemable_amount)
            }
        except RequestException as re:
            self.send_response_flag = True
            message = 'Unable to get points.'
            for error in re.response.json().get('errors', []):
                message = error.get('message', message)
                break
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message=message)
        except Exception:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Unable to get points.')

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        data = self.user_points
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables(**kwargs)
        self.validate_membership_id()
        if self.send_response_flag:
            return
        self.get_user_points_from_lms()
        if self.send_response_flag:
            return
        self.generate_final_response()
