from marshmallow import Schema, fields, validate, EXCLUDE, post_load
from marshmallow.validate import ValidationError


class CommonAttributes(Schema):
    member_id = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    email = fields.Email(required=True, validate=validate.Length(min=1, max=255))
    business_category = fields.Str(required=True, validate=validate.Length(min=1, max=30))
    business_trigger = fields.Str(required=True, validate=validate.Length(min=1, max=30))
    concept_id = fields.Str(required=True, validate=validate.Length(min=1, max=30))
    concept_name = fields.Str(required=True, validate=validate.Length(min=1, max=255))
    external_transaction_id = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    gross_total_amount = fields.Float(required=True, validate=validate.Range(min=0))
    net_amount = fields.Float(required=True, validate=validate.Range(min=0))
    amount_paid_using_points = fields.Float(required=True, validate=validate.Range(min=0))
    paid_amount = fields.Float(required=True, validate=validate.Range(min=0))
    currency = fields.Str(required=True, validate=validate.Length(min=1, max=10))
    redemption_reference = fields.Str(required=True)
    charge_id = fields.Str(required=True, validate=validate.Length(min=1, max=30))
    description = fields.Str(required=True, validate=validate.Length(min=1, max=255))
    external_user_id = fields.Str(required=True, validate=validate.Length(min=1, max=255))
    external_user_name = fields.Str(required=True, validate=validate.Length(min=1, max=255))
    transaction_datetime = fields.DateTime(required=True, format='%Y-%m-%d %H:%M:%S')

    class Meta:
        unknown = EXCLUDE

    @post_load
    def post_process(self, data, **kwargs):
        if data['amount_paid_using_points'] > 0 and not data['redemption_reference']:
            raise ValidationError({"redemption_reference": ["redemption_reference can not have empty value when "
                                                            "amount_paid_using_points is greater then zero."]})
        data['transaction_datetime'] = data['transaction_datetime'].strftime('%Y-%m-%d %H:%M:%S')
        return data


class HospitalitySchema(CommonAttributes):
    hotel_id = fields.Str(required=True, validate=validate.Length(min=1, max=255))
    hotel_name = fields.Str(required=True, validate=validate.Length(min=1, max=255))
    outlet_id = fields.Str(required=True, validate=validate.Length(min=1, max=30))
    outlet_name = fields.Str(required=True, validate=validate.Length(min=1, max=255))


class SalesSchema(CommonAttributes):
    community_id = fields.Str(required=True, validate=validate.Length(min=1, max=30))
    community_name = fields.Str(required=True, validate=validate.Length(min=1, max=255))
    sales_order_id = fields.Str(required=True, validate=validate.Length(min=1, max=255))
    party_id = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    unit_id = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    property_type = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    number_of_instalments = fields.Int(required=True)
    property_gross_value = fields.Float(required=True)
    property_net_value = fields.Float(required=True)
    order_date = fields.Date(required=True, format='%Y-%m-%d')

    @post_load
    def post_process(self, data, **kwargs):
        super(SalesSchema, self).post_process(data, **kwargs)
        data['order_date'] = data['order_date'].strftime('%Y-%m-%d')
        return data


class SalesInstalmentPaymentsSchema(SalesSchema):
    instalment_number = fields.Int(required=True)
    instalment_due_date = fields.Date(required=True, format='%Y-%m-%d')
    is_handover_payment = fields.Boolean(required=True)

    @post_load
    def post_process(self, data, **kwargs):
        super(SalesInstalmentPaymentsSchema, self).post_process(data, **kwargs)
        data['instalment_due_date'] = data['instalment_due_date'].strftime('%Y-%m-%d')
        data['is_handover_payment'] = 1 if data['is_handover_payment'] else 0
        return data


class MaintenanceInstalmentPaymentsSchema(CommonAttributes):
    community_id = fields.Str(required=True, validate=validate.Length(min=1, max=30))
    community_name = fields.Str(required=True, validate=validate.Length(min=1, max=255))
    unit_id = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    maintenance_contract_number = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    package_type = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    package_id = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    package_detail = fields.Str(required=True, validate=validate.Length(min=1, max=255))
    contract_period = fields.Int(required=True, validate=validate.Range(min=0))
    contract_value = fields.Float(required=True)
    number_of_instalments = fields.Int(required=True)
    instalment_number = fields.Int(required=True)

    @post_load
    def post_process(self, data, **kwargs):
        super(MaintenanceInstalmentPaymentsSchema, self).post_process(data, **kwargs)
        return data


class LeasingInstalmentPaymentsSchema(CommonAttributes):
    community_id = fields.Str(required=True, validate=validate.Length(min=1, max=30))
    community_name = fields.Str(required=True, validate=validate.Length(min=1, max=255))
    lease_contract_number = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    unit_id = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    property_type = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    lease_method = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    contract_period = fields.Int(required=True, validate=validate.Range(min=0))
    contract_value = fields.Float(required=True)
    number_of_instalments = fields.Int(required=True)
    is_renewal = fields.Boolean(required=True)
    instalment_number = fields.Int(required=True)
    instalment_due_date = fields.Date(required=True, format='%Y-%m-%d')

    @post_load
    def post_process(self, data, **kwargs):
        super(LeasingInstalmentPaymentsSchema, self).post_process(data, **kwargs)
        data['instalment_due_date'] = data['instalment_due_date'].strftime('%Y-%m-%d')
        data['is_renewal'] = 1 if data['is_renewal'] else 0
        return data


class EducationPaymentSchema(CommonAttributes):
    school_id = fields.Str(required=True, validate=validate.Length(min=1, max=30))
    school_name = fields.Str(required=True, validate=validate.Length(min=1, max=255))
    enrolment_id = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    student_id = fields.Str(required=True, validate=validate.Length(min=1, max=50))
    grade = fields.Str(required=True, validate=validate.Length(min=1, max=30))
    term_number = fields.Int(required=True, validate=validate.Range(min=0))
    is_student_enrolment_this_year = fields.Boolean(required=True)

    @post_load
    def post_process(self, data, **kwargs):
        super(EducationPaymentSchema, self).post_process(data, **kwargs)
        data['is_student_enrolment_this_year'] = 1 if data['is_student_enrolment_this_year'] else 0
        data['is_progressed_from_primary_to_secondary'] = 0
        if data['term_number'] == 1 and data['is_student_enrolment_this_year'] == 0 and data['grade'] in (
                "Year 07", "Grade 06"
        ):
            data['is_progressed_from_primary_to_secondary'] = 1
        return data
