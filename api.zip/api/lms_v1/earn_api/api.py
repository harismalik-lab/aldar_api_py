"""
Earn API
   - validate business trigger
   - validate membership id
   - validate concept id
   - validate category
   - For maintenance asset validate package id
   - validate data for earn request according to business trigger
   - request lms for earn with given info
"""
from marshmallow.validate import ValidationError
from requests import codes, RequestException

from api.lms_v1.earn_api import lms_earn_api_validation_schemas
from api.lms_v1.earn_api.validation import earn_validator
from app_configurations.settings import LMS_APIS_LOG_PATH
from common.callbacks_base_resource import BasePostResource
from common.constants import AED
from models.aldar_app.category import Category
from models.aldar_app.concept_id_mapping import ConceptIdMapping
from models.aldar_app.maintenance_packages_lookup import MaintenancePackagesLookUp
from models.aldar_app.transaction_earn_education import TransactionEarnEducation
from models.aldar_app.transaction_earn_hospitality import TransactionEarnHospitality
from models.aldar_app.transaction_earn_leasing import TransactionEarnLeasing
from models.aldar_app.transaction_earn_maintenance import TransactionEarnMaintenance
from models.aldar_app.transaction_earn_sale import TransactionEarnSale
from models.aldar_app.user import User
from models.entertainer_web.outlet import Outlet
from utils.lms_manager import lms_manager
from utils.translation_manager import TranslationManager

business_trigger_data = dict(
    hospitality_fnb=dict(
        db_model=TransactionEarnHospitality,
        schema_class=lms_earn_api_validation_schemas.HospitalitySchema),
    hospitality_spa=dict(
        db_model=TransactionEarnHospitality,
        schema_class=lms_earn_api_validation_schemas.HospitalitySchema),
    hospitality_golf_course=dict(
        db_model=TransactionEarnHospitality,
        schema_class=lms_earn_api_validation_schemas.HospitalitySchema),
    hospitality_sports_facilities=dict(
        db_model=TransactionEarnHospitality,
        schema_class=lms_earn_api_validation_schemas.HospitalitySchema),
    sales_service_charges=dict(
        db_model=TransactionEarnSale,
        schema_class=lms_earn_api_validation_schemas.SalesSchema),
    sales_instalment_payment=dict(
        db_model=TransactionEarnSale,
        schema_class=lms_earn_api_validation_schemas.SalesInstalmentPaymentsSchema),
    maintenance_instalment_payment=dict(
        db_model=TransactionEarnMaintenance,
        schema_class=lms_earn_api_validation_schemas.MaintenanceInstalmentPaymentsSchema),
    leasing_instalment_payment=dict(
        db_model=TransactionEarnLeasing,
        schema_class=lms_earn_api_validation_schemas.LeasingInstalmentPaymentsSchema),
    education_term_fee=dict(
        db_model=TransactionEarnEducation,
        schema_class=lms_earn_api_validation_schemas.EducationPaymentSchema),
)


class LMSEarnApi(BasePostResource):
    request_parser = earn_validator
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=LMS_APIS_LOG_PATH,
            file_path='lms_earn_api/lms_earn_api.log',
        ),
        'name': 'lms_earn_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.membership_id = self.request_args.get('membership_number')
        self.locale = self.request_args.get('language')
        self.business_category = self.request_args.get('business_category')
        self.business_trigger = self.request_args.get('business_trigger')
        self.concept_id = self.request_args.get('concept_id')
        self.concept_name = self.request_args.get('concept_name')
        self.external_transaction_id = self.request_args.get('external_transaction_id')
        self.gross_total_amount = self.request_args.get('gross_total_amount')
        self.net_amount = self.request_args.get('net_amount')
        self.amount_paid_using_points = self.request_args.get('amount_paid_using_points')
        self.paid_amount = self.request_args.get('paid_amount')
        self.redemption_reference = self.request_args.get('redemption_reference')
        self.charge_id = self.request_args.get('charge_id')
        self.description = self.request_args.get('description')
        self.transaction_datetime = self.request_args.get('transaction_datetime')
        self.external_user_id = self.request_args.get('external_user_id')
        self.external_user_name = self.request_args.get('external_user_name')

        # Sales
        self.sales_order_id = self.request_args.get('sales_order_id')
        self.party_id = self.request_args.get('party_id')
        self.unit_id = self.request_args.get('unit_id')
        self.property_type = self.request_args.get('property_type')
        self.number_of_instalments = self.request_args.get('number_of_instalments')
        self.property_gross_value = self.request_args.get('property_gross_value')
        self.property_net_value = self.request_args.get('property_net_value')
        self.order_date = self.request_args.get('order_date')

        # Sales instalment payment
        self.instalment_number = self.request_args.get('instalment_number')
        self.instalment_due_date = self.request_args.get('instalment_due_date')
        self.is_handover_payment = self.request_args.get('is_handover_payment')

        # maintenance
        self.maintenance_contract_number = self.request_args.get('maintenance_contract_number')
        self.package_type = self.request_args.get('package_type')
        self.package_id = self.request_args.get('package_id')
        self.package_detail = self.request_args.get('package_detail')
        self.contract_period = self.request_args.get('contract_period')
        self.contract_value = self.request_args.get('contract_value')

        # Leasing
        self.lease_contract_number = self.request_args.get('lease_contract_number')
        self.lease_method = self.request_args.get('lease_method')
        self.is_renewal = self.request_args.get('is_renewal')

        # Education
        self.enrolment_id = self.request_args.get('enrolment_id')
        self.student_id = self.request_args.get('student_id')
        self.grade = self.request_args.get('grade')
        self.term_number = self.request_args.get('term_number')
        self.is_student_enrolment_this_year = self.request_args.get('is_student_enrolment_this_year')

    def initialize_local_veriables(self, **kwargs):
        """
        Initializes local variables
        """
        self.currency = AED
        self.outlet = None
        self.validation_schema = None
        self.earned_points = 0
        self.earn_transaction_id = ''
        self.bonus_points = 0
        self.creation_date = ''
        self.earn_rate = 0
        self.amount = 0

    def validate_business_trigger(self):
        if self.business_trigger not in business_trigger_data.keys():
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Invalid business trigger', custom_code=2)
            return

    def validate_membership_id(self):
        self.user = User.get_active_by_membership_id(self.membership_id)
        if not self.user:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Member not found', custom_code=2)
            return

    def validate_concept_id(self):
        """
        - get lms_concept_id from concept_id_mapping table
        - verify if concept id exists in Outlets
        """
        concept_id_mapping = ConceptIdMapping.get_lms_concept_id(self.business_category, self.concept_id)
        if concept_id_mapping:
            self.concept_id = concept_id_mapping.lms_concept_id

        self.outlet = Outlet.get_info_by_concept_id(self.concept_id)
        if not self.outlet:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Concept Id not found', custom_code=3)

    def validate_category(self):
        """
        validate and fetch category
        """
        category = Category.get_by_business_asset(self.business_category)
        if not category:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Invalid "business_category"')
            return

    def validate_maintenance_package_id(self):
        """
        validate package id if business category is maintenance
        """
        if self.business_category == 'maintenance':
            package_id = MaintenancePackagesLookUp.get_package_id(self.package_id)
            if not package_id:
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.response = self.generate_response_dict(message='Invalid "Package Id."')
                return

    def handle_transaction_earn_tables_entry(self, earn_id, request_data):
        db_table = business_trigger_data.get(self.business_trigger, {}).get('db_model')
        transaction_earn_instance = db_table()
        transaction_earn_instance.__dict__.update(request_data)
        transaction_earn_instance.earn_id = earn_id
        transaction_earn_instance.insert_record()

    def lms_earn(self):
        """
        validate data and request lms for earn with validated data
        """
        self.validation_schema = business_trigger_data.get(self.business_trigger, {}).get('schema_class')
        try:
            data = {
                "member_id": self.user.lms_membership_id,
                "email": self.user.email,

                "business_category": self.business_category,
                "business_trigger": self.business_trigger,
                "concept_id": self.concept_id,
                "concept_name": self.concept_name,
                "external_transaction_id": self.external_transaction_id,
                "gross_total_amount": self.paid_amount,
                "net_amount": self.paid_amount,
                "amount_paid_using_points": self.amount_paid_using_points,
                "paid_amount": self.paid_amount,
                "currency": self.currency,
                "redemption_reference": self.redemption_reference,
                "charge_id": self.charge_id,
                "description": self.description,
                "external_user_id": self.external_user_id,
                "external_user_name": self.external_user_name,
                "transaction_datetime": self.transaction_datetime,

                # hospitality
                "outlet_id": self.outlet.sf_id,
                "outlet_name": self.outlet.name if self.outlet.name else 'Not available',
                "hotel_name": self.outlet.hotel if self.outlet.hotel else 'Not available',
                "hotel_id": self.outlet.sf_id,

                # sales
                "community_id": self.concept_id,
                "community_name": self.concept_name,
                "sales_order_id": self.sales_order_id,
                "party_id": self.party_id,
                "unit_id": self.unit_id,
                "property_type": self.property_type,
                "number_of_instalments": self.number_of_instalments,
                "property_gross_value": self.property_gross_value,
                "property_net_value": self.property_net_value,
                "order_date": self.order_date,

                # sales instalment payment
                "instalment_number": self.instalment_number,
                "instalment_due_date": self.instalment_due_date,
                "is_handover_payment": self.is_handover_payment,

                # maintenance
                "maintenance_contract_number": self.maintenance_contract_number,
                "package_type": self.package_type,
                "package_id": self.package_id,
                "package_detail": self.package_detail,
                "contract_period": self.contract_period,
                "contract_value": self.contract_value,

                # Leasing
                "lease_contract_number": self.lease_contract_number,
                "lease_method": self.lease_method,
                "is_renewal": self.is_renewal,

                # Education
                "school_id": self.concept_id,
                "school_name": self.concept_name,
                "enrolment_id": self.enrolment_id,
                "student_id": self.student_id,
                "grade": self.grade,
                "term_number": self.term_number,
                "is_student_enrolment_this_year": self.is_student_enrolment_this_year
            }

            try:
                load_data = self.validation_schema().load(data)
            except ValidationError as e:
                self.logger.exception("Faulty record detected: {}, {}".format(data, e))
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.response = self.generate_response_dict(message=e.messages)
                return

            load_data['aldar_user_id'] = self.user.id
            load_data['source'] = 'aldar-api'
            self.lms_response = lms_manager.earn([load_data])
            if self.lms_response.get('status') != 0:
                self.external_transaction_id = None
                failed = self.lms_response.get('batch_earn', {}).get('failed', [])
                if failed:
                    self.response = self.generate_response_dict(message=failed[0].get('message', ''))
                else:
                    self.response = self.generate_response_dict(message=TranslationManager.get_translation(
                        TranslationManager.UNABLE_TO_EARN
                    ))
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                return
            earned = self.lms_response.get('batch_earn', {}).get('success', [])
            if earned:
                self.earned_points = earned[0].get('earned_points', 0)
                self.earn_transaction_id = earned[0].get('earn_transaction_id')
                self.bonus_points = earned[0].get('bonus_points')
                self.creation_date = earned[0].get('creation_date')
                self.earn_rate = earned[0].get('earn_rate')
                self.amount = earned[0].get('amount')
                if self.lms_response.get('earn_id'):
                    self.handle_transaction_earn_tables_entry(self.lms_response.get('earn_id'), load_data)

        except RequestException as re:
            self.external_transaction_id = None
            self.send_response_flag = True
            message = TranslationManager.get_translation(TranslationManager.UNABLE_TO_EARN)
            for error in re.response.json().get('errors', []):
                message = error.get('message', message)
                break
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message=message)

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        data = {
            "email": self.user.email,
            "business_category": self.business_category,
            "business_trigger": self.business_trigger,
            "concept_id": self.concept_id,
            "earn_transaction_id": self.earn_transaction_id,
            "external_transaction_id": self.external_transaction_id,
            "earned_points": self.earned_points,
            "amount": self.amount,
            "earn_rate": self.earn_rate,
            "bonus_points": self.bonus_points,
            "creation_date": self.creation_date
        }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables(**kwargs)
        self.validate_business_trigger()
        if self.send_response_flag:
            return
        self.validate_membership_id()
        if self.send_response_flag:
            return
        self.validate_concept_id()
        if self.send_response_flag:
            return
        self.validate_category()
        if self.send_response_flag:
            return
        self.validate_maintenance_package_id()
        if self.send_response_flag:
            return
        self.lms_earn()
        if self.send_response_flag:
            return
        self.set_final_response()
