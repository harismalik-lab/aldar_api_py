"""
User Profile API validation
"""

from flask_restful import reqparse
from flask_restful.inputs import regex

from common.constants import EN
from utils.custom_request_parsers import email, language

user_profile_parser = reqparse.RequestParser(bundle_errors=True)

user_profile_parser.add_argument(
    'language',
    type=language,
    default=EN,
    location='json'
)
user_profile_parser.add_argument(
    name="mobile_number",
    type=regex(r'^(?:[0-9]●?){6,14}$'),
    required=False,
    location='json',
    help="mobile_number must have minimum 12 and maximum 14 numeric characters excluding '00' and '+'."
)
user_profile_parser.add_argument(
    'email',
    type=email,
    location='json'
)
