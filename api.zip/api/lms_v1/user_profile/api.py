"""
Get User Profile API
Returns adr user profile
"""

from requests import codes

from api.lms_v1.user_profile.validation import user_profile_parser
from app_configurations.settings import LMS_APIS_LOG_PATH
from common.callbacks_base_resource import BasePostResource
from common.constants import MISSING_PARAMETER_ERR_CODE, USER_NOT_FOUND_ERR_CODE
from models.aldar_app.user import User
from utils.translation_manager import TranslationManager


class UserProfileAPI(BasePostResource):
    request_parser = user_profile_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=LMS_APIS_LOG_PATH,
            file_path='user_profile/user_profile.log',
        ),
        'name': 'user_profile'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.mobile_number = self.request_args.get('mobile_number')
        self.email = self.request_args.get('email')

    def initialize_local_veriables(self):
        """
        Initializes local variables
        """
        self.user = None
        self.user_profile = {}

    def get_adr_user_profile(self):
        """
        get user by:
        - if email (prior)
        - if email is not available then mobile number
            - concat '+' with given mobile number and query db
        - if both are N/A, return error response
        """
        if self.email:
            self.user = User.get_user_by_email_or_phone(email=self.email)
        if not self.user:
            if self.mobile_number:
                self.mobile_number = '+{}'.format(self.mobile_number)
                self.user = User.get_user_by_email_or_phone(phone=self.mobile_number)

        if not self.mobile_number and not self.email:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.MOBILE_EMAIL_MISSING,
                    self.locale
                ),
                custom_code=MISSING_PARAMETER_ERR_CODE
            )
            return self.send_response(self.response, self.status_code)

        if not self.user:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.USER_NOT_FOUND,
                    self.locale
                ),
                custom_code=USER_NOT_FOUND_ERR_CODE
            )
            return self.send_response(self.response, self.status_code)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        data = {
            'email': self.user.email,
            'membership_number': self.user.membership_id,
            'mobile_number': self.user.mobile_no.replace('+', ''),  # removing '+' char from mobile number
            'first_name': self.user.first_name,
            'last_name': self.user.last_name,
            "is_active": self.user.is_active,
            "member_status": self.user.lms_status,
            "registration_date": self.user.created_at.strftime('%Y-%m-%d %H:%M:%S')

        }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables()
        self.get_adr_user_profile()
        if self.send_response_flag:
            return
        self.generate_final_response()
