"""
Get Earn Transaction API validation
"""

from flask_restful import reqparse

from common.constants import EN
from utils.custom_request_parsers import language

get_earn_transaction_parser = reqparse.RequestParser(bundle_errors=True)

get_earn_transaction_parser.add_argument(
    'language',
    type=language,
    default=EN,
    location='json'
)
