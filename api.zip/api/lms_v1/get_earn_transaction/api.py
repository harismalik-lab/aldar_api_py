"""
Get Earn Transaction Details API
    - Get Earn Transaction record from `aldar_app.earn` table by joining it with `User` by user_id
    - generate and return response
"""

from requests import codes

from api.lms_v1.get_earn_transaction.validation import get_earn_transaction_parser
from app_configurations.settings import LMS_APIS_LOG_PATH
from common.callbacks_base_resource import BaseGetResource
from common.constants import UPTO_TWO_DECIMALS
from models.aldar_app.earn import Earn
from utils.translation_manager import TranslationManager


class EarnTransactionDetails(BaseGetResource):
    request_parser = get_earn_transaction_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=LMS_APIS_LOG_PATH,
            file_path='get_earn_transaction/get_earn_transaction_api.log',
        ),
        'name': 'get_earn_transaction_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')

    def initialize_local_veriables(self, **kwargs):
        """
        Initializes local variables
        """
        self.transaction_id = kwargs['earn_transaction_id']
        self.transaction_details = None
        self.response_data = {}

    def get_earn_transaction_details(self):
        """
        query Earn table for transaction details based on lms_transaction_id
        """
        self.transaction_details = Earn.get_by_lms_transaction_id(self.transaction_id)
        if not self.transaction_details:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="No earn transaction found against '{}' transaction id".format(self.transaction_id),
                custom_code=2
            )
            return

    def generate_final_response(self):
        """
        Generates final response
        """
        if self.transaction_details:
            self.response_data = {
                "email": self.transaction_details.email,
                "business_category": self.transaction_details.business_category,
                "business_trigger": self.transaction_details.business_trigger,
                "concept_id": self.transaction_details.concept_id,
                "earn_transaction_id": self.transaction_id,
                "external_transaction_id": self.transaction_details.external_transaction_id,
                "earned_points": UPTO_TWO_DECIMALS.format(self.transaction_details.points_earned),
                "amount": UPTO_TWO_DECIMALS.format(self.transaction_details.paid_amount),
                "earn_rate": UPTO_TWO_DECIMALS.format(self.transaction_details.earn_rate),
                "bonus_points": UPTO_TWO_DECIMALS.format(self.transaction_details.bonus_points),
                "creation_date": self.transaction_details.date_created.strftime('%Y-%m-%d %H:%M:%S')
            }
        self.send_response_flag = True
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=self.response_data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables(**kwargs)
        self.get_earn_transaction_details()
        if self.send_response_flag:
            return
        self.generate_final_response()
