"""
Get Points API validation
"""
from flask_restful import reqparse

from utils.custom_request_parsers import business_category_retail

get_points_api_validator = reqparse.RequestParser(bundle_errors=True)

get_points_api_validator.add_argument(
    'business_category',
    type=business_category_retail,
    required=True,
    location='json'
)
