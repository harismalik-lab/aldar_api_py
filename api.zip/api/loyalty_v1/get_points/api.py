"""
Get Points API
"""
import math

from requests import codes, RequestException

from api.loyalty_v1.get_points.validation import get_points_api_validator
from app_configurations.settings import CLO_APIS_LOG_PATH
from common.callbacks_base_resource import BasePostResource as CLOBasePostResource
from common.constants import AED
from models.aldar_app.category import Category
from models.aldar_app.user import User
from utils.lms_manager import lms_manager


class GetPointsAPI(CLOBasePostResource):
    request_parser = get_points_api_validator
    logger_info = {
        'filename': '{file_path}'.format(
            log_path=CLO_APIS_LOG_PATH,
            file_path='get_points_api.log',
        ),
        'name': 'get_points'
    }

    def populate_request_arguments(self):
        self.business_category = self.request_args.get('business_category')

    def initialize_class_attributes(self):
        self.points = {}

    def validate_membership_code(self, *args, **kwargs):
        self.membership_code = kwargs['membership_code']
        user = User.get_active_by_membership_id(self.membership_code)
        if not user:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Member not found', custom_code=2)
            return
        self.lms_id = user.lms_membership_id

    def get_points(self):
        category = Category.get_by_business_asset(self.business_category)
        if not category:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Invalid "business_category"')
            return
        try:
            points = lms_manager.get_user_points(self.lms_id, category.business_trigger, self.business_category)
            self.points = {
                "available_points": str(points['total_available_points']),
                "amount": str(math.floor(points['total_available_points']/10)),  # TODO
                "currency": AED,
                "minimum_redeemable_points": "10",  # TODO
                "minimum_redeemable_amount": "1"  # TODO
            }
        except RequestException as re:
            self.send_response_flag = True
            message = 'Unable to get points.'
            for error in re.response.json().get('errors', []):
                message = error.get('message', message)
                break
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message=message)
        except Exception:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Unable to get points.')

    def set_final_response(self):
        self.send_response_flag = True
        self.status_code = codes.OK
        self.response = self.generate_response_dict(data=self.points)

    def process_request(self, *args, **kwargs):
        self.validate_membership_code(*args, **kwargs)
        if self.send_response_flag:
            return
        self.get_points()
        if self.send_response_flag:
            return
        self.set_final_response()
