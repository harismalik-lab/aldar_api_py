"""
Transaction Decision API
"""
import datetime

from requests import codes

from api.loyalty_v1.transaction_decsicion.validation import transaction_decision_validator
from app_configurations.settings import CLO_APIS_LOG_PATH
from common.callbacks_base_resource import BasePostResource as CLOBasePostResource
from models.aldar_app.clo_transactions import CloTransaction
from models.aldar_app.user import User
from models.entertainer_web.outlet import Outlet
from utils.api_utils import push_braze_notification, get_braze_android_message_object, get_braze_apple_message_object


class TransactionDecisionAPI(CLOBasePostResource):
    log_api_request = True
    request_parser = transaction_decision_validator
    logger_info = {
        'filename': '{file_path}'.format(
            log_path=CLO_APIS_LOG_PATH,
            file_path='transaction_decision_api.log',
        ),
        'name': 'transaction_decision_api'
    }

    def populate_request_arguments(self):
        self.membership_code = self.request_args.get('membership_code')
        self.card_id = self.request_args.get('card_id')
        self.te_merchant_id = self.request_args.get('te_merchant_id')
        self.ls_merchant_id = self.request_args.get('ls_merchant_id')
        self.transaction_date = self.request_args.get('transaction_date')
        self.transaction_amount = self.request_args.get('transaction_amount')
        self.transaction_currency = self.request_args.get('transaction_currency')
        self.transaction_amount_aed = self.request_args.get('transaction_amount_aed')

    def validate_membership_id(self):
        user = User.get_active_by_membership_id(self.membership_code)
        if not user:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Member not found', custom_code=2)
            return
        self.user_id = user.id

    def validate_te_merchant_id(self):
        outlet = Outlet.get_by_concept_id(self.te_merchant_id)
        if not outlet:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Invalid "te_merchant_id"', custom_code=7)
            return
        # self.mapping = MerchantMapping.get_category_info_by_merchant_id(outlet.merchant_id)
        # if not self.mapping:
        #     self.send_response_flag = True
        #     self.status_code = codes.UNPROCESSABLE_ENTITY
        #     self.response = self.generate_response_dict(message='Merchant doesn\'t belong to any category')
        #     return

    def validate_duplication(self, *args, **kwargs):
        transaction = CloTransaction.get_by_clo_transaction_id(kwargs['transaction_id'])
        if transaction:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message='Transaction already received for accrual or redemption decision',
                custom_code=4
            )
            return

    def make_transaction_entry(self, *args, **kwargs):
        self.clo_transaction = CloTransaction(
            user_id=self.user_id,
            membership_code=self.membership_code,
            concept_id=self.te_merchant_id,
            ls_merchant_id=self.ls_merchant_id,
            card_id=self.card_id,
            amount=self.transaction_amount,
            currency=self.transaction_currency,
            transaction_datetime=self.transaction_date + datetime.timedelta(hours=4),
            clo_transaction_id=kwargs['transaction_id'],
            amount_in_aed=self.transaction_amount_aed
        )
        self.clo_transaction.insert_record()

    def push_braze_notification(self, retry=True):
        try:
            message = "Decision Required."
            push_braze_notification(
                self.user_id,
                get_braze_android_message_object(message, self.clo_transaction.id),
                get_braze_apple_message_object(message, self.clo_transaction.id)
            )
        except Exception as e:
            self.logger.exception("Unable to publish notification: {}".format(e))
            if retry:
                self.push_braze_notification(retry=False)
            else:
                self.clo_transaction.braze_pushed = 0
                self.clo_transaction.update_record()
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.response = self.generate_response_dict(message='Something went wrong, please try later')
                return

    def set_final_response(self):
        self.send_response_flag = True
        self.status_code = codes.CREATED
        self.response = self.generate_response_dict(message='transaction received successfully.', data={
            'te_transaction_id': self.clo_transaction.id
        })

    def process_request(self, *args, **kwargs):
        self.validate_membership_id()
        if self.send_response_flag:
            return
        self.validate_te_merchant_id()
        if self.send_response_flag:
            return
        self.validate_duplication(*args, **kwargs)
        if self.send_response_flag:
            return
        self.make_transaction_entry(*args, **kwargs)
        self.push_braze_notification()
        if self.send_response_flag:
            return
        self.set_final_response()
