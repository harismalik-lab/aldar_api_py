"""
Transaction Decision API validator
"""

from flask_restful import reqparse

from common.constants import AED
from utils.custom_request_parsers import datetime_validator, check_positive, currency

transaction_decision_validator = reqparse.RequestParser(bundle_errors=True)

transaction_decision_validator.add_argument(
    'membership_code',
    type=str,
    required=True,
    location='json'
)
transaction_decision_validator.add_argument(
    'card_id',
    type=str,
    required=True,
    location='json'
)
transaction_decision_validator.add_argument(
    'te_merchant_id',
    type=str,
    required=True,
    location='json'
)
transaction_decision_validator.add_argument(
    'ls_merchant_id',
    type=str,
    required=True,
    location='json'
)
transaction_decision_validator.add_argument(
    'transaction_date',
    type=datetime_validator,
    required=True,
    location='json'
)
transaction_decision_validator.add_argument(
    'transaction_amount',
    type=check_positive,
    required=True,
    location='json'
)
transaction_decision_validator.add_argument(
    'transaction_currency',
    type=currency,
    required=True,
    location='json',
    default=AED
)
transaction_decision_validator.add_argument(
    'transaction_amount_aed',
    type=check_positive,
    required=True,
    location='json'
)
