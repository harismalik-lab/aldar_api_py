"""
Transaction Notification API validator
"""

from flask_restful import reqparse

from common.constants import AED
from utils.custom_request_parsers import datetime_validator, check_positive, currency, transaction_type

transaction_notif_validator = reqparse.RequestParser(bundle_errors=True)

transaction_notif_validator.add_argument(
    'membership_code',
    type=str,
    required=True,
    location='json'
)
transaction_notif_validator.add_argument(
    'card_id',
    type=str,
    required=True,
    location='json'
)
transaction_notif_validator.add_argument(
    'te_merchant_id',
    type=str,
    required=True,
    location='json'
)
transaction_notif_validator.add_argument(
    'ls_merchant_id',
    type=str,
    required=True,
    location='json'
)
transaction_notif_validator.add_argument(
    'transaction_date',
    type=datetime_validator,
    required=True,
    location='json'
)
transaction_notif_validator.add_argument(
    'transaction_amount',
    type=check_positive,
    required=True,
    location='json'
)
transaction_notif_validator.add_argument(
    'transaction_currency',
    type=currency,
    required=True,
    location='json',
    default=AED
)
transaction_notif_validator.add_argument(
    'transaction_amount_aed',
    type=check_positive,
    required=True,
    location='json'
)
transaction_notif_validator.add_argument(
    'type',
    type=transaction_type,
    required=True,
    location='json'
)
transaction_notif_validator.add_argument(
    'points_availability_after_x_days',
    type=int,
    required=True,
    location='json'
)
transaction_notif_validator.add_argument(
    'frozen_transaction_id',
    type=str,
    required=False,
    location='json'
)
