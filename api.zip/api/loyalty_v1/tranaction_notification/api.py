"""
Transaction Notification API
"""
import datetime

from requests import codes

from api.loyalty_v1.tranaction_notification.validation import transaction_notif_validator
from api.loyalty_v1.transaction_decsicion.api import TransactionDecisionAPI
from app_configurations.settings import CLO_APIS_LOG_PATH
from common.constants import TRANSACTION_TYPE_REDEMPTION, LINK_NOTIFICATION_X_DAYS_MSG
from models.aldar_app.clo_transactions import CloTransaction
from utils.api_utils import push_braze_notification, get_braze_apple_message_object, get_braze_android_message_object


class TransactionNotificationAPI(TransactionDecisionAPI):
    log_api_request = True
    request_parser = transaction_notif_validator
    logger_info = {
        'filename': '{file_path}'.format(
            log_path=CLO_APIS_LOG_PATH,
            file_path='transaction_notification_api.log',
        ),
        'name': 'transaction_notification_api'
    }

    def populate_request_arguments(self):
        self.membership_code = self.request_args.get('membership_code')
        self.card_id = self.request_args.get('card_id')
        self.te_merchant_id = self.request_args.get('te_merchant_id')
        self.ls_merchant_id = self.request_args.get('ls_merchant_id')
        self.transaction_date = self.request_args.get('transaction_date')
        self.transaction_amount = self.request_args.get('transaction_amount')
        self.transaction_currency = self.request_args.get('transaction_currency')
        self.transaction_amount_aed = self.request_args.get('transaction_amount_aed')
        self.type = self.request_args.get('type')
        self.points_availability_after_x_days = self.request_args.get('points_availability_after_x_days')
        self.frozen_transaction_id = self.request_args.get('frozen_transaction_id')

    def validate_duplication(self, *args, **kwargs):
        self.transaction = CloTransaction.get_by_clo_transaction_id(kwargs['transaction_id'])
        if self.transaction and self.transaction.transaction_type:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message='Transaction already received for accrual or redemption decision',
                custom_code=5
            )
            return

    def make_transaction_entry(self, *args, **kwargs):
        if self.transaction:
            self.clo_transaction = self.transaction
        else:
            self.clo_transaction = CloTransaction(
                user_id=self.user_id,
                membership_code=self.membership_code,
                concept_id=self.te_merchant_id,
                ls_merchant_id=self.ls_merchant_id,
                card_id=self.card_id,
                amount=self.transaction_amount,
                currency=self.transaction_currency,
                transaction_datetime=self.transaction_date + datetime.timedelta(hours=4),
                points_availability_after_days=self.points_availability_after_x_days,
                clo_transaction_id=kwargs['transaction_id'],
                amount_in_aed=self.transaction_amount_aed
            )
        if self.type.lower() == TRANSACTION_TYPE_REDEMPTION:
            self.clo_transaction.resolution_status = CloTransaction.RESOLUTION_REDEEM
        else:
            self.clo_transaction.resolution_status = CloTransaction.RESOLUTION_ACCRUE
        self.clo_transaction.transaction_type = self.type
        self.clo_transaction.points_availability_after_days = self.points_availability_after_x_days
        self.clo_transaction.frozen_transaction_id = self.frozen_transaction_id
        if self.transaction:
            self.clo_transaction.update_record()
        else:
            self.clo_transaction.insert_record()

    def push_braze_notification(self, retry=True):
        try:
            message = "Transaction Alert."
            if self.points_availability_after_x_days >= 15:
                message = LINK_NOTIFICATION_X_DAYS_MSG.format(self.points_availability_after_x_days)
            push_braze_notification(
                self.user_id,
                get_braze_android_message_object(message, self.clo_transaction.id, notification=True),
                get_braze_apple_message_object(message, self.clo_transaction.id, notification=True)
            )
        except Exception as e:
            self.logger.exception("Unable to publish notification: {}".format(e))
            self.clo_transaction.braze_pushed = 0
            self.clo_transaction.update_record()

    def set_final_response(self):
        self.send_response_flag = True
        if self.transaction:
            self.status_code = codes.OK
        else:
            self.status_code = codes.CREATED
        self.response = self.generate_response_dict(message='transaction received successfully for notification.',
                                                    data={'te_transaction_id': self.clo_transaction.id})

    def process_request(self, *args, **kwargs):
        self.validate_membership_id()
        if self.send_response_flag:
            return
        self.validate_te_merchant_id()
        if self.send_response_flag:
            return
        self.validate_duplication(*args, **kwargs)
        if self.send_response_flag:
            return
        self.make_transaction_entry(*args, **kwargs)
        self.push_braze_notification()
        if self.send_response_flag:
            return
        self.set_final_response()
