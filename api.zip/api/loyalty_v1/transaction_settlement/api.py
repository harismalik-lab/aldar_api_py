"""
Transaction Settlement API
"""
import datetime
import uuid

from requests import codes, RequestException

from api.loyalty_v1.transaction_decsicion.api import TransactionDecisionAPI
from api.loyalty_v1.transaction_settlement.validation import transaction_settlement_validator
from app_configurations.settings import CLO_APIS_LOG_PATH
from common.constants import TRANSACTION_TYPE_ACCRUAL, AED, TRANSACTION_TYPE_REDEMPTION
from models.aldar_app.clo_transactions import CloTransaction
from models.aldar_app.user import User
from models.entertainer_web.merchant_mapping import MerchantMapping
from models.entertainer_web.outlet import Outlet
from utils.lms_manager import lms_manager
from utils.translation_manager import TranslationManager


class TransactionSettlementAPI(TransactionDecisionAPI):
    log_api_request = True
    request_parser = transaction_settlement_validator
    logger_info = {
        'filename': '{file_path}'.format(
            log_path=CLO_APIS_LOG_PATH,
            file_path='transaction_settlement_api.log',
        ),
        'name': 'transaction_settlement_api'
    }

    def populate_request_arguments(self):
        self.membership_code = self.request_args.get('membership_code')
        self.card_id = self.request_args.get('card_id')
        self.te_merchant_id = self.request_args.get('te_merchant_id')
        self.ls_merchant_id = self.request_args.get('ls_merchant_id')
        self.transaction_date = self.request_args.get('transaction_date')
        self.transaction_amount = self.request_args.get('transaction_amount')
        self.transaction_currency = self.request_args.get('transaction_currency')
        self.transaction_amount_aed = self.request_args.get('transaction_amount_aed')
        self.type = self.request_args.get('type')
        # self.points_availability_after_x_days = self.request_args.get('points_availability_after_x_days')
        self.ls_points = self.request_args.get('ls_points')
        self.frozen_transaction_id = self.request_args.get('frozen_transaction_id')

    def validate_membership_id(self):
        self.user = User.get_active_by_membership_id(self.membership_code)
        if not self.user:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Member not found', custom_code=2)
            return
        self.user_id = self.user.id

    def validate_duplication(self, *args, **kwargs):
        self.transaction = CloTransaction.get_by_clo_transaction_id(kwargs['transaction_id'])
        if self.transaction and self.transaction.is_processed:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message='Transaction is already settled.',
                custom_code=6
            )
            return

    def validate_te_merchant_id(self):
        self.outlet = Outlet.get_info_by_concept_id(self.te_merchant_id)
        if not self.outlet:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Invalid "te_merchant_id"', custom_code=7)
            return
        self.mapping = MerchantMapping.get_category_info_by_merchant_id(self.outlet.merchant_id)

    def make_transaction_entry(self, *args, **kwargs):
        if self.transaction:
            self.clo_transaction = self.transaction
        else:
            self.clo_transaction = CloTransaction(
                user_id=self.user_id,
                membership_code=self.membership_code,
                concept_id=self.te_merchant_id,
                ls_merchant_id=self.ls_merchant_id,
                card_id=self.card_id,
                amount=self.transaction_amount,
                currency=self.transaction_currency,
                transaction_datetime=self.transaction_date + datetime.timedelta(hours=4),
                amount_in_aed=self.transaction_amount_aed,
                ls_points=self.ls_points,
                clo_transaction_id=kwargs['transaction_id']
            )
        if self.type.lower() == TRANSACTION_TYPE_REDEMPTION:
            self.clo_transaction.resolution_status = CloTransaction.RESOLUTION_REDEEM
        else:
            self.clo_transaction.resolution_status = CloTransaction.RESOLUTION_ACCRUE
        self.clo_transaction.transaction_type = self.type
        self.clo_transaction.ls_points = self.ls_points
        self.clo_transaction.amount_in_aed = self.transaction_amount_aed
        self.clo_transaction.amount = self.transaction_amount
        self.clo_transaction.frozen_transaction_id = self.frozen_transaction_id
        if self.transaction:
            self.clo_transaction.update_record()
        else:
            self.clo_transaction.insert_record()

    def settle(self):
        try:
            if self.type == TRANSACTION_TYPE_ACCRUAL:
                self.lms_response = lms_manager.earn([
                    {
                        "source": "CLO",
                        "aldar_user_id": self.user.id,
                        "member_id": self.user.lms_membership_id,
                        "email": self.user.email,
                        "business_category": self.mapping.name,
                        "business_trigger": self.mapping.business_trigger,
                        "concept_id": self.te_merchant_id,
                        "concept_name": self.outlet.name,
                        "external_transaction_id": self.clo_transaction.clo_transaction_id,
                        "gross_total_amount": self.transaction_amount_aed,
                        "net_amount": self.transaction_amount_aed,
                        "amount_paid_using_points": "0",
                        "paid_amount": self.transaction_amount_aed,
                        "currency": AED,
                        "redemption_reference": str(uuid.uuid4()),
                        "charge_id": "clo",
                        "description": "transaction made by CLO",
                        "transaction_datetime": self.clo_transaction.transaction_datetime.strftime("%Y-%m-%d %H:%M:%S"),

                        "merchant_category": self.mapping.name,
                        "outlet_id": self.outlet.id,
                        "outlet_name": self.outlet.name
                    }
                ])
                if self.lms_response.get('status') != 0:
                    self.send_response_flag = True
                    self.status_code = codes.UNPROCESSABLE_ENTITY
                    self.response = self.generate_response_dict(message=TranslationManager.get_translation(
                        TranslationManager.UNABLE_TO_EARN
                    ))
                    return
                earned = self.lms_response.get('batch_earn', {}).get('success', [])
                if earned:
                    self.earned_points = earned[0].get('earned_points', 0)
                    self.clo_transaction.earned_burned_lms_points = self.earned_points
                self.reference_code = earned[0].get('earn_transaction_id')
                self.clo_transaction.is_processed = 1
                self.clo_transaction.update_record()
            else:
                self.lms_response = lms_manager.burn_points(
                    self.user.lms_membership_id,
                    self.transaction_amount_aed,
                    self.mapping.business_trigger,
                    self.mapping.name,
                    self.clo_transaction.clo_transaction_id,
                    self.te_merchant_id,
                    user_id=self.user.id,
                    redemption_mode='amount',
                    concept_name=self.outlet.name,
                    description="transaction made by CLO",
                    source="CLO"
                )
                if self.lms_response and self.lms_response.get('status') != 0:
                    self.transaction_number = None
                    self.send_response_flag = True
                    self.status_code = codes.UNPROCESSABLE_ENTITY
                    self.response = self.generate_response_dict(message=TranslationManager.get_translation(
                        TranslationManager.UNABLE_TO_BURN
                    ))
                    return
                self.points = self.lms_response.get('redemption', {}).get('points', 0)
                self.clo_transaction.earned_burned_lms_points = self.points
                self.clo_transaction.is_processed = 1
                self.clo_transaction.update_record()
                self.reference_code = self.lms_response.get('redemption', {}).get('redemption_reference_code')
        except RequestException as r_e:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            message = TranslationManager.get_translation(TranslationManager.UNABLE_TO_EARN)
            for error in r_e.response.json().get('errors', []):
                message = error.get('message', message)
                break
            self.response = self.generate_response_dict(message=message)
            return

    def set_final_response(self):
        self.send_response_flag = True
        self.status_code = codes.CREATED
        self.response = self.generate_response_dict(message='transaction processed successfully.', data={
            "te_transaction_id": self.clo_transaction.id,
            "points": str(self.clo_transaction.earned_burned_lms_points),
            "type": self.type,
            "reference_number": self.reference_code
        }
)

    def process_request(self, *args, **kwargs):
        self.validate_membership_id()
        if self.send_response_flag:
            return
        self.validate_te_merchant_id()
        if self.send_response_flag:
            return
        self.validate_duplication(*args, **kwargs)
        if self.send_response_flag:
            return
        self.make_transaction_entry(*args, **kwargs)
        self.settle()
        if self.send_response_flag:
            return
        self.set_final_response()
