"""
Get Access Token API validation
"""
from flask_restful import reqparse

from common.constants import EN
from utils.custom_request_parsers import language


get_token_parser = reqparse.RequestParser(bundle_errors=True)

get_token_parser.add_argument(
    'language',
    type=language,
    default=EN,
    location='json'
)
get_token_parser.add_argument(
    'client_id',
    type=str,
    location='json',
    required=True
)
get_token_parser.add_argument(
    'client_secret',
    type=str,
    location='json',
    required=True
)
