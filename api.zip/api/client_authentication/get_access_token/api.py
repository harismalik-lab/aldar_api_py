"""
Get Access Token API
    - validate_client
        - get company from client record
    - disable previous active access tokens
    - create/insert new access token
"""
from datetime import datetime, timedelta
from uuid import uuid4

from requests import codes

from api.client_authentication.get_access_token.validation import get_token_parser
from app_configurations.settings import CLIENT_AUTH_LOG_PATH
from common.callbacks_base_resource import BasePostResource, basic_auth
from common.constants import INVALID_CLIENT_ERR_CODE
from models.entertainer_web.api_token_clients import ApiTokenClients
from models.entertainer_web.api_tokens import ApiTokens
from utils.translation_manager import TranslationManager


class GetAccessToken(BasePostResource):
    request_parser = get_token_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=CLIENT_AUTH_LOG_PATH,
            file_path='get_access_token_api/get_access_token_api.log',
        ),
        'name': 'get_access_token_api'
    }
    validators = [basic_auth.login_required]

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.client_id = self.request_args.get('client_id')
        self.client_secret = self.request_args.get('client_secret')

    def initialize_class_attributes(self):
        """
        Initializes class attributes
        """
        self.company = ''

    def validate_client_creds(self):
        """
        query `api_token_clients` to validate client's provided Creds
        """
        client_exists = ApiTokenClients.get_client(self.client_id, self.client_secret)
        if not client_exists:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.INVALID_CLIENT,
                    self.locale
                ),
                custom_code=INVALID_CLIENT_ERR_CODE
            )
            return self.send_response(self.response, self.status_code)
        self.company = client_exists.company

    def disable_previous_access_tokens(self):
        """
        qurey `api_tokens` model to disable client's active access tokens
        """
        ApiTokens.disable_active_tokens(self.client_id, self.client_secret)

    def create_new_token(self):
        """
        create and insert a new token
        """
        self.new_access_token = str(uuid4())
        api_token = ApiTokens(
            company=self.company,
            client_id=self.client_id,
            client_secret=self.client_secret,
            client_token=self.new_access_token,
            token_issue_date=datetime.now(),
            token_expiry_date=datetime.now() + timedelta(seconds=86400),
            is_expired=0
        )
        api_token.insert_record()

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        data = {
            'client_access_token': self.new_access_token,
            'expires_in': 86400
        }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.CREATED
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialize_class_attributes()
        self.validate_client_creds()
        if self.send_response_flag:
            return
        # self.disable_previous_access_tokens()
        self.create_new_token()
        self.set_final_response()
