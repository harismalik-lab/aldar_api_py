"""
Session Logout Api
- get session info
    - get session token
    - get company
- get session obj by querying Session model with company and session_token
- if session obj found:
    - deactivate session_token
- Generate final response
"""
from requests import codes

from common.base_resource import BasePostResource
from api.v1.logout.validation import logout_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from utils.api_utils import get_locale
from utils.translation_manager import TranslationManager
from models.entertainer_web.session import Session
from user_authentication.authentication import get_current_customer


class LogoutApi(BasePostResource):
    """
    @api {post} /user/logout | Logout the user and remove the session.

    @apiSampleRequest /v1/session/logout

    @apiName LogoutApi
    @apiGroup UsersService
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}       [language]      Response language
    """
    request_parser = logout_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='session_logout_api.log',
        ),
        'name': 'logout_api'
    }
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Adds request arguments of logout api.
        """
        self.locale = self.request_args.get('language')

    def setting_variables(self):
        """
        Sets variables logout api
        """
        self.locale = get_locale(self.locale)

    def get_session_info(self):
        """
        Gets session_token from user info
        """
        self.customer = get_current_customer()
        self.session_token = self.customer.get('session_token')
        self.company = self.customer.get('company')

    def generate_final_response(self):
        """
        Sets final response of session logout api
        :rtype: dict
        """
        self.send_response_flag = True
        self.status_code = codes.OK
        # get session obj
        session = Session.get_by_company_and_session_token(company=self.company, session_token=self.session_token)
        if session:
            # set session as inactive
            Session.deactivate_against_session_token(self.session_token)

            response_message = TranslationManager.get_translation(
                TranslationManager.success,
                self.locale
            )
            response_success = True
        else:
            self.status_code = codes.UNPROCESSABLE_ENTITY
            response_message = TranslationManager.get_translation(
                TranslationManager.wrong_session_token,
                self.locale
            )
            response_success = False

        self.response = {
            "message": response_message,
            "success": response_success,
            "data": [],
            "code": 0
        }
        return self.send_response(self.response, status_code=self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Handles the process of api
        """
        self.setting_variables()
        self.get_session_info()
        self.generate_final_response()
