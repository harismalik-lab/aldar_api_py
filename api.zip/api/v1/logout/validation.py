"""
Validation for Logout api
"""
from flask_restful import reqparse
from utils.custom_request_parsers import language
from common.constants import EN


logout_parser = reqparse.RequestParser(bundle_errors=True)

logout_parser.add_argument(
    name="language",
    type=language,
    default=EN,
    required=False,
    location='json'
)
