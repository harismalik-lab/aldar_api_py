"""
Country API Util methods
"""

from flask import g

from models.aldar_app.country import Country

cache = g.cache


@cache.memoize(timeout=86400)
def get_all_countries(locale):
    """
    Prepares a list of all active countries
    :param str locale: locale code for translation
    :return list: countries list
    """
    countries_list = []
    for country in Country.get_active_countries(locale):
        countries_list.append(country._asdict())
    return countries_list
