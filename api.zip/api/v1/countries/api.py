"""
Countries API
Returns list of countries
"""
from flask import current_app
from requests import codes

from api.v1.countries.utils import get_all_countries
from api.v1.countries.validation import country_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.api_utils import get_api_configurations
from common.base_resource import BasePostResource
from common.constants import PUBLIC_CONFIGS, ADR
from models.entertainer_web.api_configuration import ApiConfiguration
from utils.translation_manager import TranslationManager


class CountriesAPI(BasePostResource):
    request_parser = country_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='countries/countries.log',
        ),
        'name': 'countries'
    }
    required_token = False

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')

    def initialize_local_veriables(self):
        """
        Initializes local veriables
        """
        self.countries = []
        self.environment = current_app.config['ENV']
        self.api_configs = get_api_configurations(ADR, self.environment, PUBLIC_CONFIGS)

    def set_countries(self):
        """
        Sets countries list
        """
        self.countries = get_all_countries(self.locale)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        data = {
            'countries': self.countries,
            'countries_version': self.api_configs.get(ApiConfiguration.COUNTRIES_VERSION, 1)
        }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables()
        self.set_countries()
        self.generate_final_response()
