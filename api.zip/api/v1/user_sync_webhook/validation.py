"""
User Syc Web hook API validation
"""

from flask_restful import reqparse
from flask_restful.inputs import regex

user_sync_web_hook_parser = reqparse.RequestParser(bundle_errors=True)

user_sync_web_hook_parser.add_argument(
    'action',
    type=regex(r'^(tier_updated|status_updated)$'),
    location='json',
    required=True
)
user_sync_web_hook_parser.add_argument(
    'lms_member_id',
    type=str,
    location='json',
    required=True
)
user_sync_web_hook_parser.add_argument(
    'value',
    type=str,
    location='json',
    required=True
)
