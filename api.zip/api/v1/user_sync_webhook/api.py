"""
User Sync Webhook
"""
from flask import current_app
from requests import codes, RequestException

from api.v1.user_sync_webhook.validation import user_sync_web_hook_parser
from common.callbacks_base_resource import BasePostResource as WebHookBasePostResource
from models.aldar_app.user import User
from models.aldar_app.user_sync_webhook_logs import UserSyncWebhookLog
from user_authentication.lms_authentication import HTTPBasicAuthThirdParty
from utils.lms_manager import lms_manager

basic_auth_web_hook = HTTPBasicAuthThirdParty()


@basic_auth_web_hook.get_password
def get_basic_auth_password(username):
    try:
        return current_app.config['BASIC_AUTH_CREDENTIALS_WEB_HOOK'].get(username)
    except KeyError:
        return None


class UserSyncWebhook(WebHookBasePostResource):
    request_parser = user_sync_web_hook_parser
    logger_info = {
        'filename': '{file_path}'.format(
            file_path='user_sync_web_hook.log',
        ),
        'name': 'user_sync_web_hook'
    }
    validators = [basic_auth_web_hook.login_required]

    def populate_request_arguments(self):
        self.action = self.request_args.get('action')
        self.lms_member_id = self.request_args.get('lms_member_id')
        self.value = self.request_args.get('value')
        self.updated = False

    def log_request(self):
        self.sync_log = UserSyncWebhookLog(
            action=self.action,
            lms_member_id=self.lms_member_id,
            value=self.value,
            synced=0
        )
        self.sync_log.insert_record()

    def validate_lms_member_id(self):
        self.user = User.get_active_or_inactive_by_lms_membership_id(self.lms_member_id)
        if not self.user:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                success_flag=True,
                data={},
                message='Member not found'
            )

    def sync_user(self, retry=False):
        """
        Syncs user
        """
        try:
            lms_user_profile = lms_manager.get_lms_user_profile(self.lms_member_id)
            if self.user.lms_status != lms_user_profile['status']:
                self.updated = True
                if lms_user_profile['status'].lower() != 'active':
                    self.user.is_active = 0
                else:
                    self.user.is_active = 1
                self.user.lms_status = lms_user_profile['status']
            if self.user.lms_tier != lms_user_profile['member_tier']:
                self.updated = True
                self.user.lms_tier = lms_user_profile['member_tier']
            if self.updated:
                self.sync_log.synced = 1
                self.sync_log.update_record()
                self.user.update_record()
        except RequestException as re:
            if re.response.status_code == codes.UNAUTHORIZED and retry is False:
                self.sync_user(retry=True)
            self.send_response_flag = True
            message = 'Unable to fetch LMS user details'
            for error in re.response.json().get('errors', []):
                message = error.get('message', message)
                break
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message=message)

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        self.response = self.generate_response_dict(
            success_flag=True,
            data={'updated': self.updated}
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.log_request()
        self.validate_lms_member_id()
        if self.send_response_flag:
            return
        self.sync_user()
        if self.send_response_flag:
            return
        self.set_final_response()
