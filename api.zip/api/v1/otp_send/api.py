"""
Mobile Number Registration API resides here
"""
import datetime
import random

from requests import codes

from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from api.v1.otp_send.validation import otp_send_parser
from common.base_resource import BasePostResource
from common.constants import (
    ADR,
    INVALID_COMPANY,
    OTP_END_RANGE,
    OTP_START_RANGE,
    PHONE_ALREADY_EXISTS
)
from models.aldar_app.otp_history import OtpHistory
from models.aldar_app.user import User
from user_authentication.authentication import get_current_customer
from utils.api_utils import send_sms_to_user
from utils.translation_manager import TranslationManager
from common.api_utils import rate_limit_otp
from common.constants import OTP_EXPIRATION_IN_MINUTES, OTP_RATE_LIMIT_SECONDS


class OTPSendAPI(BasePostResource):
    request_parser = otp_send_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='otp_send_api.log',
        ),
        'name': 'otp_send_api'
    }
    required_token = False

    def populate_request_arguments(self):
        self.msisdn = self.request_args.get('msisdn')
        self.locale = self.request_args.get('language')
        self.company = self.request_args.get('company')

    def initialize_class_attributes(self):
        """
        Initializes class attributes
        """
        self.session_data = get_current_customer()
        self.user_id = self.session_data.get('user_id')

    def verify_company(self):
        """
        Verifies Company
        """
        if not self.company or self.company.lower() != ADR.lower():
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.INVALID_COMPANY,
                    self.locale
                ),
                custom_code=INVALID_COMPANY
            )
            return self.send_response(self.response, self.status_code)

    def verify_phone(self):
        """
        Verify whether phone is registered with another user
        """
        if User.get_count_by_phone(self.msisdn):
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="This mobile number is already registered",
                custom_code=PHONE_ALREADY_EXISTS
            )
            return self.send_response(self.response, self.status_code)

    def generate_otp(self):
        """
        Generates OTP
        """
        self.otp = random.randint(OTP_START_RANGE, OTP_END_RANGE)

    def check_rate_limit_otp(self):
        """
        Rate limit OTP sending
        """
        if rate_limit_otp(self.msisdn):
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.OTP_RESEND_TIME_LIMIT,
                    self.locale
                ).format(OTP_RATE_LIMIT_SECONDS)
            )
            return self.send_response(self.response, self.status_code)

    def add_phone_history(self):
        """
        Adds phone number
        """
        OtpHistory.invalidate_old_otp(self.msisdn)
        otp_history = OtpHistory(
            mobile_no=self.msisdn,
            otp_code=self.otp,
            otp_code_expiry=datetime.datetime.now() + datetime.timedelta(minutes=OTP_EXPIRATION_IN_MINUTES),
            is_verified=0,
            is_active=1
        )
        otp_history.insert_record()

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        data = {}
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.OTP_SENT_MESSAGE,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialize_class_attributes()
        self.verify_company()
        if self.send_response_flag:
            return
        self.verify_phone()
        if self.send_response_flag:
            return
        self.check_rate_limit_otp()
        if self.send_response_flag:
            return
        self.generate_otp()
        send_sms_to_user(self.otp, self.msisdn)
        self.add_phone_history()
        self.generate_final_response()
