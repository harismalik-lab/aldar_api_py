"""
Otp Send API validation
"""

from flask_restful import reqparse
from flask_restful.inputs import regex

from utils.custom_request_parsers import language

from common.constants import EN

otp_send_parser = reqparse.RequestParser(bundle_errors=True)

otp_send_parser.add_argument(
    name="msisdn",
    type=regex(r'^\+(?:[0-9]●?){6,14}[0-9]$'),
    required=True,
    location='json'
)
otp_send_parser.add_argument(
    'language',
    type=language,
    default=EN,
    location='json'
)
otp_send_parser.add_argument(
    'company',
    type=regex(r'^[a-zA-Z]{2,9}'),
    required=True,
    location='json'
)
