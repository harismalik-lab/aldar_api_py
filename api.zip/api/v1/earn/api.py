"""
Earn API
   - validates business category
   - validates business trigger
   - get outlet necessary info for lms doEarn request
   - validates merchant pin
   - get merchant category
   - get user email
   - get payment info : TODO
   - request lms with necessary info
   - returns response
"""
from datetime import datetime

from flask import current_app, request
from requests import codes, RequestException

from api.v1.earn.validation import earn_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.api_utils import get_api_configurations
from common.base_resource import BasePostResource
from common.constants import AED, INVALID_MERCHANT_PIN_ERR_CODE, INVALID_CONCEPT_ID_ERR_CODE, EARN_NOT_ENABLED_ERR_CODE, \
    NO_MAPPING_FOUND, EARNED_DESCRIPTION, CAPTCHA_FAILED_ERR_CODE, ADR
from models.aldar_app.rule import Rule
from models.entertainer_web.merchant_mapping import MerchantMapping
from models.aldar_app.user import User
from models.entertainer_web.merchant import Merchant
from models.entertainer_web.outlet import Outlet
from user_authentication.authentication import get_current_customer
from utils.api_utils import generate_transaction_id
from utils.captcha_v3 import captcha_v3
from utils.lms_manager import lms_manager
from utils.translation_manager import TranslationManager


class EarnApi(BasePostResource):
    request_parser = earn_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='earn_api/earn_api.log',
        ),
        'name': 'earn_api'
    }
    strict_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.concept_id = self.request_args.get('concept_id')
        self.paid_amount = self.request_args.get('paid_amount')
        self.merchant_pin = self.request_args.get('merchant_pin')

        # following param deals with captcha_v3
        self.captcha_token = self.request_args.get('captcha_token')

    def initialize_class_attributes(self):
        """
        Initializes class attributes
        """
        self.session_data = get_current_customer()
        self.customer_id = self.session_data.get('aldar_user_id', 0)
        self.member_id = self.session_data.get('lms_member_id', 0)
        self.email = ''
        self.redemption_reference = generate_transaction_id(self.concept_id)
        self.external_transaction_id = self.redemption_reference
        self.currency = AED
        self.transaction_datetime = datetime.now()
        self.outlet_id = 0
        self.outlet_name = ''
        self.concept_name = ''
        self.description = EARNED_DESCRIPTION
        self.merchant_category = 0
        self.business_trigger = None
        self.business_category = None
        self.earned_points = 0
        self.earn_transaction_id = ''
        self.configs = get_api_configurations(ADR, current_app.config.get('ENV'))
        self.captcha_enabled = self.configs.get(Rule.IS_CAPTCHA_VERIFICATION, False)

    def captcha_validation(self):
        """
        - get `bypass_captcha_token` from request headers.
        - validate key.
        - if validated, set `self.captcha_enabled` False.
        """
        bypass_captcha_token = request.headers.get('bypass_captcha_token')
        if bypass_captcha_token == current_app.config.get('BYPASS_CAPTCHA_TOKEN'):
            self.captcha_enabled = False

    def captcha_verification(self):
        """
        Verify google captcha authentication
            - send token to google's verification url with captcha token
            - returns True/False as verification status
            - if not verified, set `send_response_flag` as `True`
        """
        captcha_verified = False
        if self.captcha_token:
            captcha_verified = captcha_v3.verify_captcha(response=self.captcha_token)
        if not captcha_verified:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message='Bad request please retry',
                custom_code=CAPTCHA_FAILED_ERR_CODE
            )
            return self.send_response(self.response, self.status_code)

    def get_user_info(self):
        """
        Query User model to get user info
        """
        self.user = User.get_active_by_id(self.customer_id)
        self.email = self.user.email

    def get_outlet_info(self):
        """
        query Outlet model to get info
        """
        self.outlet_info = Outlet.get_info_by_concept_id(self.concept_id)
        if not self.outlet_info:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.invalid_concept_id,
                    self.locale
                ),
                custom_code=INVALID_CONCEPT_ID_ERR_CODE
            )
            return self.send_response(self.response, self.status_code)
        # mapping = MerchantMapping.get_category_info_by_merchant_id(self.outlet_info.merchant_id)
        # if not mapping:
        #     self.send_response_flag = True
        #     self.status_code = codes.UNPROCESSABLE_ENTITY
        #     self.response = self.generate_response_dict(custom_code=NO_MAPPING_FOUND)
        #     return
        # if not mapping.is_earn_enabled:
        #     self.send_response_flag = True
        #     self.status_code = codes.UNPROCESSABLE_ENTITY
        #     self.response = self.generate_response_dict(custom_code=EARN_NOT_ENABLED_ERR_CODE)
        #     return
        #
        self.outlet_id = self.outlet_info.id
        self.outlet_name = self.outlet_info.name
        self.concept_name = self.outlet_name

    def validate_merchant_pin(self):
        """
        query Merchant model by id and pin to validate
        """
        merchant = Merchant.get_by_id(self.outlet_info.merchant_id)
        if str(merchant.pin) != self.merchant_pin:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.invalid_merchant_pin,
                    self.locale
                ),
                custom_code=INVALID_MERCHANT_PIN_ERR_CODE
            )
            return self.send_response(self.response, self.status_code)

    def get_merchant_category(self):
        """
        query MerchantMapping model by merchant_id to get merchant_category
        """
        merchant_category_info = MerchantMapping.get_category_info_by_merchant_id(self.outlet_info.merchant_id)
        if not merchant_category_info:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.earn_not_enabled,
                    self.locale
                ),
                custom_code=NO_MAPPING_FOUND
            )
            return self.send_response(self.response, self.status_code)
        if not merchant_category_info.is_earn_enabled:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.earn_not_enabled,
                    self.locale
                ),
                custom_code=EARN_NOT_ENABLED_ERR_CODE
            )
            return self.send_response(self.response, self.status_code)

        self.merchant_category = merchant_category_info.name
        self.business_trigger = merchant_category_info.business_trigger
        self.business_category = merchant_category_info.name

    def get_payment_info(self):
        """
        get payment info for lms doEarn request
        """
        # TODO: clo integration
        pass

    def request_lms_for_earn(self):
        """
        request lms for earn with required data
        """
        try:
            self.lms_response = lms_manager.earn([
                {
                    # for `earn_entry`
                    'aldar_user_id': self.user.id,
                    'description': self.description,

                    "member_id": self.member_id,
                    "email": self.email,
                    "business_category": self.business_category,
                    "business_trigger": self.business_trigger,
                    "concept_id": self.concept_id,
                    "external_transaction_id": self.external_transaction_id,
                    "concept_name": self.concept_name,
                    "gross_total_amount": self.paid_amount,
                    "net_amount": self.paid_amount,
                    "amount_paid_using_points": "0",
                    "paid_amount": self.paid_amount,
                    "currency": AED,
                    "charge_id": "paid_via_app",
                    "transaction_datetime": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),

                    # category `Hospitality` specific info
                    "outlet_id": self.outlet_info.sf_id,
                    "outlet_name": self.outlet_info.name if self.outlet_info.name else 'Not available',
                    "hotel_name": self.outlet_info.hotel if self.outlet_info.hotel else 'Not available',
                    "hotel_id": self.outlet_info.sf_id,
                }
            ])

            if self.lms_response.get('status') != 0:
                self.external_transaction_id = None
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.response = self.generate_response_dict(message=TranslationManager.get_translation(
                    TranslationManager.UNABLE_TO_EARN
                ))
                return
            earned = self.lms_response.get('batch_earn', {}).get('success', [])
            if earned:
                self.earned_points = earned[0].get('earned_points', 0)
                self.earn_transaction_id = earned[0].get('earn_transaction_id')

        except RequestException as re:
            self.external_transaction_id = None
            self.send_response_flag = True
            message = TranslationManager.get_translation(TranslationManager.UNABLE_TO_EARN)
            for error in re.response.json().get('errors', []):
                message = error.get('message', message)
                break
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message=message)

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        data = {
            "transaction_number": self.earn_transaction_id,
            'earned_points': self.earned_points
        }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialize_class_attributes()
        self.captcha_validation()
        if self.captcha_enabled:
            self.captcha_verification()
            if self.send_response_flag:
                return
        self.get_outlet_info()
        if self.send_response_flag:
            return
        self.validate_merchant_pin()
        if self.send_response_flag:
            return
        self.get_merchant_category()
        if self.send_response_flag:
            return
        self.get_user_info()
        self.get_payment_info()
        self.request_lms_for_earn()
        if self.send_response_flag:
            return
        self.set_final_response()
