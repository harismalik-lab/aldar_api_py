"""
Earn API validation
"""
from flask_restful import reqparse

from common.constants import EN
from utils.custom_request_parsers import language, check_positive

earn_parser = reqparse.RequestParser(bundle_errors=True)

earn_parser.add_argument(
    'concept_id',
    type=str,
    location='json',
    required=True
)
earn_parser.add_argument(
    'paid_amount',
    type=check_positive,
    location='json',
    required=True
)
earn_parser.add_argument(
    'merchant_pin',
    type=str,
    location='json',
    required=True
)
earn_parser.add_argument(
    'language',
    type=language,
    default=EN,
    location='json'
)
earn_parser.add_argument(
    'captcha_token',
    type=str,
    location='json'
)
