"""
Register User API
"""
import datetime
import time
import uuid

from flask import current_app
from jwt import encode
from phpserialize import dumps as php_json_dumps
from requests import codes, RequestException

from api.v1.register_user.validation import register_user_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.api_utils import generate_member_code
from common.base_resource import BasePostResource
from common.constants import (
    FIRST_TIME_REGISTRATION_REQUIRED_AND_TRUE_FIELDS,
    FIRST_TIME_REGISTRATION_REQUIRED_FIELDS,
    MISMATCH_PASSWORDS,
    PASSWORD_CHANGE_FLOW_REQUIRED,
    TIER_BRONZE,
    USER_INACTIVE, ADR
)
from models.aldar_app.user import User
from models.aldar_app.users_password_history import UsersPasswordHistory
from models.consolidation.ent_customer_profile import EntCustomerProfile
from models.consolidation.ent_send_email import EntSendEmail
from models.consolidation.user import User as consolidation_user
from models.entertainer_web.session import Session
from models.entertainer_web.session_addendum import SessionAddendum
from models.entertainer_web.wl_product import WlProduct
from models.entertainer_web.wl_user_group import WlUserGroup
from models.entertainer_web.wlvalidation import Wlvalidation
from user_authentication.authentication import get_jw_token_identity, get_current_customer
from utils.api_utils import get_user_tier_dict
from utils.lms_manager import lms_manager
from utils.security import security
from utils.translation_manager import TranslationManager


class RegisterUser(BasePostResource):
    request_parser = register_user_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='register_user/register_user_api.log',
        ),
        'name': 'register_user_api'
    }
    required_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.first_name = self.request_args.get('first_name')
        self.last_name = self.request_args.get('last_name')
        self.email = self.request_args.get('email')
        self.password = self.request_args.get('password')
        self.confirm_password = self.request_args.get('confirm_password')
        self.country = self.request_args.get('country_of_residence')
        self.locale = self.request_args.get('language')
        self.dob = self.request_args.get('dob')
        self.gender = self.request_args.get('gender')
        self.nationality = self.request_args.get('nationality')
        # TODO: Check all args below this
        self.terms_and_conditions = self.request_args.get('terms_and_conditions')
        self.enable_email_notification = self.request_args.get('enable_email_notification')
        self.enable_push_notification = self.request_args.get('enable_push_notification')

        self.gdpr_privacy_policy = self.request_args.get('gdpr_privacy_policy')
        self.referrer_id = self.request_args.get('referrer_id', '')

        self.device_id = self.request_args.get('device_uid')
        self.device_model = self.request_args.get('device_model')
        self.device_os = self.request_args.get('device_os')
        self.lng = self.request_args.get('lng')
        self.lat = self.request_args.get('lat')
        self.platform = self.request_args.get('__platform')
        if not self.platform:
            self.platform = self.request_args.get('platform')
        self.device_key = self.request_args.get('device_key')

    def initialize_class_attributes(self):
        """
        Initializes class attributes
        """
        self.jwt_data = get_jw_token_identity()
        self.customer_data = get_current_customer()
        self.user = None
        self.is_first_time = False
        self.et_user = None
        self.jwt = None
        self.wl_company = ADR
        self.consolidation_user_id = None
        self.notifications_updated = False
        self.session_token = None
        self.country_updated = False

    def validate_jwt_data(self):
        if self.jwt_data and isinstance(self.jwt_data, dict) and self.jwt_data.get('user_id'):
            self.user_id = self.jwt_data.get('user_id', 0)
        elif self.customer_data and self.customer_data.get('aldar_user_id'):
            self.user_id = self.customer_data['aldar_user_id']
        else:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Expected 'user_id' is not provided."
            )
            return self.send_response(self.response, self.status_code)

    def validate_email(self):
        """
        Validates Email
        """
        self.user = User.get_active_by_id(self.user_id)
        if not self.user:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.USER_INACTIVE,
                    self.locale
                ),
                custom_code=USER_INACTIVE
            )
            return self.send_response(self.response, self.status_code)
        if self.email and (self.user.email or '').lower() != self.email.lower():
            if User.get_count_by_email(self.email):
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.response = self.generate_response_dict(
                    message=TranslationManager.get_translation(
                        TranslationManager.EMAIL_ALREADY_EXISTS,
                        self.locale
                    )
                )
                return self.send_response(self.response, self.status_code)

    def validate_first_time_registration(self):
        """
        Validates whether user is doing first time registration
        """
        if self.user.password is None:  # Fist time registration
            self.is_first_time = True

            missing_field = None
            false_field = None
            for _r_field in FIRST_TIME_REGISTRATION_REQUIRED_AND_TRUE_FIELDS:
                field_value = self.request_args.get(_r_field)
                if field_value is None:
                    missing_field = _r_field
                elif field_value != 1:
                    false_field = _r_field
                if any([missing_field, false_field]):
                    error_message = "Missing required field '{}'".format(
                        missing_field) if missing_field else "False value of field '{}'".format(false_field)

                    self.send_response_flag = True
                    self.status_code = codes.UNPROCESSABLE_ENTITY
                    self.response = self.generate_response_dict(
                        message=error_message
                    )
                    return self.send_response(self.response, self.status_code)

            if not all([self.first_name, self.last_name, self.email, self.password, self.confirm_password]):
                missing_field = None
                for _r_field in FIRST_TIME_REGISTRATION_REQUIRED_FIELDS:
                    if not self.request_args.get(_r_field):
                        missing_field = _r_field
                        break
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.response = self.generate_response_dict(
                    message="Missing required field '{}'".format(missing_field)
                )
                return self.send_response(self.response, self.status_code)

        if self.password:
            if self.user.password is not None:
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.response = self.generate_response_dict(
                    message=TranslationManager.get_translation(
                        TranslationManager.UNABLE_TO_CHANGE_RESOURCE,
                        self.locale
                    ).format('password'),
                    custom_code=PASSWORD_CHANGE_FLOW_REQUIRED
                )
                return self.send_response(self.response, self.status_code)
            if self.password != self.confirm_password:
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.response = self.generate_response_dict(
                    message=TranslationManager.get_translation(
                        TranslationManager.PASSWORD_MISMATCH,
                        self.locale
                    ),
                    custom_code=MISMATCH_PASSWORDS
                )
                return self.send_response(self.response, self.status_code)
            self.user.password = security.generate_password_hash(self.password)
        # create an entry in users password history table
        if self.password and self.is_first_time:
            insert_user_password_history = UsersPasswordHistory(
                user_id=self.user.id,
                email=self.email,
                password=security.generate_password_hash(self.password),
                created_at=datetime.datetime.now()
            )
            insert_user_password_history.insert_record()

    def set_et_user_id(self):
        """
        Set et_user_id of aldar user by creating a user in consolidation or by get the id of existing one.
        :return:
        """
        self.et_user = consolidation_user.find_active_user_by_email(email=self.email)
        if self.et_user:
            self.user.et_user_id = self.et_user.id
        else:
            try:
                self.register_et_user()
            except Exception as e:
                self.logger.error("Unable to register ET User: {}".format(e))
                raise Exception("Oops! something went wrong please try again later.")
            self.user.et_user_id = self.et_user.id
        self.consolidation_user_id = self.et_user.id

    def register_et_user(self):
        """
        Registers ET User against Aldar user
        """
        if self.is_first_time:
            self.et_user = consolidation_user(
                auth_key=security.generate_random_key().encode('utf-8'),
                password_hash=security.generate_password_hash(self.password),
                email=self.email,
                username=self.email,
                first_name=self.first_name if self.first_name else None,
                last_name=self.last_name if self.last_name else None
            )
            self.et_user.insert_record()

            self.ent_customer_profile = EntCustomerProfile(
                user_id=self.et_user.id,
                email=self.email,
                membership_code=generate_member_code(self.country, self.et_user.id),
                onboarding_status=EntCustomerProfile.ONBOARDING_FINISHED,
                accepted_terms=self.terms_and_conditions,
                receive_email=self.enable_email_notification,
            )
            if self.first_name:
                self.ent_customer_profile.firstname = self.first_name
            if self.last_name:
                self.ent_customer_profile.lastname = self.last_name
            if self.gender:
                self.ent_customer_profile.gender = self.gender
            # if self.mobile_phone:
            #     self.ent_customer_profile.mobile_phone = self.user.mobile_no
            # if self.nationality:
            #     self.ent_customer_profile.nationality = self.nationality
            # if self.country:
            #     self.ent_customer_profile.country_of_residence = self.country
            # TODO: Verify dob
            if self.dob:
                self.ent_customer_profile.birthdate = self.dob
            self.ent_customer_profile.insert_record()

    def update_aldar_user_profile(self):
        """
        Update aldar user profile data
        """
        if self.is_first_time:
            if self.first_name:
                self.user.first_name = self.first_name
            if self.last_name:
                self.user.last_name = self.last_name
            if self.email:
                self.user.email = self.email
        if self.country is not None:
            self.user.country_of_residence = self.country
            self.country_updated = True
        if self.nationality is not None:
            self.user.nationality = self.nationality
        if self.dob and not self.user.date_of_birth:
            self.user.date_of_birth = self.dob
        if self.gender is not None:
            self.user.gender = self.gender.lower()
        if self.enable_push_notification is not None:
            self.user.enable_push_notification = self.enable_push_notification
            self.notifications_updated = True
        if self.enable_email_notification is not None:
            self.user.enable_email_notification = self.enable_email_notification
            self.notifications_updated = True
        if self.referrer_id:
            self.user.referrer_member_id = self.referrer_id

        self.user.update_record()

    def create_session(self):
        """
        Creates Session and JWT
        :return:
        """
        self.user_group_ids = Wlvalidation.get_user_groups(self.wl_company, self.consolidation_user_id)
        user_groups = self.user_group_ids
        if not user_groups:
            user_groups = [WlUserGroup.DEFAULT_USER_GROUP]
        product_ids = WlProduct.get_configured_product_ids(self.wl_company, user_groups)
        # noinspection PyArgumentList
        session = Session(
            session_token=str(uuid.uuid4()),
            customer_id=self.consolidation_user_id,
            product_ids=','.join(map(str, product_ids)),
            company=self.wl_company,
            isagreed=True,
            date_cached=time.time(),
            date_agreed=datetime.datetime.now()
        )
        session.insert_record()
        self.jwt = encode(
            {
                'session_token': session.session_token,
                'api_token': current_app.config.get('ALDAR_API_TOKEN')
            }, current_app.config['JWT_SECRET_KEY'], algorithm='HS256'
        )
        self.session_token = session.session_token
        self.session_id = session.id

    def create_session_addendum(self):
        """
        create session addendum record
        """
        session_addendum = SessionAddendum(
            session_id=self.session_id,
            user_id=self.consolidation_user_id,
            device_key=self.device_key,
            device_os=self.platform,
            device_model=self.device_model,
            device_language=self.locale,
            lat=self.lat,
            lng=self.lng,
            company=self.wl_company,
            is_eula_agreed=1,
            is_gdpr_agreed=1
        )
        session_addendum.insert_record()

    def get_user_profile(self):
        """
        Gets user profile
        """
        if self.user:
            self.user_profile = self.user.json()
            # self.user_profile.update(self.user.json())
        else:
            self.user_profile = {}

    def get_user_tier(self):
        """
        Gets user tier
        """
        if self.user and self.user.lms_membership_id:
            self.user_tier = get_user_tier_dict(self.user.lms_membership_id)
        else:
            self.user_tier = {}

    def send_email(self):
        """
        Inserts a row in ent_send_email, cron will handle the actual email sending part
        """
        self.email_data_optional = {
            '{FIRST_NAME}': self.user.first_name,
            '{LAST_NAME}': self.user.last_name,
            '{PHONE_NUMBER}': self.user.mobile_no,
            '{EMAIL}': self.user.email,
        }
        self.email_data = {}

        ent_send_email = EntSendEmail(
            email_to=self.user.email,
            email_template_type_id=current_app.config['WELCOME_EMAIL_TEMPLATE_ID'],
            email_template_data=php_json_dumps(self.email_data).decode(errors="ignore"),
            optional_data=php_json_dumps(self.email_data_optional).decode(errors="ignore"),
            language=self.locale,
            priority=EntSendEmail.PRIORITY_HIGH
        )
        ent_send_email.insert_record()

    def update_user_on_lms(self):
        """
        Updates demographics on lms
        """
        if self.gender and self.nationality and self.dob:
            lms_manager.update_lms_user(self.user.lms_membership_id, self.gender, self.nationality, self.dob)
        elif self.country:
            lms_manager.update_lms_user_country_of_residence(self.user.lms_membership_id, self.country)

    def create_user_on_lms(self):
        """
        Create user on LMS
        """
        if not self.user.lms_membership_id:
            lms_kwargs = {
                'external_user_id': self.user.id,
                'first_name': self.user.first_name,
                'last_name': self.user.last_name,
                'mobile_number': self.user.mobile_no,
                'email': self.user.email,
                'membership_number': self.user.membership_id,
                "registration_date": datetime.datetime.now(),
                "referrer_member_id": self.referrer_id
            }
            try:
                self.lms_user_profile = lms_manager.register_user(**lms_kwargs) or {}
                self.user.lms_membership_id = self.lms_user_profile.get('member_id')
                self.user.lms_status = self.lms_user_profile.get('status')
                self.user.lms_tier = self.lms_user_profile.get('member_tier', TIER_BRONZE)
                self.user.update_record()
            except RequestException as r_e:
                errors = r_e.response.json().get('errors')
                message = "Something went wrong."
                for error in errors:
                    message = 'invalid "{}"'.format(error.get('field_name', "") or error.get('message', ""))
                    break
                self.response = self.generate_response_dict(message=message)
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.user.password = None
                self.user.update_record()
            except Exception as e:
                self.logger.exception('Exception on LMS user creation: {}'.format(e))
                self.response = self.generate_response_dict(message='Something went wrong, please retry.')
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.user.password = None
                self.user.update_record()

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        data = {
            'user_profile': self.user_profile,
            'user_tier': self.user_tier
        }
        if self.jwt:
            data['auth'] = {
                'access_token': self.jwt.decode(),
                'analytics_token': self.session_token
            }
        if self.notifications_updated:
            message = TranslationManager.get_translation(
                TranslationManager.SETTINGS_UPDATED,
                self.locale
            )
        if self.country_updated:
            message = TranslationManager.get_translation(
                TranslationManager.COUNTRY_UPDATED,
                self.locale
            )
        else:
            message = TranslationManager.get_translation(
                TranslationManager.PROFILE_UPDATED_SUCCESSFULLY,
                self.locale
            )
        self.response = self.generate_response_dict(
            message=message,
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialize_class_attributes()
        self.validate_jwt_data()
        if self.send_response_flag:
            return
        self.validate_email()
        if self.send_response_flag:
            return
        self.validate_first_time_registration()
        if self.send_response_flag:
            return
        self.update_aldar_user_profile()
        if self.is_first_time:
            self.set_et_user_id()
            self.create_user_on_lms()
            if self.send_response_flag:
                return
            self.create_session()
            self.create_session_addendum()
            self.send_email()
        else:
            self.update_user_on_lms()
        self.get_user_profile()
        self.get_user_tier()
        self.set_final_response()
