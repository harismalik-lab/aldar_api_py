"""
Register User API Validation
"""

from flask_restful import reqparse
from flask_restful.inputs import regex

from common.constants import EN
from utils.custom_request_parsers import date_validator, email, language, validate_gender, boolean, \
    device_list_for_sign_up

register_user_parser = reqparse.RequestParser(bundle_errors=True)

register_user_parser.add_argument(
    'language',
    type=language,
    default=EN,
    location='json'
)
register_user_parser.add_argument(
    'first_name',
    type=regex(r'[a-zA-Z-.]+'),
    location='json',
)
register_user_parser.add_argument(
    'last_name',
    type=regex(r'[a-zA-Z-.]+'),
    location='json',
)
register_user_parser.add_argument(
    'password',
    type=regex(r"^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[~}|{'\"`_^\]\\@\[?>=<;:/.\-,+*\)\(&%$#!]).*$"),
    location='json',
    help="Password must have min length of 8, contains at least 1 one upper alphabetic character, "
         "at least one lower alphabetic character, "
         "at least one numeric letter and "
         "at least one special character in it."
)
register_user_parser.add_argument(
    'confirm_password',
    type=regex(r"^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[~}|{'\"`_^\]\\@\[?>=<;:/.\-,+*\)\(&%$#!]).*$"),
    location='json',
    help="Password must have min length of 8, contains at least 1 one upper alphabetic character, "
         "at least one lower alphabetic character, "
         "at least one numeric letter and "
         "at least one special character in it."
)
register_user_parser.add_argument(
    'email',
    type=email,
    location='json'
)
register_user_parser.add_argument(
    'country_of_residence',
    type=str,
    location='json'
)
register_user_parser.add_argument(
    'dob',
    type=date_validator,
    location='json'
)
register_user_parser.add_argument(
    'gender',
    type=validate_gender,
    location='json'
)
register_user_parser.add_argument(
    'nationality',
    type=str,
    required=False,
    location='json'
)
register_user_parser.add_argument(
    'gdpr_privacy_policy',
    type=int,
    required=False,
    location='json'
)
register_user_parser.add_argument(
    'terms_and_conditions',
    type=int,
    required=False,
    location='json'
)
register_user_parser.add_argument(
    'enable_email_notification',
    type=boolean,
    default=True,
    required=False,
    location='json'
)
register_user_parser.add_argument(
    'enable_push_notification',
    type=boolean,
    default=True,
    required=False,
    location='json'
)
register_user_parser.add_argument(
    'referrer_id',
    type=str,
    location='json',
)
register_user_parser.add_argument(
    'platform',
    type=regex('[a-zA-Z]*'),
    required=False,
    location='json'
)
register_user_parser.add_argument(
    '__platform',
    type=regex('[a-zA-Z]*'),
    required=False,
    location='json'
)
register_user_parser.add_argument(
    'lat',
    type=str,
    required=False,
    default=0,
    location='json'
)
register_user_parser.add_argument(
    'lng',
    type=str,
    required=False,
    default=0,
    location='json'
)
register_user_parser.add_argument(
    'device_key',
    type=str,
    required=False,
    location='json'
)
register_user_parser.add_argument(
    'device_os',
    type=device_list_for_sign_up,
    required=False,
    location='json'
)
register_user_parser.add_argument(
    'device_model',
    type=str,
    required=False,
    location='json'
)
register_user_parser.add_argument(
    'device_uid',
    type=str,
    required=False,
    location='json'
)
