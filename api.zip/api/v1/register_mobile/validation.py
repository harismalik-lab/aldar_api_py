"""
Register Mobile API Validation
"""

from flask_restful import reqparse
from flask_restful.inputs import regex

from common.constants import EN
from utils.custom_request_parsers import language

register_mobile_parser = reqparse.RequestParser(bundle_errors=True)

register_mobile_parser.add_argument(
    name="msisdn",
    type=regex(r'^\+(?:[0-9]●?){6,14}[0-9]$'),
    required=True,
    location='json',
    help="Invalid mobile number"
)
register_mobile_parser.add_argument(
    'language',
    type=language,
    default=EN,
    location='json'
)
register_mobile_parser.add_argument(
    'otp',
    type=int,
    required=False,
    location='json'
)
register_mobile_parser.add_argument(
    'company',
    type=regex(r'^[a-zA-Z]{2,9}'),
    required=False,
    location='json'
)
register_mobile_parser.add_argument(
    'captcha_token',
    type=str,
    required=False,
    location='json',
    default=''
)
