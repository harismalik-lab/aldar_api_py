"""
Registers Mobile Phone

`RegisterMobileApi` has two purposes:
1 - generate `otp` for first time registration.
    *  validate `company` in request params.
    *  `generate_otp`.
        * check if user exists with given `msisdn`.
            * Fail case -> returns `"user_exists": True`
    * `check_rate_limit_otp`
    * send otp via sms to user
    * `add_otp_history`
2 - `otp` verification.
    * verify `otp` and mobile number
    * register `user` in `aldar_app.user` db.
    * generates jwt
    * returns `access_token` in response.

"""
import datetime
import random

from flask import current_app, request
from jwt import encode
from luhn import generate
from requests import codes

from api.v1.register_mobile.validation import register_mobile_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.api_utils import rate_limit_otp, get_api_configurations
from common.base_resource import BasePostResource
from common.constants import (
    INVALID_COMPANY,
    OTP_RELATED_ISSUE,
    OTP_EXPIRATION_IN_MINUTES,
    OTP_RATE_LIMIT_SECONDS,
    OTP_START_RANGE,
    OTP_END_RANGE,
    CAPTCHA_FAILED_ERR_CODE)
from models.aldar_app.otp_history import OtpHistory
from models.aldar_app.rule import Rule
from models.aldar_app.user import User
from models.entertainer_web.wl_company import WlCompany
from utils.api_utils import send_sms_to_user
from utils.captcha_v3 import captcha_v3
from utils.translation_manager import TranslationManager


class RegisterMobileAPI(BasePostResource):
    request_parser = register_mobile_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='register_mobile_api/register_mobile_api.log',
        ),
        'name': 'register_mobile_api'
    }
    required_token = False

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.msisdn = self.request_args.get('msisdn')
        self.locale = self.request_args.get('language')
        self.otp_api = self.request_args.get('otp')
        self.company = self.request_args.get('company')

        # following param deals with captcha_v3
        self.captcha_token = self.request_args.get('captcha_token')

    def initialize_class_attributes(self):
        """
        Initializes class attributes
        """
        self.jwt = None
        self.otp_sent = False
        self.otp = None
        self.user_exists = False
        self.user = None
        self.configs = get_api_configurations(self.company, current_app.config.get('ENV'))
        self.captcha_enabled = self.configs.get(Rule.IS_CAPTCHA_VERIFICATION, False)

    def captcha_validation(self):
        """
        - get `bypass_captcha_token` from request headers.
        - validate key.
        - if validated, set `self.captcha_enabled` False.
        """
        bypass_captcha_token = request.headers.get('bypass_captcha_token')
        if bypass_captcha_token == current_app.config.get('BYPASS_CAPTCHA_TOKEN'):
            self.captcha_enabled = False

    def set_invalid_otp_response(self):
        """
        Sets Invalid OTP response
        """
        self.send_response_flag = True
        self.status_code = codes.UNPROCESSABLE_ENTITY
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.INVALID_OTP,
                self.locale
            ),
            custom_code=OTP_RELATED_ISSUE
        )
        return self.send_response(self.response, self.status_code)

    def verify_company(self):
        """
        Verifies Company
        """
        if not self.company:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message='Missing required parameter "company".',
                custom_code=INVALID_COMPANY
            )
            return self.send_response(self.response, self.status_code)
        self.company = WlCompany.get_active_by_code(self.company)
        if not self.company:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.INVALID_COMPANY,
                    self.locale
                ),
                custom_code=INVALID_COMPANY
            )
            return self.send_response(self.response, self.status_code)

    def generate_otp(self):
        """
        Generates OTP
        """
        user = User.get_count_by_phone(self.msisdn)
        if not user:
            self.otp = random.randint(OTP_START_RANGE, OTP_END_RANGE)
        else:
            self.user_exists = True

    def check_rate_limit_otp(self):
        """
        Rate limit OTP sending
        """
        if rate_limit_otp(self.msisdn):
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.OTP_RESEND_TIME_LIMIT,
                    self.locale
                ).format(OTP_RATE_LIMIT_SECONDS)
            )
            return self.send_response(self.response, self.status_code)

    def captcha_verification(self):
        """
        Verify google captcha authentication
            - send token to google's verification url with captcha token
            - returns True/False as verification status
            - if not verified, set `send_response_flag` as `True`
        """
        captcha_verified = False
        if self.captcha_token:
            captcha_verified = captcha_v3.verify_captcha(response=self.captcha_token)
        if not captcha_verified:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message='Bad request please retry',
                custom_code=CAPTCHA_FAILED_ERR_CODE
            )
            return self.send_response(self.response, self.status_code)

    def add_otp_history(self):
        """
        Adds phone number
        """
        if self.otp:
            OtpHistory.invalidate_old_otp(self.msisdn)
            otp_history = OtpHistory(
                mobile_no=self.msisdn,
                otp_code=self.otp,
                otp_code_expiry=datetime.datetime.now() + datetime.timedelta(minutes=OTP_EXPIRATION_IN_MINUTES),
                is_verified=0,
                is_active=1
            )
            otp_history.insert_record()
            self.otp_sent = True

    def verify_otp_and_phone(self):
        """
        Verifies OTP and Phone
        """
        if self.msisdn and self.otp_api is not None:
            self.otp_history = OtpHistory.get_by_otp_and_phone(self.otp_api, self.msisdn)
            if not self.otp_history:
                return self.set_invalid_otp_response()
            if datetime.datetime.now() >= self.otp_history.otp_code_expiry:
                return self.set_invalid_otp_response()
            self.otp_history.is_verified = OtpHistory.OTP_VERIFIED
            self.otp_history.is_active = 0
            self.otp_history.activation_date = datetime.datetime.now()
            self.otp_history.update_record()

    def register_user(self):
        """
        Registers a new User with verified phone
        """
        self.user = User.get_active_by_phone_pending_registration(self.msisdn)
        if self.user:
            pass
        else:
            membership_id = '{}{}'.format(
                self.msisdn.lstrip('+')[0:2],
                random.randint(100000000000, 999999999999)
            )
            luhn_checksum = generate(membership_id)
            membership_id = '{}{}'.format(membership_id, luhn_checksum)
            luhn_checksum = generate(membership_id)
            membership_id = '{}{}'.format(membership_id, luhn_checksum)
            self.user = User(
                mobile_no=self.msisdn,
                is_active=1,
                is_phone_verified=1,
                membership_id=membership_id
            )
            self.user.insert_record()

    def generate_jwt(self):
        """
        Generates JWT
        """
        api_token = current_app.config.get('ALDAR_API_TOKEN')
        secret_key = current_app.config.get('JWT_SECRET_KEY')
        self.jwt = encode(
            {
                'api_token': api_token,
                'user_id': self.user.id
            }, secret_key, algorithm='HS256'
        )

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        if self.user:
            data = {
                'auth': {
                    'access_token': self.jwt.decode()
                }
            }
        else:
            data = {
                'otp_sent': self.otp_sent,
                'user_exists': self.user_exists
            }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialize_class_attributes()
        self.captcha_validation()
        if self.msisdn and self.otp_api is None:
            self.verify_company()
            if self.send_response_flag:
                return
            self.generate_otp()
            if not self.user_exists:
                self.check_rate_limit_otp()
                if self.send_response_flag:
                    return
                if self.captcha_enabled:
                    self.captcha_verification()
                    if self.send_response_flag:
                        return
                send_sms_to_user(self.otp, self.msisdn)
                self.add_otp_history()
        elif self.msisdn and self.otp_api is not None:
            if self.captcha_enabled:
                self.captcha_verification()
                if self.send_response_flag:
                    return
            self.verify_otp_and_phone()
            if self.send_response_flag:
                return
            self.register_user()
            self.generate_jwt()
        self.set_final_response()
