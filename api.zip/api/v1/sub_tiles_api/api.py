"""
Sub Tiles API
Returns tiles against section identifier
"""

from requests import codes

from api.v1.sub_tiles_api.utils import get_tiles_by_section_identifier
from api.v1.sub_tiles_api.validation import sub_tiles_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from common.constants import ADR, EXPERIENCES_TITLE, YAS_ISLAND_TITLE, SUB_CATEGORIES
from utils.translation_manager import TranslationManager


class SubTilesAPI(BasePostResource):
    request_parser = sub_tiles_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='sub_tiles/sub_tiles.log',
        ),
        'name': 'sub_tiles'
    }
    required_token = False

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.company = ADR

    def initialize_local_veriables(self):
        """
        Initializes local veriables
        """
        self.sections = []

    def get_section_identifier(self, **kwargs):
        """
        Get section identifier
        """
        self.section_identifier = kwargs.get('section_identifier')

    def set_sub_tiles(self):
        """
        Set sub tiles
        """
        tiles = get_tiles_by_section_identifier(self.locale, self.company, self.section_identifier)
        section_items = []
        self.title = EXPERIENCES_TITLE
        self.show_all_link = ''
        if tiles:
            self.title = tiles[0].link_type
            self.show_all_link = tiles[0].entity_type
        for tile in tiles:
            tile_dict = {
                "id": tile.id,
                "title": tile.title,
                "image_url": tile.image_url,
                "deeplink": tile.deep_link,
            }
            section_items.append(tile_dict)
        self.sections.append(
            {
                "section_identifier": SUB_CATEGORIES,
                "title": self.title if self.title else "",
                "section_items": section_items,
                "show_all_offers": 0,
                "deeplink": "aldar://dummy",
                "show_all_deeplink": self.show_all_link if self.show_all_link else "",
                "show_all_text": "See All Offers" if self.show_all_link else ""
            }
        )

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        data = {
            'title': self.title,
            'sections': self.sections
        }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables()
        self.get_section_identifier(**kwargs)
        self.set_sub_tiles()
        self.generate_final_response()
