"""
Subtiles Util methods
"""

from flask import g

from models.entertainer_web.home_screen_configurations import HomeScreenConfiguration

cache = g.cache


@cache.memoize(timeout=1800)
def get_tiles_by_section_identifier(locale, company, section_identifier):
    """
    Tiles by section identifier

    :param section_identifier:
    :param locale: Locale
    :param company: company
    :return:
    """
    tiles = HomeScreenConfiguration.get_tiles_by_section_identifier(
        section_identifier=section_identifier,
        company=company,
        locale=locale
    )
    return tiles
