import copy
import json
import math

from _md5 import md5
from operator import itemgetter
from datetime import datetime, timedelta

from api.v1.merchant_details.constants import (
    ATTRIBUTE_VALUE_TYPE_TERNARY, ATTRIBUTE_VALUE_NO, ATTRIBUTE_VALUE_YES, ATTRIBUTE_VALUE_OUTLET_SPECIFIC,
    ATTRIBUTE_VALUE_TYPE_VALUE, FINE_DINING_DRESS_CODE_TRANSLATION, CUISINE, DRESS_CODE, FINE_DINING,
    ANALYTICS_CATEGORY_CODES_DICT, OFFER_TYPE_VALUE_DEFAULT, OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE,
    OFFER_TYPE_VALUE_PERCENTAGE_OFF, OFFER_TYPE_VALUE_GIFT, OFFER_TYPE_VALUE_PACKAGE, OFFER_TYPE_VALUE_FIX_PRICE_OFF,
    OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS, IMAGE_TYPE_VOUCHER_TYPE, CATEGORY_API_NAME_BODY, CATEGORY_API_NAME_LEISURE,
    CATEGORY_API_NAME_RESTAURANTS_AND_BARS, CATEGORY_API_NAME_RETAIL, CATEGORY_API_NAME_SERVICES,
    CATEGORY_API_NAME_TRAVEL, VOUCHER_TYPE_IMAGE_URL_PREFIX, VOUCHER_TYPE_IMAGE_URL_PREFIX_HS,
    ANALYTICS_CATEGORY_CODE_TRAVEL, VOUCHER_RESTRICTION_IMAGE_URL_PREFIX, IMAGE_TYPE_VOUCHER_RESTRICTION,
    IMAGE_TYPE_PARTY_SIZE, PARTY_SIZE_IMAGE_URL_PREFIX, VOUCHER_RESTRICTIONS, SORT_EXPIRED, SECTION_REDEEMABLE,
    SECTION_REDEEMED, SECTION_NOT_REDEEMABLE, SORT_PURCHASED_AVAILABLE_IN_FUTURE, SORT_REDEEMABLE, SORT_REDEEMED,
    SORT_NOT_REDEEMABLE, COLOR_CODE_ALREADY_REDEEMED, ANALYTICS_CATEGORY_CODE_BODY, ANALYTICS_CATEGORY_CODE_LEISURE,
    ANALYTICS_CATEGORY_CODE_RESTAURANTSANDBARS, ANALYTICS_CATEGORY_CODE_RETAIL, ANALYTICS_CATEGORY_CODE_SERVICES,
    CATEGORY_API_NAME_KIDS, TYPE_MEMBER
)
from common.constants import EN, SUPPORTED_LOCALES, ADR
from models.entertainer_web.delivery_menu_items import DeliveryMenuItem
from models.entertainer_web.merchant_attributes_body import MerchantAttributesBody
from models.entertainer_web.merchant_attributes_fashion_and_retail import MerchantAttributesFashionAndRetail
from models.entertainer_web.merchant_attributes_kids import MerchantAttributesKid
from models.entertainer_web.merchant_attributes_leisure import MerchantAttributesLeisure
from models.entertainer_web.merchant_attributes_restaurants_and_bars import MerchantAttributesRestaurantsAndBar
from models.entertainer_web.merchant_attributes_services import MerchantAttributesService
from models.entertainer_web.merchant_attributes_travel import MerchantAttributesTravel
from models.entertainer_web.offer_wl_active import OfferWlActive
from models.entertainer_web.redemption import Redemption
from models.entertainer_web.wl_company import WlCompany
from utils.api_utils import multi_key_sort, calculate_redeemability, user_redemptions_lookup_hash

from utils.translation_manager import TranslationManager

from models.entertainer_web.category import Category
from models.entertainer_web.merchant import Merchant


def orm_objects_to_dict(queryset):
    """
    convert a queryset (contains more than one objs) into dict
    :param orm queryset:
    :return dict:
    """
    dict_result = []
    if queryset:
        for element in queryset:
            dict_result.append(element._asdict())
    return dict_result


def get_merchant_attributes_by_category(category, locale=EN):
    """
    1. gets merchant attribute groups
    2. gets merchant attributes
    3. Returns merchant attributes by category
    :param int category:
    :param str locale:
    :return dict merchant_attributes_by_group:
    """
    merchant_attribute_groups_dict = []
    merchant_attribute_dict = {}

    merchant_attribute_groups = Category.get_merchant_attribute_groups(category, locale)
    if merchant_attribute_groups:
        merchant_attribute_groups_dict = orm_objects_to_dict(merchant_attribute_groups)

    merchant_attribute = Category.get_merchant_attributes(category, locale)
    if merchant_attribute:
        merchant_attribute_dict = orm_objects_to_dict(merchant_attribute)

    merchant_attributes_by_group = []
    hashed_merchant_attributes = {}
    if merchant_attribute_groups_dict and merchant_attribute_dict:
        for merchant_attribute in merchant_attribute_dict:
            key = merchant_attribute["merchant_attribute_group_id"]
            del merchant_attribute["merchant_attribute_group_id"]
            if hashed_merchant_attributes.get(key):
                hashed_merchant_attributes[key].append(merchant_attribute)
            else:
                hashed_merchant_attributes.update({key: [merchant_attribute]})

        for filter_group in merchant_attribute_groups_dict:
            attributes = hashed_merchant_attributes.get(filter_group['id'])
            if attributes:
                group = dict()
                group['section_name'] = filter_group['name']
                group['attributes'] = attributes
                merchant_attributes_by_group.append(group)
    return merchant_attributes_by_group


def get_merchant_attribute_translation_for_value(value, attribute_type, locale=EN):
    """
    Gets merchant attribute translation
    :param value: value
    :param attribute_type: attribute type
    :param locale: locale
    :return: attribute value
    """
    translation_manager = TranslationManager()
    if not value:
        return ""
    if attribute_type == ATTRIBUTE_VALUE_TYPE_TERNARY:
        if value == ATTRIBUTE_VALUE_NO:
            message = translation_manager.get_translation(
                translation_manager.NO,
                locale
            )
            return message
        elif value == ATTRIBUTE_VALUE_YES:
            message = translation_manager.get_translation(
                translation_manager.YES,
                locale
            )
            return message
        elif value == ATTRIBUTE_VALUE_OUTLET_SPECIFIC:
            message = translation_manager.get_translation(
                translation_manager.OUTLET_SPECIFIC,
                locale
            )
            return message
    elif attribute_type == ATTRIBUTE_VALUE_TYPE_VALUE:
        return value


def format_merchant_attributes(merchant_id, merchant_attributes, merchant_category, locale=EN, company=''):
    """
    Formats merchant attributes e.g cuisine and dress codes.
    :param int merchant_id: Merchant Id
    :param dict merchant_attributes: Merchant Attributes
    :param str merchant_category: Merchant category
    :param str locale: Locale
    :param str company: Company code
    :rtype: list
    """
    merchant_attributes_by_section = get_merchant_attributes_by_category(merchant_category, locale)

    # using merchant_attributes as dict
    merchant_attributes = merchant_attributes.__dict__
    for merchant_attribute_section in merchant_attributes_by_section:
        for merchant_attribute in merchant_attribute_section['attributes']:

            if merchant_attribute['key'] in merchant_attributes:
                merchant_attribute['value'] = get_merchant_attribute_translation_for_value(
                    merchant_attributes[merchant_attribute['key']],
                    merchant_attribute['type'],
                    locale
                )
                if (
                        merchant_attributes.get(merchant_attribute['key']) and
                        merchant_attributes[merchant_attribute['key']] == ATTRIBUTE_VALUE_OUTLET_SPECIFIC or
                        merchant_attribute['type'] == ATTRIBUTE_VALUE_TYPE_VALUE
                ):
                    if locale == EN:
                        case = merchant_attribute['key']
                        localed_merchant_value = ("{value}_{locale}".format(
                            value=merchant_attribute['value'],
                            locale=locale)
                        ).lower()
                        fine_dining_merchant_key = FINE_DINING_DRESS_CODE_TRANSLATION.get(
                            merchant_attribute['key']
                        )
                        if case == CUISINE:
                            cuisine = Merchant.get_merchant_cuisine(merchant_id, locale)
                            merchant_attribute['name'] = "{name}: {cuisine}".format(
                                name=merchant_attribute['name'],
                                cuisine=cuisine.m_cuisine or cuisine.t_cuisine
                            )
                        elif case == DRESS_CODE:
                            merchant_attribute['name'] = "{name}: {localed_merchant}".format(
                                name=merchant_attribute['name'],
                                localed_merchant=fine_dining_merchant_key.get(localed_merchant_value)
                            )
                        elif case == FINE_DINING:
                            merchant_attribute['name'] = "{name}: {value}".format(
                                name=merchant_attribute['name'],
                                value=fine_dining_merchant_key.get(localed_merchant_value)
                            )
                        else:
                            merchant_attribute['name'] = "{name}: {value}".format(
                                name=merchant_attribute['name'],
                                value=merchant_attribute['value']
                            )
                    else:
                        merchant_attribute['name'] = "{name}: {value}".format(
                            name=merchant_attribute['name'],
                            value=merchant_attribute['value']
                        )
        # remove unselected attributes
        merchant_attribute_section['attributes'] = list(filter(
            itemgetter('value'),
            merchant_attribute_section['attributes']
        ))
    return [section for section in merchant_attributes_by_section if section['attributes']]


def initialize_offers_array(offer_array, offer, is_pinged_section):
    """
    Initializes offer array
    :param offer_array:
    :param offer:
    :param is_pinged_section:
    :rtype: dict
    """
    offer_array['product_id'] = offer['product_id']
    offer_array['purchase_product_id'] = offer['purchase_product_id']
    offer_array['section_name'] = offer.get('product_name')
    offer_array['product_sku'] = offer['product_sku']
    offer_array['is_delivery_section'] = bool(offer['is_delivery'])
    offer_array['is_monthly_section'] = offer['is_monthly']
    if not is_pinged_section:
        offer_array['is_show_purchase_button'] = offer['is_show_purchase_button']
    else:
        offer_array['is_show_purchase_button'] = False
    offer_array['offers_to_display'] = []
    return offer_array


def get_category_color_code(category, categories):
    """
    Gets category color code
    :param str category: Category
    :param list categories: Categories
    :rtype: list
    """
    for cat in categories:
        if category == cat['api_name']:
            return cat['color_code']
    return ''


def get_analytics_codes_against_categories(categories):
    """
    Gets analytics codes against given categories
    """
    codes = []
    for category in categories:
        value_against_category = ANALYTICS_CATEGORY_CODES_DICT.get(category.lower())
        if value_against_category:
            codes.append(value_against_category)
    return ','.join(codes)


def get_message_for_offer_type(locale='en', offer_type=0, spend=0, reward=0,
                               discount_off_or_percentage_off=0):
    """
    Gets the offer message for the offer type
    :param str locale: locality of the user
    :param str offer_type: type of the offer
    :param str spend: spends of the user
    :param str reward: rewards of the user till now
    :param str discount_off_or_percentage_off: discount of the user availed
    :rtype: str
    """
    if not offer_type or not offer_type > 0:
        offer_type = OFFER_TYPE_VALUE_DEFAULT

    offer_type = int(offer_type)
    message = ""
    if offer_type == OFFER_TYPE_VALUE_DEFAULT:
        message = TranslationManager.get_translation(
            TranslationManager.voucher_type_1,
            locale
        )
    if offer_type == OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE:
        message = TranslationManager.get_translation(
            TranslationManager.voucher_type_1,
            locale
        )
    if offer_type == OFFER_TYPE_VALUE_PERCENTAGE_OFF:
        message = TranslationManager.get_translation(
            TranslationManager.voucher_type_2,
            locale
        )
        message = message.replace('_percentage_value_', str(discount_off_or_percentage_off))
    if offer_type == OFFER_TYPE_VALUE_GIFT:
        message = TranslationManager.get_translation(
            TranslationManager.voucher_type_3,
            locale
        )
    if offer_type == OFFER_TYPE_VALUE_PACKAGE:
        message = TranslationManager.get_translation(
            TranslationManager.voucher_type_4,
            locale
        )
    if offer_type == OFFER_TYPE_VALUE_FIX_PRICE_OFF:
        message = TranslationManager.get_translation(
            TranslationManager.voucher_type_5,
            locale
        )
        message = message.replace('_discount_value_', str(discount_off_or_percentage_off))
    if offer_type == OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS:
        message = TranslationManager.get_translation(
            TranslationManager.voucher_type_6,
            locale
        )
        message = message.replace('_spend_value_', str(spend))
        message = message.replace('_reward_value_', str(reward))
    return message


def get_image_url_prefix(company, image_type, category=''):
    """
    Gets image url prefix
    :param str company: Company
    :param str image_type: Image Type
    :rtype: str
    """
    image_url_prefix = ""
    if image_type == IMAGE_TYPE_VOUCHER_TYPE:
        return VOUCHER_TYPE_IMAGE_URL_PREFIX
    if image_type == IMAGE_TYPE_VOUCHER_RESTRICTION:
        image_url_prefix = VOUCHER_RESTRICTION_IMAGE_URL_PREFIX
    if image_type == IMAGE_TYPE_PARTY_SIZE:
        image_url_prefix = PARTY_SIZE_IMAGE_URL_PREFIX
    return image_url_prefix


def get_image_url(image_type, category, voucher_type_id='', replace_241_type_with_141=False,
                  voucher_restriction_id='', is_monthly=False, company=''):
    """
    Gets image url
    :param int image_type: Image Type
    :param str category: Category
    :param str voucher_type_id: Voucher Type Id
    :param bool replace_241_type_with_141: Replace 241 Type With 141
    :param str voucher_restriction_id: Voucher Restriction ID
    :param bool is_monthly: Is Monthly
    :param str company: White label client
    :rtype: str
    """
    image_url = ""
    _category = None
    voucher_image_prefix = ""
    if category:
        if category == CATEGORY_API_NAME_BODY:
            _category = "body"

        if category == CATEGORY_API_NAME_LEISURE:
            _category = "leisure"

        if category == CATEGORY_API_NAME_RESTAURANTS_AND_BARS:
            _category = "food"

        if category == CATEGORY_API_NAME_RETAIL:
            _category = "retail"

        if category == CATEGORY_API_NAME_SERVICES:
            _category = "services"

        if category == CATEGORY_API_NAME_TRAVEL:
            _category = "travel"
    if _category:
        end_format = ""
        if voucher_type_id == OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE:
            end_format = "_1_for_1"
        if image_type:
            if image_type == IMAGE_TYPE_VOUCHER_TYPE:
                if is_monthly:
                    if replace_241_type_with_141:
                        image_url = "{}{}_{}{}.png".format(
                            VOUCHER_TYPE_IMAGE_URL_PREFIX,
                            "monthly",
                            voucher_type_id,
                            end_format
                        )
                    else:
                        image_url = "{}{}_{}.png".format(
                            VOUCHER_TYPE_IMAGE_URL_PREFIX,
                            "monthly",
                            voucher_type_id
                        )
                else:
                    voucher_image_prefix = VOUCHER_TYPE_IMAGE_URL_PREFIX
                    # if (
                    #     company == WlCompany.COMPANY_CODE_ENTERTAINER_HSBC and
                    #     _category.lower() == CATEGORY_API_NAME_SERVICES.lower()
                    # ):
                    #     voucher_image_prefix = VOUCHER_TYPE_IMAGE_URL_PREFIX_HS
                    # else:
                    #     if (
                    #         company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS and
                    #             (
                    #                 _category.lower() == CATEGORY_API_NAME_SERVICES or
                    #                 _category.lower() == ANALYTICS_CATEGORY_CODE_TRAVEL
                    #             )
                    #     ):
                    #         voucher_image_prefix = VOUCHER_RESTRICTION_IMAGE_URL_PREFIX
                    #     else:
                    #         voucher_image_prefix = VOUCHER_TYPE_IMAGE_URL_PREFIX

                    if replace_241_type_with_141:
                        image_url = "{}{}_{}{}.png".format(
                            voucher_image_prefix,
                            _category,
                            voucher_type_id,
                            end_format
                        )
                    else:
                        image_url = "{}{}_{}.png".format(
                            voucher_image_prefix,
                            _category,
                            voucher_type_id
                        )

            if image_type == IMAGE_TYPE_VOUCHER_RESTRICTION:
                image_url_prefix = get_image_url_prefix(company, image_type, category)
                image_url = "{}{}_{}.png".format(
                    image_url_prefix,
                    _category,
                    voucher_restriction_id
                )

            if image_type == IMAGE_TYPE_PARTY_SIZE:
                image_url_prefix = get_image_url_prefix(company, image_type, category)
                image_url = "{}{}{}.png".format(
                    image_url_prefix,
                    "party_size_",
                    _category
                )
    return image_url


def get_voucher_type_details(voucher_type, offer_category, locale='en', replace_241_type_with_141=False,
                             is_monthly=False, company=''):
    """
    Returns voucher type details
    :param int|str voucher_type: Voucher type
    :param str offer_category: Offer Category
    :param str locale: Locale
    :param bool replace_241_type_with_141: Flag to replace 2 for 1 offers with 1 for 1
    :param bool is_monthly: Flag for monthly offers
    :rtype: dict
    """
    voucher_types = {
        '1': 'Buy One Get One',
        '2': 'PERCENTAGE OFF',
        '3': 'GIFT',
        '4': 'PACKAGE',
        '6': 'SPEND THIS GET THIS'
    }
    voucher_type_key = ''

    if voucher_types.get(str(voucher_type)):
        if voucher_type == 1:
            if replace_241_type_with_141:
                voucher_type_key = TranslationManager.voucher_type_141
            else:
                voucher_type_key = TranslationManager.voucher_type_1
        elif voucher_type == 2:
            voucher_type_key = TranslationManager.voucher_type_2
        elif voucher_type == 3:
            voucher_type_key = TranslationManager.voucher_type_3
        elif voucher_type == 4:
            voucher_type_key = TranslationManager.voucher_type_4
        elif voucher_type == 5:
            voucher_type_key = TranslationManager.voucher_type_5
        elif voucher_type == 6:
            voucher_type_key = TranslationManager.voucher_type_6

        voucher_type_title = TranslationManager.get_translation(voucher_type_key, locale)
        if voucher_type_title:
            return {
                'id': voucher_type,
                'image': get_image_url(
                    IMAGE_TYPE_VOUCHER_TYPE,
                    offer_category,
                    voucher_type,
                    replace_241_type_with_141,
                    '',
                    is_monthly,
                    company
                ),
                'title': voucher_type_title,
                'color': ''
            }


def get_voucher_restriction_details(voucher_restriction_id, offer_category, locale='en'):
    """
    Gets voucher restriction details
    :param str voucher_restriction_id: Voucher Restriction Id
    :param str offer_category: Offer Category
    :param str locale: Language
    :rtype: str
    """
    _voucher_restrictions = VOUCHER_RESTRICTIONS
    _voucher_restriction_key = ''

    if _voucher_restrictions.get(str(voucher_restriction_id)):
        if voucher_restriction_id == 1:
            _voucher_restriction_key = TranslationManager.voucher_restriction_1
        if voucher_restriction_id == 2:
            _voucher_restriction_key = TranslationManager.voucher_restriction_2
        if voucher_restriction_id == 3:
            _voucher_restriction_key = TranslationManager.voucher_restriction_3
        if voucher_restriction_id == 4:
            _voucher_restriction_key = TranslationManager.voucher_restriction_4
        if voucher_restriction_id == 5:
            _voucher_restriction_key = TranslationManager.voucher_restriction_5
        if voucher_restriction_id == 6:
            _voucher_restriction_key = TranslationManager.voucher_restriction_6
        if voucher_restriction_id == 7:
            _voucher_restriction_key = TranslationManager.voucher_restriction_7
        if voucher_restriction_id == 8:
            _voucher_restriction_key = TranslationManager.voucher_restriction_8
        if voucher_restriction_id == 9:
            _voucher_restriction_key = TranslationManager.voucher_restriction_9
        if voucher_restriction_id == 10:
            _voucher_restriction_key = TranslationManager.voucher_restriction_10
        if voucher_restriction_id == 11:
            _voucher_restriction_key = TranslationManager.voucher_restriction_11
        if voucher_restriction_id == 12:
            _voucher_restriction_key = TranslationManager.voucher_restriction_12
        if voucher_restriction_id == 13:
            _voucher_restriction_key = TranslationManager.voucher_restriction_13
        if voucher_restriction_id == 14:
            _voucher_restriction_key = TranslationManager.voucher_restriction_14

        if _voucher_restrictions[str(voucher_restriction_id)]:
            voucher_restriction_title = TranslationManager.get_translation(_voucher_restriction_key, locale)
            if voucher_restriction_title:
                return {
                    'id': voucher_restriction_id,
                    'image': get_image_url(
                        image_type=IMAGE_TYPE_VOUCHER_RESTRICTION,
                        category=offer_category,
                        voucher_type_id=0,
                        replace_241_type_with_141=False,
                        voucher_restriction_id=voucher_restriction_id
                    ),
                    'title': voucher_restriction_title,
                    'color': ''
                }

    return None


def initialize_offer_to_display_array(*args, **kwargs):
    """
    Initialize offer to display offers
    :param args:
    :param kwargs:
    :rtype: dict
    """

    import datetime

    offer_to_display = {}
    offer = kwargs.get('offer')
    categories = kwargs.get('categories')
    redeemability = kwargs.get('redeemability')
    locale = kwargs.get('locale')
    company = kwargs.get('company')
    replace_241_type_with_141 = kwargs.get('replace_241_type_with_141')
    category_color = get_category_color_code(offer['merchant_category'], categories)
    categories_list = []
    if offer['merchant_category']:
        categories_list.append(offer['merchant_category'])
    offer_to_display['categories_analytics'] = get_analytics_codes_against_categories(categories_list)

    offer_to_display['offer_id'] = offer['id']
    offer_to_display['category'] = offer.get('merchant_category')
    offer_to_display['category_color'] = category_color
    offer_to_display['name'] = offer.get('name')
    offer_to_display['details'] = offer.get('details')
    offer_to_display['offer_detail'] = offer.get('description', '')
    offer_to_display['is_cheers'] = bool(offer.get('is_cheers'))  # Offer belongs to cheers
    offer_to_display['voucher_type'] = offer.get('voucher_type')
    offer_to_display['voucher_type_image'] = ""
    offer_to_display['voucher_restriction1'] = offer.get('voucher_restriction1')
    offer_to_display['voucher_restriction2'] = offer.get('voucher_restriction2')
    offer_to_display['voucher_restrictions'] = offer.get('voucher_restrictions')  # Offer Voucher Restriction
    offer_to_display['savings_estimate'] = round(offer.get('savings_estimate'))
    offer_to_display['savings_estimate_aed'] = offer.get('savings_estimate_aed')
    offer_to_display['savings_estimate_local_currency'] = offer.get('savings_estimate_local_currency')
    offer_to_display['redeemability'] = redeemability
    offer_to_display['is_topup_offer_allowed'] = False  # Offer Buy Back Allowed
    offer_to_display['is_pingable'] = False  # Is offer Pingable?
    offer_to_display['is_pinged'] = False  # Customer Already Pinged This offer to other customer ?
    offer_to_display['is_show_smiles'] = offer.get('show_smiles_earn_value')
    offer_to_display['smiles_earn_value'] = offer.get('smiles_earn_value')
    offer_to_display['smiles_burn_value'] = offer.get('smiles_burn_value')
    offer_to_display['dcp_license'] = offer.get('dcp_license')
    offer_to_display['valid_from_date'] = offer.get('valid_from_date').replace(
        tzinfo=datetime.timezone.utc
    ).isoformat()
    offer_to_display['expiration_date'] = offer.get('expiration_date').replace(
        tzinfo=datetime.timezone.utc
    ).isoformat()
    offer_to_display['validity_date'] = offer.get('expiration_date').replace(
        tzinfo=datetime.timezone.utc
    ).isoformat()
    offer_to_display['outlet_ids'] = offer.get('outlet_ids')
    offer_to_display['item_code'] = offer.get('item_code')
    offer_to_display['is_barcode_enabled'] = offer.get('is_barcode_enabled')
    offer_to_display['is_point_based_offer'] = True if offer.get('is_point_based_offer') else False
    offer_to_display['is_merlin_offer'] = offer.get('is_merlin_offer')
    offer_to_display['outlet_merlin_urls'] = offer.get('outlet_merlin_urls')
    offer_to_display['merlin_title'] = offer.get('merlin_title')
    offer_to_display['message'] = get_message_for_offer_type(
        locale,
        offer.get('voucher_type'),
        offer.get('spend'),
        offer.get('reward'),
        offer.get('percentage_off')
    )
    offer_to_display['sub_detail_label'] = ""
    offer_to_display['additional_details'] = []
    offer_to_display['voucher_details'] = []
    offer_to_display['voucher_rules_of_use'] = []
    offer['voucher_type'] = 1 if not offer.get('voucher_type') else offer.get('voucher_type')
    if offer['voucher_type']:
        voucher_type_details = get_voucher_type_details(
            offer['voucher_type'],
            offer['merchant_category'],
            locale,
            replace_241_type_with_141,
            offer['is_monthly'],
            company
        )
        if voucher_type_details:
            voucher_type_details['title'] = offer_to_display['message']
            offer_to_display['voucher_details'].append(voucher_type_details)
            offer_to_display['voucher_type_image'] = voucher_type_details.get('image')

    if offer['voucher_restriction1']:
        voucher_restriction1_details = get_voucher_restriction_details(
            offer['voucher_restriction1'],
            offer['merchant_category'],
            locale
        )
        if voucher_restriction1_details:
            offer_to_display['voucher_details'].append(voucher_restriction1_details)
            voucher_restriction1_details['title'] = voucher_restriction1_details['title'].lower()
            offer_to_display['additional_details'].append(voucher_restriction1_details)

    if offer['voucher_type'] == OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE:
        party_size_image_url = get_image_url(
            image_type=IMAGE_TYPE_PARTY_SIZE,
            category=offer['merchant_category'],
            voucher_type_id=0,
            replace_241_type_with_141=False,
            voucher_restriction_id=0,
            is_monthly=False
        )
        offer_to_display['additional_details'].append(
            {
                'id': 0,
                'image': party_size_image_url,
                'title': TranslationManager.get_translation(TranslationManager.Two_People, locale),
                'color': category_color
            }
        )

    if offer['voucher_restriction2']:
        voucher_restriction2_details = get_voucher_restriction_details(
            offer['voucher_restriction2'],
            offer['merchant_category'],
            locale
        )
        if voucher_restriction2_details:
            offer_to_display['voucher_details'].append(voucher_restriction2_details)

    if offer['smiles_earn_value']:
        offer_to_display['additional_details'].append(
            {
                'id': offer["smiles_earn_value"],
                'image': 'https://s3.amazonaws.com/entertainer-app-assets/icons/smiles_icon.png',
                'title': '+{smiles_earn_value} SMILES'.format(smiles_earn_value=offer["smiles_earn_value"]),
                'color': 'e2bb55'
            }
        )

    if offer["voucher_restrictions"].strip():
        offer_to_display['voucher_rules_of_use'].append(offer["voucher_restrictions"].upper())

    if offer['is_offer_expired']:
        offer_to_display['sort_order'] = SORT_EXPIRED

    offer_to_display['offer_redemption_type'] = 0
    if kwargs.get('show_and_go_product_skus'):
        if offer['product_sku'] in kwargs['show_and_go_product_skus']:
            offer_to_display['offer_redemption_type'] = 1

    return offer_to_display


def get_formated_date(date):
    if isinstance(date, datetime):
        date = datetime.strftime(date, '%Y-%m-%dT%H:%M:%S+0400')
    return date


def set_offer_label(offer_section, offer, offer_to_display, messages_locale, is_skip_mode=False):
    """
    Sets Label to offer to display object based on different criteria
    :param offer_section:
    :param offer:
    :param offer_to_display:
    :param messages_locale:message_locale
    :param is_skip_mode:
    """
    if offer['is_offer_expired']:
        offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
            TranslationManager.expired_offer, messages_locale
        )
        return offer_to_display
    if offer_section == SECTION_REDEEMABLE:
        if offer['is_offer_valid_in_future']:
            offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                TranslationManager.purchased_available_from,
                messages_locale
            )
            offer_to_display['validity_date'] = get_formated_date(offer['valid_from_date'])
        else:
            offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                TranslationManager.valid_to,
                messages_locale
            )
    elif offer_section == SECTION_REDEEMED:
        offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
            TranslationManager.already_redeemed,
            messages_locale
        )
    elif offer_section == SECTION_NOT_REDEEMABLE:
        if offer['is_show_purchase_button'] or is_skip_mode:
            offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                TranslationManager.included_in_mobile_product_not_yet_purchased,
                messages_locale
            )
    return offer_to_display


def assign_sort_order_to_offers(offer_section, offer, offer_to_display):
    """
    Assigns sort order to offer to display object based on different criteria.
    :param offer_section:
    :param offer:
    :param offer_to_display:
    """
    if offer['is_offer_expired']:
        offer_to_display['sort_order'] = SORT_EXPIRED
        return offer_to_display

    if offer_section == SECTION_REDEEMABLE:
        if offer['is_offer_valid_in_future']:
            offer_to_display['sort_order'] = SORT_PURCHASED_AVAILABLE_IN_FUTURE
        else:
            offer_to_display['sort_order'] = SORT_REDEEMABLE
    elif offer_section == SECTION_REDEEMED:
        offer_to_display['sort_order'] = SORT_REDEEMED
    elif offer_section == SECTION_NOT_REDEEMABLE:
        offer_to_display['sort_order'] = SORT_NOT_REDEEMABLE
    return offer_to_display


def get_offer_sub_detail_object(id='', image='', title='', color=''):
    """
    Gets offer sub detail object
    :return:
    """
    return {'id': id, 'image': image, 'title': title, 'color': color}


def formulate_offer_details_array(
        offers, offers_array, message_locale, is_skip_mode, company, categories,
        replace_241_type_with_141=False, show_and_go_product_skus=None
):
    """
    Formulated offer details
    """
    # replace_retail_to_services - its for supporting retail to be treated as services
    # for apps before v5.92 (Till Jan 31, 2017)
    if show_and_go_product_skus is None:
        show_and_go_product_skus = ()
    for offer in offers:
        for offer_array in offers_array:
            if offer_array.get('product_id') == offer.get('product_id'):
                if not offer_array.get('offers_to_display'):
                    offer_array = initialize_offers_array(offer_array, offer, True)
                    # Show the offers which are either redeemable or reusable
                for index in range(int(offer.get('quantity_redeemable', 0))):
                    redeemability = offer.get('redeemability')
                    offer_to_display = initialize_offer_to_display_array(
                        offer=offer,
                        locale=message_locale,
                        offer_section_by_redeemability=SECTION_REDEEMABLE,
                        redeemability=redeemability,
                        is_skip_mode=is_skip_mode,
                        replace_241_type_with_141=replace_241_type_with_141,
                        categories=categories,
                        company=company,
                        show_and_go_product_skus=show_and_go_product_skus
                    )
                    offer_to_display['redeemability'] = offer.get('redeemability')
                    if offer_to_display['redeemability'] == Redemption.REUSABLE:
                        offer_to_display['redeemability'] = Redemption.REDEEMABLE
                    offer_to_display = set_offer_label(
                        SECTION_REDEEMABLE,
                        offer,
                        offer_to_display,
                        message_locale
                    )
                    offer_to_display = assign_sort_order_to_offers(
                        SECTION_REDEEMABLE, offer, offer_to_display
                    )
                    offer_array['offers_to_display'].append(offer_to_display)

                    # Show the offers which are already redeemed
                for index in range(int(offer.get('quantity_redeemed', 0))):
                    redeemability = Redemption.REDEEMED
                    offer_to_display = initialize_offer_to_display_array(
                        offer=offer,
                        locale=message_locale,
                        offer_section_by_redeemability=SECTION_REDEEMED,
                        redeemability=redeemability,
                        is_skip_mode=is_skip_mode,
                        replace_241_type_with_141=replace_241_type_with_141,
                        categories=categories,
                        company=company,
                        show_and_go_product_skus=show_and_go_product_skus
                    )
                    offer_to_display['redeemability'] = Redemption.REDEEMED
                    offer_to_display = set_offer_label(
                        SECTION_REDEEMED,
                        offer,
                        offer_to_display,
                        message_locale
                    )
                    offer_to_display = assign_sort_order_to_offers(
                        SECTION_REDEEMED, offer, offer_to_display
                    )
                    offer_to_display['additional_details'] = []
                    offer_to_display['additional_details'].append(
                        get_offer_sub_detail_object(
                            offer.get("smiles_earn_value", ""),
                            "",
                            offer_to_display.get('sub_detail_label', '').upper(),
                            COLOR_CODE_ALREADY_REDEEMED
                        )
                    )
                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'].append(offer_to_display)
                    # Show the offers which are not redeemable
                for index in range(offer.get('quantity_not_redeemable')):
                    redeemability = Redemption.NOT_REDEEMABLE
                    offer_to_display = initialize_offer_to_display_array(
                        offer=offer,
                        locale=message_locale,
                        offer_section_by_redeemability=SECTION_NOT_REDEEMABLE,
                        redeemability=redeemability,
                        is_skip_mode=is_skip_mode,
                        replace_241_type_with_141=replace_241_type_with_141,
                        categories=categories,
                        company=company,
                        show_and_go_product_skus=show_and_go_product_skus
                    )
                    offer_to_display['redeemability'] = Redemption.NOT_REDEEMABLE
                    offer_to_display = set_offer_label(
                        SECTION_NOT_REDEEMABLE,
                        offer,
                        offer_to_display,
                        message_locale
                    )

                    offer_to_display = assign_sort_order_to_offers(
                        SECTION_NOT_REDEEMABLE, offer, offer_to_display
                    )
                    offer_to_display['additional_details'] = []
                    offer_to_display['additional_details'].append(
                        get_offer_sub_detail_object(
                            offer.get("smiles_earn_value", ""),
                            "",
                            offer_to_display.get('sub_detail_label', '').upper(),
                            COLOR_CODE_ALREADY_REDEEMED
                        )
                    )
                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'] = [offer_to_display]

    _filtered_product_offers = []

    # remove sections where there is no offer available to redeem
    for product_section in offers_array:
        if product_section.get('offers_to_display'):
            product_section['offers_to_display'] = multi_key_sort(
                product_section['offers_to_display'],
                ['sort_order', 'offer_id']
            )
        _filtered_product_offers.append(product_section)

    offers_array = _filtered_product_offers

    return offers_array


def get_analytics_category_code(category):
    """
    :returns corresponding category code
    """
    if category == CATEGORY_API_NAME_BODY:
        return ANALYTICS_CATEGORY_CODE_BODY

    if category == CATEGORY_API_NAME_LEISURE:
        return ANALYTICS_CATEGORY_CODE_LEISURE

    if category == CATEGORY_API_NAME_RESTAURANTS_AND_BARS:
        return ANALYTICS_CATEGORY_CODE_RESTAURANTSANDBARS

    if category == CATEGORY_API_NAME_RETAIL:
        return ANALYTICS_CATEGORY_CODE_RETAIL

    if category == CATEGORY_API_NAME_SERVICES:
        return ANALYTICS_CATEGORY_CODE_SERVICES

    if category == CATEGORY_API_NAME_TRAVEL:
        return ANALYTICS_CATEGORY_CODE_TRAVEL

    return ''


def get_category_codes_for_analytics(categories):
    """
    Gets category codes for analytics
    :param list categories: Categories
    :rtype: str
    """
    categories_analytics = []
    if not categories:
        return categories_analytics
    for category in categories:
        analytics_category_code = get_analytics_category_code(category)
        if analytics_category_code:
            categories_analytics.append(analytics_category_code)
    return ','.join(categories_analytics)


def get_delivery_tutorials_info(locale=EN):
    """
    Gets the delivery tutorial's information
    :param str locale: locale
    :rtype: list
    """
    tutorial_info = []
    if locale.lower() in SUPPORTED_LOCALES:
        tutorial_info = [
            "https://s3.amazonaws.com/entertainer-app-assets/delivery/{}/delivery_tutorial_01.png".format(locale),
            "https://s3.amazonaws.com/entertainer-app-assets/delivery/{}/delivery_tutorial_02.png".format(locale),
            "https://s3.amazonaws.com/entertainer-app-assets/delivery/{}/delivery_tutorial_03.png".format(locale),
            "https://s3.amazonaws.com/entertainer-app-assets/delivery/{}/delivery_tutorial_04.png".format(locale)
        ]
    return tutorial_info


def get_menu_items(merchant_id, locale=EN):
    """
    :param merchant_id:
    :param locale:
    :return:
    """
    result = {}
    delivery_contact_number = Merchant.get_delivery_contact_number(merchant_id, locale)
    if delivery_contact_number:
        result['delivery_contact_no'] = delivery_contact_number.delivery_contact_no
    else:
        result['delivery_contact_no'] = None
    result['delivery_tutorials_info'] = get_delivery_tutorials_info(locale)

    items = DeliveryMenuItem.get_items(merchant_id)
    categorized_menu = {}
    category_locale = 'category_{}'.format(locale)
    title_locale = 'title_{}'.format(locale)
    description_locale = 'description_{}'.format(locale)

    for item in items:
        item = item.__dict__
        categorized_menu[item[category_locale]] = item[category_locale]
        if item['is_entertainer']:
            icon = DeliveryMenuItem.IMAGE_LINK
        else:
            icon = ''

        new_item = {
            'id': item.get('id'),
            'title': item.get(title_locale),
            'description': item.get(description_locale),
            'price': '{currency} {price}'.format(
                currency=item.get('currency'),
                price=item.get('price')
            ),
            'is_deliverable': item.get('is_entertainer'),
            'img': icon
        }
        # TODO need to confirm
        categorized_menu[item[category_locale]] = new_item

    output = []
    for key, value in categorized_menu.items():
        output.append({'title': key, 'menus': value})
    result.update({'menu_section': output})
    return result


def get_merchant_attributes_by_merchant_id(merchant_id, merchant_category=''):
    """
    Gets merchant attributes against merchant id. Check category and select category based Model
    to query attributes.
    :param int merchant_id: Merchant id
    :param str merchant_category: Merchant category
    :param str locale: Locale
    """
    merchant_attribute = None
    MODEL = ''
    if merchant_category == CATEGORY_API_NAME_BODY:
        MODEL = MerchantAttributesBody
    elif merchant_category == CATEGORY_API_NAME_KIDS:
        MODEL = MerchantAttributesKid
    elif merchant_category == CATEGORY_API_NAME_LEISURE:
        MODEL = MerchantAttributesLeisure
    elif merchant_category == CATEGORY_API_NAME_RESTAURANTS_AND_BARS:
        MODEL = MerchantAttributesRestaurantsAndBar
    elif merchant_category == CATEGORY_API_NAME_SERVICES:
        MODEL = MerchantAttributesService
    elif merchant_category == CATEGORY_API_NAME_RETAIL:
        MODEL = MerchantAttributesFashionAndRetail
    elif merchant_category == CATEGORY_API_NAME_TRAVEL:
        MODEL = MerchantAttributesTravel

    if MODEL:
        # query the category based model
        merchant_attribute = MODEL.get_attributes(merchant_id)
    return merchant_attribute


def inject_distances_and_sort(outlets, target_lat_long='0,0'):
    """
    Here we do some calculations on latitude and longitude and sort result on basis of that calculation.
    :param list outlets: List of outlet dicts
    :param str target_lat_long: String of latitude and longitude appended by coma
    """
    if target_lat_long and target_lat_long not in ('0,0', '0.0,0.0'):
        target_lat_long = list(map(float, target_lat_long.split(',')))
    else:
        target_lat_long = []
    for _index, outlet in enumerate(outlets):
        outlet = outlet._asdict()
        outlets[_index] = outlet
        outlet['distance'] = 0
        if target_lat_long:
            outlet['lat'], outlet['lng'] = (float(outlet['lat'] if outlet['lat'] is not None else 0),
                                            float(outlet['lng'] if outlet['lng'] is not None else 0))
            # Distance between outlet and target in meters
            outlet['distance'] = round(
                math.acos(
                    math.cos(math.radians(90.0 - target_lat_long[0])) *
                    math.cos(math.radians(90.0 - outlet['lat'])) +
                    math.sin(math.radians(90.0 - target_lat_long[0])) *
                    math.sin(math.radians(90.0 - outlet['lat'])) *
                    math.cos(math.radians((target_lat_long[1] - outlet['lng'])))
                ) * 6371.0 * 1000.0
            )


def process_merchant(merchant, app_version='0', skip_app_version_check=False):
    """
    Process merchant after getting from db, sets image urls and encrypts merchant pin etc
    :param dict merchant: Merchant dict
    :param str app_version: App version
    :param bool skip_app_version_check: Flag to disable or enable version checking
    :return:
    """
    merchant['merchant_pin'] = md5(merchant.get('merchant_pin', '').encode()).hexdigest()
    hero_urls = []
    hero_small_urls = []
    hero_urls_old = []
    hero_small_urls_old = []
    if skip_app_version_check or app_version >= '5.8':
        if merchant['p3_hero_image_retina']:
            hero_urls.append(merchant['p3_hero_image_retina'])
        if merchant['photo_url']:
            hero_urls.append(merchant['photo_url'])
        if merchant['p3_hero_image_non_retina']:
            hero_small_urls.append(merchant['p3_hero_image_non_retina'])
        if merchant['photo_small_url']:
            hero_small_urls.append(merchant['photo_small_url'])
    if merchant.get('hero_urls'):
        hero_urls_old = json.loads(merchant['hero_urls'])
    if merchant.get('hero_small_urls'):
        hero_small_urls_old = json.loads(merchant['hero_small_urls'])

    merchant['hero_urls'] = hero_urls + hero_urls_old
    merchant['hero_small_urls'] = hero_small_urls + hero_small_urls_old

    images_360 = {}
    if merchant['is_opted_in_for_360_image'] and merchant['p3_360_degree_image']:
        count = 1
        for hero_url in merchant['hero_urls']:
            if count > 1:
                break
            images_360[hero_url] = merchant['p3_360_degree_image']
            count += 1
        hero_images_360 = images_360
    else:
        hero_images_360 = {}
    merchant['hero_images_360'] = hero_images_360


def fix_expiration_date(current_date):
    """
    Fix expiration date
    :rtype date
    """
    expiration_date = current_date.replace(hour=12, minute=0, second=0)
    return expiration_date


def parse_voucher_restrictions(json_encoded_voucher_restriction):
    """
    parses a json encoded string
    :param json_encoded_voucher_restriction: json encoded string
    :return: decoded json
    """
    voucher_restrictions = {}
    try:
        voucher_restrictions = json.loads(json_encoded_voucher_restriction)
    except Exception:
        pass
    return voucher_restrictions


def set_offers_data(offers, offer_categories, offer_sub_categories, session_data=None):
    """
    set offers data to process next
    :param dict offers:
    :param list offer_categories:
    :param list offer_sub_categories:
    :param dict session_data:
    :return dict offers: offers_data
    """
    if session_data is None:
        session_data = {}
    product_offers = []
    offer_ids = []
    for offer in offers:
        offer = offer._asdict()
        offer_ids.append(offer.get('id'))
        offer['expiration_date'] = fix_expiration_date(offer['expiration_date'])
        offer['valid_to'] = offer['expiration_date']
        offer['valid_from'] = offer['valid_from_date']
        if offer['item_code'] == "":
            offer['is_barcode_enabled'] = False
        else:
            offer['is_barcode_enabled'] = True

        if not offer.get('merchant_category') in offer_categories:
            offer_categories.append(offer.get('merchant_category'))

        if (
                offer.get('sub_category') and
                offer.get('sub_category') != '' and
                not offer.get('sub_category') in offer_sub_categories
        ):
            offer_sub_categories.append(offer.get('sub_category'))

        if offer.get('is_cheers'):
            offer['is_cheers'] = True
        else:
            offer['is_cheers'] = False

        if offer.get('is_delivery'):
            offer['is_delivery'] = True
        else:
            offer['is_delivery'] = False

        product_id_sku_name_array = offer['product_id_sku_name'].split(',')
        product_id_sku_name_count = len(product_id_sku_name_array)

        # Need to check
        for i in range(product_id_sku_name_count):
            product_offers.append(copy.deepcopy(offer))
            product_id_sku_name = product_id_sku_name_array[i].split('_')
            # converting product id from str to int for redeemability calculation
            product_offers[len(product_offers) - 1]['product_id'] = product_id_sku_name[0]
            product_offers[len(product_offers) - 1]['product_sku'] = product_id_sku_name[1]
            product_offers[len(product_offers) - 1]['product_name'] = product_id_sku_name[2]
            product_offers[len(product_offers) - 1]['offer_product'] = '{}_{}'.format(offer['id'],
                                                                                      product_id_sku_name[0])
            purchased_through_connect = False

            product_offers[len(product_offers) - 1]['purchased_through_connect'] = purchased_through_connect

    offers = product_offers

    if offers:
        # Need to check this function
        current_datetime = datetime.now()
        offer_valid_from_start_date = datetime(year=current_datetime.year, month=1, day=31)
        offer_valid_from_cut_off_date = current_datetime
        offer_valid_from_cut_off_date = offer_valid_from_cut_off_date.replace(
            hour=0, minute=0, second=0
        )
        offer_valid_from_cut_off_date = offer_valid_from_cut_off_date + timedelta(days=-30)

        # Getting offers redeemability
        redeemabilities = {}
        if session_data.get('user_id'):
            redeemabilities = user_redemptions_lookup_hash(session_data.get('user_id'), ADR, offer_ids)
        current_date = datetime.now()
        date_from = current_date + timedelta(hours=OfferWlActive.HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM)
        date_to = current_date + timedelta(hours=OfferWlActive.HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO)
        for offer in offers:
            # Code
            redeemability = calculate_redeemability(
                DictToObj(**offer),  # using offer as an obj for calculate_redeemability()
                session_data.get('product_ids'),
                redeemabilities,
                date_from,
                date_to
            )

            if isinstance(offer.get('outlet_ids'), str):
                offer['outlet_ids'] = list(set(list(map(int, offer['outlet_ids'].split(',')))))
            offer['voucher_restrictions'] = '{voucher} {card}'.format(
                voucher=offer.get('voucher_restrictions'),
                card=offer.get('card_line')
            )
            offer['conditions'] = '{conditions}{card}'.format(
                conditions=offer.get('conditions'),
                card=offer.get('card_line')
            )
            offer['conditions'] = parse_voucher_restrictions(offer.get('conditions', {}))
            offer['is_redeemable'] = redeemability.get('is_redeemable', False)
            offer['redeemability'] = redeemability.get('redeemability', Redemption.NOT_REDEEMABLE)
            offer['is_purchased'] = redeemability.get('is_purchased', False)
            offer['is_offer_valid_in_future'] = redeemability.get('is_offer_valid_in_future', False)
            offer['is_offer_expired'] = redeemability.get('is_offer_expired', False)
            offer['quantity_redeemable'] = redeemability.get('quantity_redeemable', 0)
            offer['quantity_redeemed'] = redeemability.get('quantity_redeemed', 0)
            offer['quantity_not_redeemable'] = redeemability.get('quantity_not_redeemable', offer.get('quantity'))
            offer['is_show_purchase_button'] = redeemability.get('is_show_purchase_button', False)
            offer['is_monthly'] = offer['type'] == TYPE_MEMBER

            if (
                    offer['type'] != TYPE_MEMBER and
                    offer['valid_from_date'] > offer_valid_from_start_date and
                    offer['valid_from_date'] > offer_valid_from_cut_off_date
            ):
                offer['is_new'] = True
            else:
                offer['is_new'] = False

    return offers


def split_and_filter_null_entries(data, delimiter=' '):
    """
    Splits string and filter None entries and returns a list
    :param str|list data: Data to be split
    :param str delimiter: character on which you want to split
    :rtype: list
    """
    if isinstance(data, str):
        return list(filter(None, data.split(delimiter)))
    elif isinstance(data, list):
        return list(filter(None, data))
    return []


class DictToObj:
    """
    converts a dict into obj
    """

    def __init__(self, **entries):
        self.__dict__.update(entries)
