"""
Validation for Get Merchant by Id api
"""
from flask_restful import reqparse

from common.constants import EN, USD
from utils.custom_request_parsers import currency, language

merchant_by_id_parser = reqparse.RequestParser(bundle_errors=True)

merchant_by_id_parser.add_argument(
    'category',
    type=str,
    default="",
    location='args'
)

merchant_by_id_parser.add_argument(
    'language',
    type=language,
    required=False,
    default=EN,
    location='args'
)

merchant_by_id_parser.add_argument(
    'currency',
    type=currency,
    default=USD,
    location='args'
)

merchant_by_id_parser.add_argument(
    'app_version',
    type=str,
    required=False,
    location='args'
)

merchant_by_id_parser.add_argument(
    'lat',
    type=float,
    default=0,
    location='args'
)
merchant_by_id_parser.add_argument(
    'lng',
    type=float,
    default=0,
    location='args'
)

merchant_by_id_parser.add_argument(
    'is_cuckoo',
    type=bool,
    default=False,
    location='args'
)
merchant_by_id_parser.add_argument(
    'user_include_cheers',
    type=bool,
    default=False,
    location='args'
)

merchant_by_id_parser.add_argument(
    'location_id',
    type=int,
    required=False,
    default=0,
    location='args'
)
merchant_by_id_parser.add_argument(
    'user_groups',
    type=str,
    required=False,
    default='1',
    location='args'
)
