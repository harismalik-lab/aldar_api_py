"""
This module contains API endpoint to get merchant by id.
"""
from math import floor
from operator import itemgetter

from flask import current_app
from requests import codes, RequestException

from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.api_utils import get_api_configurations

from common.base_resource import BasePostResource
from common.constants import ADR, BUSINESS_TRIGGERS_FOR_TAX_DEDUCTION
from api.v1.merchant_details.constants import USER_BALANCE_DESCRIPTION, USER_ZERO_BALANCE_DESCRIPTION, RETAIL, \
    USER_ZERO_BALANCE_DESCRIPTION_MALL_CARD
from models.entertainer_web.api_configuration import ApiConfiguration
from models.entertainer_web.merchant_mapping import MerchantMapping

from models.consolidation.ent_customer_profile import EntCustomerProfile
from models.entertainer_web.exchange_rate import ExchangeRate
from models.entertainer_web.merchant import Merchant
from models.entertainer_web.outlet import Outlet
from models.entertainer_web.wl_location_category import WlLocationCategory
from models.entertainer_web.wl_product import WlProduct
from models.entertainer_web.wl_user_group import WlUserGroup
from models.entertainer_web.wlvalidation import Wlvalidation

from utils.api_utils import get_locale, multi_key_sort
from user_authentication.authentication import get_current_customer
from utils.lms_manager import lms_manager
from utils.translation_manager import TranslationManager

from api.v1.merchant_details.validation import merchant_by_id_parser

from api.v1.merchant_details.utils import (
    format_merchant_attributes,
    formulate_offer_details_array,
    get_analytics_codes_against_categories,
    get_category_codes_for_analytics,
    get_menu_items,
    get_merchant_attributes_by_merchant_id,
    inject_distances_and_sort,
    process_merchant,
    set_offers_data,
    split_and_filter_null_entries
)


class MerchantByIdApi(BasePostResource):
    """
    @api {get} /v1/merchants/{merchant_id} Get merchant id
    @apiSampleRequest /v1/merchants/{merchant_id}
    @apiVersion 1.0.0
    @apiName MerchantName
    @apiGroup Merchants
    @apiParam {String}                                  [app_version]                App_version
    @apiParam {Float}                                   [lat]                         Latitude
    @apiParam {Float}                                   [lng]                        Longitude
    @apiParam {String="BHD", "EGP", "EUR", "GBP", "HKD", "JOD", "KWD", "LBP", "MYR", "OMR", "QAR", "SAR", "SGD", "USD", "ZAR", "AED"}     [currency]    Currency  # noqa:E501
    @apiParam {Boolean}                                 [is_cuckoo]                  Is_cuckoo flag
    @apiParam {Boolean}                                 [user_include_cheers]        User_include_cheers flag
    """
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='merchants_service/merchants_by_id.log',
        ),
        'name': 'merchants_api_wl'
    }
    request_parser = merchant_by_id_parser
    required_token = True

    def populate_request_arguments(self):
        """
        Add request arguments of merchant_api
        """
        self.category = self.request_args.get('category')
        self.locale = self.request_args.get('language')
        self.currency = self.request_args.get('currency')
        self.app_version = self.request_args.get('app_version')
        self.lattitude = self.request_args.get('lat')
        self.longitude = self.request_args.get('lng')
        self.is_cuckoo = self.request_args.get('is_cuckoo')
        self.user_include_cheers = self.request_args.get('user_include_cheers')
        self.location_id = self.request_args.get('location_id')
        self.targetted_user_groups = self.request_args.get('user_groups')

    def initialize_local_variables(self):
        """
        Initialize local variables
        """
        self.company = ADR
        self.message_locale = get_locale(self.locale)
        self.important_info_section = False

    def initialize_class_attributes(self):
        """
        Initialize class attributes
        """
        self.lat_long = "{},{}".format(self.lattitude, self.longitude)
        self.customer_info = {}
        self.get_love_dining_skus = {}
        self.outlet_ids_having_offers = []
        self.outlets_filtered = []
        self.outlet_ids = []
        self.offers_array = []
        self.purchasable_product_ids = []     # always empty list
        self.offer_categories = []
        self.offer_sub_categories = []
        self.redeemability_for_delivery = {}
        self.delivery_offers_count = 0
        self.outlet_merlin_urls = {}

    def set_current_customer_data(self):
        """
        Sets current customer data
        """
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id')
        self.user_group = WlUserGroup.DEFAULT_USER_GROUP
        if not self.customer.get('is_user_logged_in'):
            # if self.targetted_user_groups:
            #     self.targetted_user_groups = list(map(int, self.targetted_user_groups.split(',')))
            self.location_wise_product_ids = WlProduct.get_configured_product_ids(
                company=self.company,
                user_groups=[self.user_group],
                location_id=self.location_id
            )
            self.customer['product_ids'] = self.location_wise_product_ids
        if self.customer.get('is_user_logged_in'):
            user_groups = Wlvalidation.get_user_groups(self.company, self.customer.get('customer_id'))
            if user_groups:
                self.user_group = user_groups[len(user_groups) - 1]
            else:
                self.user_group = 0
            # for location_wise_product_id in self.location_wise_product_ids:
            #     if location_wise_product_id not in self.customer['product_ids']:
            #         self.customer['product_ids'].append(location_wise_product_id)

    def get_merchant(self, **kwargs):
        """
        Finds merchant by supplied id
        """
        self.merchant = Merchant.find_by_id(
            merchant_id=kwargs.get('merchant_id'),
            locale=self.message_locale
        )
        if self.merchant:
            self.merchant = self.merchant._asdict()
            process_merchant(self.merchant, skip_app_version_check=True)

            self.merchant['cuisines'] = split_and_filter_null_entries(self.merchant['cuisines'], ';')
            self.merchant['sub_categories'] = (self.merchant['sub_categories'] or '').split(',')
            self.merchant['offer_categories'] = split_and_filter_null_entries(self.merchant['offer_categories'], ',')
            self.merchant['categories'] = split_and_filter_null_entries(self.merchant['merchant_categories'], ';')
            self.merchant['merchant_categories'] = self.merchant['categories']
            self.merchant['booking_request'] = self.merchant.get('booking_request').decode('utf-8')

            self.merchant['categories_analytics'] = get_analytics_codes_against_categories(
                self.merchant['merchant_categories']
            )
            if self.merchant.get('offer_categories'):
                self.merchant['categories'] = self.merchant['offer_categories']

            # adding earn/burn flags
            merchant_category_info = MerchantMapping.get_category_info_by_merchant_id(
                self.merchant['id']
            )
            api_configs = get_api_configurations(ADR, current_app.config['ENV'].lower(), ApiConfiguration.PRIVATE)
            self.merchant['vat_percentage'] = float(api_configs.get(ApiConfiguration.VALUE_ADDED_TAX_PERCENTAGE, 0))
            self.merchant['service_tax_percentage'] = float(api_configs.get(ApiConfiguration.SALES_TAX_PERCENTAGE, 0))
            self.merchant['earn_tax_deduction'] = False
            if merchant_category_info:
                if merchant_category_info.business_trigger in BUSINESS_TRIGGERS_FOR_TAX_DEDUCTION:
                    self.merchant['earn_tax_deduction'] = True
                if merchant_category_info.category_api_name and merchant_category_info.category_api_name.lower() == RETAIL:
                    self.important_info_section = True
                self.merchant['is_earn_enabled'] = bool(merchant_category_info.is_earn_enabled)
                self.merchant['is_burn_enabled'] = bool(merchant_category_info.is_burn_enabled)
                self.merchant['earn_rate'] = str(merchant_category_info.earn_rate)
                self.merchant['burn_rate'] = str(merchant_category_info.burn_rate)
            else:
                self.merchant['is_earn_enabled'] = False
                self.merchant['is_burn_enabled'] = False

        if not self.merchant:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                'message': TranslationManager.get_translation(
                    TranslationManager.merchant_details_not_found,
                    self.message_locale
                ),
                'code': 70
            }
            return self.send_response(self.response, self.status_code)

    def get_merchant_attributes(self, **kwargs):
        """
        Gets merchant attributes
        """
        self.merchant['is_tutorial'] = self.merchant.get('is_tutorial') > 0
        merchant_attributes = get_merchant_attributes_by_merchant_id(
            merchant_id=kwargs.get('merchant_id'),
            merchant_category=self.merchant.get('category'),
        )
        if merchant_attributes:
            self.merchant_attributes = format_merchant_attributes(
                kwargs.get('merchant_id'),
                merchant_attributes,
                self.merchant.get('category'),
                self.message_locale,
                self.company
            )
        else:
            self.merchant_attributes = None

    def get_delivery_menu_item(self, **kwargs):
        """
        Gets delivery menu items
        """
        # self.merchant_menu_items = get_menu_items(merchant_id=kwargs.get('merchant_id'), locale=self.message_locale)
        self.merchant_menu_items = {}
        # try:
        #     if self.merchant_menu_items.get('delivery_tutorials_info')[3]:
        #         del self.merchant_menu_items['delivery_tutorials_info'][3]
        # except IndexError:
        #     pass

    def get_active_outlets(self, **kwargs):
        """
        Grab active outlets for this merchant
        """
        self.outlets = Outlet.find_by_merchant(
            merchant_id=kwargs.get('merchant_id'),
            location_id=0,
            latlong=self.lat_long,
            locale=self.message_locale,
        )
        inject_distances_and_sort(self.outlets, self.lat_long)
        self.outlets = sorted(self.outlets, key=itemgetter('distance'))

        for outlet in self.outlets:
            if not outlet['delivery_telephone']:
                outlet['delivery_telephone'] = self.merchant.get('delivery_contact_no')
            self.outlet_ids.append(outlet.get('id'))

            if outlet.get('name') and 'Ritz-Carlton' not in outlet.get('name'):
                outlet_name_parts = outlet['name'].split('-')
                outlet['name'] = outlet_name_parts[-1].strip()

    def load_customer_object(self):
        """
        Gets customer profile and populate the customer information
        """
        if self.customer.get('is_user_logged_in'):
            if self.customer_id:
                self.customer_info['user_id'] = self.customer_id
                cust_dmg_info = EntCustomerProfile.get_demographics_info(self.customer_id)
                if cust_dmg_info and cust_dmg_info.gender and cust_dmg_info.nationality and cust_dmg_info.birthdate:
                    self.customer_info['is_demographics_updated'] = 1
                else:
                    self.customer_info['is_demographics_updated'] = 0

                merchant_category_info = MerchantMapping.get_category_info_by_merchant_id(self.merchant['id'])
                if merchant_category_info and (merchant_category_info.is_earn_enabled or
                                               merchant_category_info.is_burn_enabled):
                    merchant_category = merchant_category_info.name
                    business_trigger = merchant_category_info.business_trigger
                    # get user balance info from lms
                    try:
                        lms_user = lms_manager.get_user_points(
                            self.customer['lms_member_id'],
                            business_trigger,
                            merchant_category
                        )
                        self.customer_info["current_balance"] = "{}".format(floor(lms_user.get('total_available_points', 0)))
                        if lms_user.get('total_available_points'):
                            self.customer_info['balance_description'] = USER_BALANCE_DESCRIPTION.format(
                                balance=self.customer_info["current_balance"]
                            )
                        else:
                            if merchant_category_info.sub_category_name == 'Mall Card':
                                self.customer_info["balance_description"] = USER_ZERO_BALANCE_DESCRIPTION_MALL_CARD
                            else:
                                self.customer_info["balance_description"] = USER_ZERO_BALANCE_DESCRIPTION
                    except Exception as e:
                        self.logger.warning("Unable to fetch points for merchant: {} for customer: {}".format(
                            self.merchant['id'], self.customer_id
                        ))

    def get_all_active_offers(self):
        """
        Gets the array of all active offers against this merchant
        """
        self.offers = Outlet.find_by_outlets(
            outlet_ids=self.outlet_ids,
            is_cuckoo=self.is_cuckoo,
            category=self.category,
            locale=self.message_locale,
            user_include_cheers=self.user_include_cheers,
            product_ids=self.customer.get('product_ids'),
        )

        self.offers = set_offers_data(
            offers=self.offers,
            offer_categories=self.offer_categories,
            offer_sub_categories=self.offer_sub_categories,
            session_data=self.customer
        )

        if self.offer_categories:
            self.merchant['category'] = self.offer_categories[0]
        else:
            self.merchant['category'] = ""
        self.merchant['categories'] = self.offer_categories
        self.merchant['merchant_categories'] = self.offer_categories
        self.merchant['categories_analytics'] = get_category_codes_for_analytics(
            self.offer_categories
        )
        self.merchant['offer_categories'] = self.offer_categories
        self.merchant['sub_categories'] = self.offer_sub_categories
        self.merchant['digital_section'] = ', '.join([str(sub_category) for sub_category in self.offer_sub_categories])

    def get_outlets_having_offers(self):
        """
        Outlet id having offers
        """
        for offer in self.offers:
            for id in offer.get('outlet_ids'):
                self.outlet_ids_having_offers.append(id)

    def get_outlets_present_in_offer_list(self):
        """
        Get the outlets present in offer list
        """
        outlet_ids_having_offers = set(self.outlet_ids_having_offers)
        for outlet in self.outlets:
            for outlet_ids_having_offer in outlet_ids_having_offers:
                if outlet_ids_having_offer == outlet.get('id'):
                    self.outlets_filtered.append(outlet)
                    if outlet.get('merlin_url'):
                        self.outlet_merlin_urls[outlet["id"]] = outlet.get('merlin_url')
        self.outlet_ids_having_offer = ''

    def sort_offers_list(self):
        """
        Sort offers list according to the given params
        """
        self.offers = multi_key_sort(
            self.offers,
            columns=[
                '-is_purchased', '-is_monthly', '-is_new', '-is_delivery', '-is_cheers', 'product_id'
            ]
        )

    def set_offer_currency(self):
        """
        Sets currency and check whether product_name already exist in the offers array
        """
        for offer in self.offers:
            offer['savings_estimate_aed'] = offer.get('savings_estimate')
            if (
                self.currency.lower() == offer['local_currency'].lower() and
                offer.get('savings_estimate_local_currency')
            ):
                offer['savings_estimate'] = offer.get('savings_estimate_local_currency')
            else:
                offer['savings_estimate'] = ExchangeRate.get_conversion_rate(
                    offer.get('savings_estimate'),
                    'AED',
                    self.currency
                )
            offer['show_smiles_earn_value'] = False
            offer['smiles_earn_value'] = 0
            offer['smiles_burn_value'] = 0

            if offer.get('product_sku') in self.get_love_dining_skus:
                offer['is_merlin_offer'] = True
                offer["outlet_merlin_urls"] = self.outlet_merlin_urls
                offer['merlin_title'] = self.merchant.get('name')
            else:
                offer['is_merlin_offer'] = False
                offer['outlet_merlin_urls'] = []
                offer['merlin_title'] = ''

            if offer['is_delivery']:
                self.redeemability_for_delivery['total_offers'] = self.redeemability_for_delivery.get('total_offers', 0)
                self.redeemability_for_delivery['total_offers'] += offer['quantity_redeemable']
                self.redeemability_for_delivery['total_offers'] += offer['quantity_not_redeemable']
                self.delivery_offers_count += 1
            product_id_exists = False
            for offer_array in self.offers_array:
                if offer_array['product_id'] == offer.get('product_id'):
                    product_id_exists = True
            if not self.offers_array or not product_id_exists:
                self.offers_array.append({'product_id': offer.get('product_id')})

    def get_location_categories(self):
        """
        Gets location categories
        """
        if self.offers_array:
            self.categories = WlLocationCategory.get_location_categories(
                self.company,
                self.location_id,
                [self.user_group],
            )
            if self.categories:
                for index, category in enumerate(self.categories):
                    category = category._asdict()
                    self.categories[index] = category
                    category['tile_id'] = 1
            replace_241_type_with_141 = False
            self.offers_array = formulate_offer_details_array(
                offers=self.offers,
                offers_array=self.offers_array,
                message_locale=self.message_locale,
                is_skip_mode=not self.customer.get('is_user_logged_in'),
                categories=self.categories,
                company=self.company,
                replace_241_type_with_141=replace_241_type_with_141
            )

    def prepare_merchant_object(self):
        """
        Prepare merchant object for final response data
        """
        if self.delivery_offers_count > 0:
            self.merchant['has_delivery_offers'] = True
        else:
            self.merchant['has_delivery_offers'] = False

        self.merchant_menu_items['offers_remaining'] = "{total_offers} {messsage}".format(
            total_offers=self.redeemability_for_delivery.get('total_offers', 0),
            messsage=TranslationManager.get_translation(
                TranslationManager.delivery_offers_remaining,
                self.message_locale
            )
        )
        if not self.customer_info:
            self.customer_info['user_id'] = 0
            self.customer_info['is_demographics_updated'] = False
        self.merchant['merchant_attributes'] = self.merchant_attributes
        self.merchant['outlets'] = self.outlets_filtered or self.outlets
        self.merchant['offers'] = self.offers_array
        self.merchant['delivery_section'] = self.merchant_menu_items
        self.merchant['customer'] = self.customer_info

    def set_important_section(self):
        self.merchant["is_important_active"] = self.important_info_section
        self.merchant["important_title"] = "Important Information"
        self.merchant["important_des"] = '''Make sure to use your linked card when purchasing to earn points.
         Not linked any cards yet? <a href="adrentertainer://linkcard"><strong>Link here</strong></a>'''

    def prepare_response(self):
        """
        Sets final response for merchant api
        :rtype: dict
        """
        self.send_response_flag = True
        self.response = {
            'success': True,
            'message': 'success',
            'data': self.merchant,
            'code': 0
        }
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Control the flow of merchant api
        """
        self.initialize_local_variables()
        self.initialize_class_attributes()
        self.set_current_customer_data()
        self.get_merchant(**kwargs)
        if self.is_send_response_flag_on():
            return
        self.get_merchant_attributes(**kwargs)
        self.get_delivery_menu_item(**kwargs)
        self.get_active_outlets(**kwargs)
        self.load_customer_object()
        self.get_all_active_offers()
        self.get_outlets_having_offers()
        self.get_outlets_present_in_offer_list()
        self.sort_offers_list()
        self.set_offer_currency()
        self.get_location_categories()
        self.prepare_merchant_object()
        self.set_important_section()
        self.prepare_response()
