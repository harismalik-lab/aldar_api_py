"""
Validates Api
    - Find user by email
        - if exists set vars corresponding user info
    - get wl_company and check its subscription status
    - try to validate given key
        - if key validated
            - assign key to user
            - update user's all sessions
            - get email template for user
            - insert a new record for EntSendEmail
        - if key is not validated then return response regarding key status
"""
import random

from flask import current_app, request
from phpserialize import dumps as php_json_dumps
from requests import codes

from api.v1.promo_code.validation import validates_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.api_utils import get_api_configurations
from common.base_resource import BasePostResource
from common.constants import ADR, CAPTCHA_FAILED_ERR_CODE
from models.aldar_app.rule import Rule
from models.aldar_app.user import User
from models.consolidation.ent_send_email import EntSendEmail
from models.entertainer_web.wl_product import WlProduct
from models.entertainer_web.wl_template import Wltemplate
from models.entertainer_web.wl_user_group import WlUserGroup
from models.entertainer_web.wlvalidation import Wlvalidation
from user_authentication.authentication import get_current_customer
from utils.api_utils import get_locale
from models.entertainer_web.session import Session
from utils.captcha_v3 import captcha_v3


class ValidatesApi(BasePostResource):
    """
    @api {POST} /v1/validates | Post Validates.

    @apiGroup UserService
    @apiParam {String}                                  email                       User Email
    @apiParam {String}                                  key                         Validation Key
    @apiParam {Boolean}                                 [is_secondary_key]          Check Secondary Key
    @apiParam {Boolean}                                 [afterlogin]                Afterlogin Check
    @apiParam {String="en", "ar", "cn", "el","zh"}      [language]                  Response Language
    @apiParam {Boolean}                                 [using_branch_activation]   Using Branch Activation
    """
    request_parser = validates_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='validates_api/validates_api.log',
        ),
        'name': 'validates_api'
    }
    required_token = True
    strict_token = True

    def populate_request_arguments(self):
        """
        Add request arguments of config api
        """
        self.locale = self.request_args.get('language')
        self.email = self.request_args.get('email')
        self.key = self.request_args.get('key')
        self.is_secondary_key = self.request_args.get('is_secondary_key')
        self.after_login = self.request_args.get('afterlogin')
        self.using_branch_activation = self.request_args.get('using_branch_activation')
        self.updated_user_group = self.request_args.get('updated_group')
        # following param deals with captcha_v3
        self.captcha_token = self.request_args.get('captcha_token')

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.company = ADR
        self.locale = get_locale(self.locale)
        self.is_key_validated = False
        self.is_customer_exists = False
        self.message = 'Invalid promo code.'

        self.existing_user_id = 0

        self.customer = get_current_customer()
        self.aldar_user_id = self.customer.get('aldar_user_id', 0)
        self.customer_id = self.customer.get('customer_id', 0)
        self.email_data = {'user_id': 0}
        self.email_data_optional = php_json_dumps({}).decode(errors="ignore")
        self.configs = get_api_configurations(self.company, current_app.config.get('ENV'))
        self.captcha_enabled = self.configs.get(Rule.IS_CAPTCHA_VERIFICATION, False)

    def captcha_validation(self):
        """
        - get `bypass_captcha_token` from request headers.
        - validate key.
        - if validated, set `self.captcha_enabled` False.
        """
        bypass_captcha_token = request.headers.get('bypass_captcha_token')
        if bypass_captcha_token == current_app.config.get('BYPASS_CAPTCHA_TOKEN'):
            self.captcha_enabled = False

    def captcha_verification(self):
        """
        Verify google captcha authentication
            - send token to google's verification url with captcha token
            - returns True/False as verification status
            - if not verified, set `send_response_flag` as `True`
        """
        captcha_verified = False
        if self.captcha_token:
            captcha_verified = captcha_v3.verify_captcha(response=self.captcha_token)
        if not captcha_verified:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message='Bad request please retry',
                custom_code=CAPTCHA_FAILED_ERR_CODE
            )
            return self.send_response(self.response, self.status_code)

    def check_key_is_passed(self):
        """
        Validates key is passed
        """
        if not self.key:
            self.send_response_flag = True
            self.response = {
                'data': {
                    'validation_status': self.is_key_validated,
                    'is_customer_exists': self.is_customer_exists
                },
                'success': True,
                'message': 'Missing required parameter "key".'
            }
            self.status_code = codes.BAD_REQUEST

            return self.send_response(self.response, self.status_code)

    def validate_key_less_activation(self):
        """
        Validates key less activation parameters
        """
        if not self.updated_user_group:
            self.send_response_flag = True
            self.response = {
                'data': {
                    'validation_status': self.is_key_validated,
                    'is_customer_exists': self.is_customer_exists
                },
                'success': True,
                'message': 'Missing required parameter "updated_group".'
            }
            self.status_code = codes.BAD_REQUEST

            return self.send_response(self.response, self.status_code)
        validation = Wlvalidation.get_active_by_company_email_and_user_group(
            self.company,
            self.email,
            self.updated_user_group
        )
        if validation:
            self.send_response_flag = True
            self.response = {
                'data': {
                    'validation_status': self.is_key_validated,
                    'is_customer_exists': self.is_customer_exists
                },
                'success': True,
                'message': 'User group already updated.'
            }
            self.status_code = codes.OK
            return self.send_response(self.response, self.status_code)

        if not WlUserGroup.get_group_info(self.updated_user_group, self.company):
            self.send_response_flag = True
            self.response = {
                'data': {
                    'validation_status': self.is_key_validated,
                    'is_customer_exists': self.is_customer_exists
                },
                'success': True,
                'message': 'Invalid "updated_group".'
            }
            self.status_code = codes.UNPROCESSABLE_ENTITY

            return self.send_response(self.response, self.status_code)
        wl_validation = Wlvalidation(
                wl_key='{}{}'.format(self.company[0:2], random.randint(1000000, 9999999)),
                wl_company=self.company,
                email=self.email,
                isused=0,
                active=1,
                user_group=self.updated_user_group,
                deactivation_date=None
            )
        wl_validation.insert_record()
        self.key = wl_validation.wl_key

    def get_customer_info(self):
        """
        - find user by email
            - if user exists set user related data
        """
        self.customer = User.get_active_by_id(self.aldar_user_id)
        self.email = self.customer.email
        self.is_customer_exists = True
        self.email_data['user_id'] = self.customer_id

    def get_url_from_config_and_change_company(self):
        """
        - get wl_company and check its subscription status
        - try to validate given key
        - if key validated
            - assign key to user
            - update user's all sessions
            - get email template for user
            - insert a new record for EntSendEmail
        :return:
        """
        validation_status = Wlvalidation.validate_key(self.key, self.company, self.email)
        if validation_status == Wlvalidation.INVALID_KEY:
            self.is_key_validated = False
            self.message = "Invalid promo code"

        if validation_status == Wlvalidation.ALREADY_ACTIVATED_VALID_KEY:
            self.is_key_validated = False
            self.message = "Promo code already activated"
        if validation_status == Wlvalidation.UNUSED_VALID_KEY:
            self.is_key_validated = True
        if not self.is_key_validated:
            self.send_response_flag = True
            self.response = {
                'data': {
                    'validation_status': self.is_key_validated,
                    'is_customer_exists': self.is_customer_exists
                },
                'success': True,
                'message': self.message
            }
            self.status_code = codes.UNPROCESSABLE_ENTITY

            return self.send_response(self.response, self.status_code)
        self.message = 'You have successfully unlocked more offers.'

        # bind a key with customer's email
        Wlvalidation.assign_key_to_customer(
            self.key,
            self.company,
            self.email,
            self.is_customer_exists,
            self.customer_id
        )

        # if customer exists, then get user groups
        if self.is_customer_exists:
            user_groups = Wlvalidation.get_user_groups(self.company, self.customer_id)
            if not user_groups:
                user_groups = [WlUserGroup.DEFAULT_USER_GROUP]
            configured_product_ids = WlProduct.get_configured_product_ids(self.company, user_groups)
            product_ids = ','.join(map(str, configured_product_ids))

            Session.update_all_sessions_for_customer(
                self.customer_id,
                product_ids,
                self.company
            )

            wl_validation_obj = Wlvalidation.get_user_group_id_by_key(self.key, self.company)
            if wl_validation_obj:
                user_group = wl_validation_obj.user_group
            else:
                user_group = WlUserGroup.DEFAULT_USER_GROUP

            # Get Email Template Based on the Company and User Group
            email_template = Wltemplate.get_template_by_company_and_type(
                self.company,
                Wltemplate.ACTIVATION_OF_TRAIL,
                user_group
            )

            # Send Email to Customer
            ent_send_email = EntSendEmail(
                email_to=self.email,
                email_template_data=php_json_dumps(self.email_data).decode(errors="ignore"),
                email_template_type_id=email_template.template_id if email_template else None,
                optional_data=php_json_dumps(self.email_data_optional).decode(errors="ignore"),
                language=self.locale,
                priority=EntSendEmail.PRIORITY_HIGH
            )
            ent_send_email.insert_record()

            self.is_key_validated = True
            self.message = 'You have successfully unlocked more offers'

    def generate_final_response(self):
        """
        generating final response.
        """
        self.send_response_flag = True
        self.response = {
            'data': {
                'validation_status': self.is_key_validated,
                'is_customer_exists': self.is_customer_exists
            },
            'success': True,
            'message': self.message
        }
        self.status_code = codes.ok

    def process_request(self, *args, **kwargs):
        self.setting_variables()
        self.captcha_validation()
        if self.captcha_enabled:
            self.captcha_verification()
            if self.send_response_flag:
                return
        if self.send_response_flag:
            return
        self.get_customer_info()
        if self.send_response_flag:
            return
        self.get_url_from_config_and_change_company()
        if self.is_send_response_flag_on():
            return
        self.generate_final_response()
        if self.is_send_response_flag_on():
            return
