"""
This module contains validation config for Travel Country API
"""
from flask_restful import reqparse

from common.constants import EN
from utils.custom_request_parsers import language, email

validates_parser = reqparse.RequestParser(bundle_errors=True)


validates_parser.add_argument(
    'language',
    type=language,
    required=False,
    default=EN,
    location='json'
)
validates_parser.add_argument(
    'email',
    type=email,
    required=False,
    location='json'
)
validates_parser.add_argument(
    'key',
    type=str,
    required=True,
    location='json'
)
validates_parser.add_argument(
    'is_secondary_key',
    type=bool,
    required=False,
    default=False,
    location='json'
)
validates_parser.add_argument(
    'afterlogin',
    type=bool,
    required=False,
    default=False,
    location='json'
)
validates_parser.add_argument(
    'using_branch_activation',
    type=bool,
    required=False,
    default=False,
    location='json'
)
validates_parser.add_argument(
    'updated_group',
    type=int,
    required=False,
    default=False,
    location='json'
)
validates_parser.add_argument(
    'captcha_token',
    type=str,
    required=False,
    location='json',
    default=''
)
