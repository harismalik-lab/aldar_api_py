"""
Hermes Data Validator
"""

from flask_restful import reqparse

from utils.custom_request_parsers import validate_platform

hermes_data_parser = reqparse.RequestParser(bundle_errors=True)

hermes_data_parser.add_argument(
    name="__platform",
    required=True,
    type=validate_platform,
    location='json'
)
