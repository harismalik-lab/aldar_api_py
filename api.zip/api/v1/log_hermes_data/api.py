"""
Log Hermes Data API
"""
from requests import codes

from api.v1.log_hermes_data.validation import hermes_data_parser
from common.base_resource import BasePostResource
from common.constants import ADR
from models.aldar_app.brasze_app_data import BrazeAppData
from user_authentication.authentication import get_current_customer


class LogHermesDataAPI(BasePostResource):
    logger_info = {
        'filename': '{file_path}'.format(
            file_path='log_hermes_data.log',
        ),
        'name': 'log_hermes_data'
    }
    required_token = True
    strict_token = True
    request_parser = hermes_data_parser

    def populate_request_arguments(self):
        self.platform = self.request_args.get('__platform')

    def set_class_attributes(self):
        """
        Sets class attributes
        """
        self.session_data = get_current_customer()
        self.user_id = self.session_data.get('aldar_user_id')

    def log_hermes_data(self):
        """
        Logs hermes data
        """
        try:
            af_hermes_data = BrazeAppData(user_id=self.user_id, platform=self.platform, company=ADR)
            af_hermes_data.insert_record()
        except Exception as e:
            self.logger.exception("Unable to log hermes data: {}".format(e))

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        self.response = self.generate_response_dict()
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.set_class_attributes()
        self.log_hermes_data()
        self.set_final_response()
