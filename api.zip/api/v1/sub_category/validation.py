"""
Sub Category API validation
"""
from flask_restful import reqparse

from common.constants import EN
from utils.custom_request_parsers import language

sub_category_parser = reqparse.RequestParser(bundle_errors=True)

sub_category_parser.add_argument(
    'category_id',
    type=str,
    required=True,
    location='json'
)
sub_category_parser.add_argument(
    'listing_type',
    type=str,
    required=True,
    location='json'
)
sub_category_parser.add_argument(
    'language',
    type=language,
    default=EN,
    location='json'
)
sub_category_parser.add_argument(
    'lat',
    type=float,
    required=False,
    location='json'
)
sub_category_parser.add_argument(
    'lng',
    type=float,
    required=False,
    location='json'
)
