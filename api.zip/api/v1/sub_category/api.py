"""
Sub Category API
- if `listing_type` is `category`:
    - returns all categories by `parent_id`
- if `listing_type` is `subcategory`:
    - get category if exists
    - get `merchant_ids` from `merchant_mappings` by `category_id` and `sub_category_ids`
    - get malls/hotles from `outlet` model by `merchant_ids`
    - query sub_categories model by category id
    - generate proper formatted response data
"""
from operator import itemgetter

from flask import current_app
from requests import codes

from api.v1.sub_category.validation import sub_category_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.api_utils import get_api_configurations
from common.base_resource import BasePostResource
from common.constants import (
    SECTION_IDENTIFIER,
    SUB_CATEGORIES,
    ALL_MALLS,
    ALL_HOTELS,
    DROPDOWN,
    DROPDOWN_ITEMS,
    MALLS,
    HOTELS,
    ADR,
    LISTING_TYPE_CATEGORY,
    LISTING_TYPE_SUBCATEGORY
)
from models.aldar_app.category import Category
from models.entertainer_web.merchant_mapping import MerchantMapping
from models.aldar_app.sub_category import SubCategory
from models.entertainer_web.api_configuration import ApiConfiguration
from models.entertainer_web.outlet import Outlet
from utils.translation_manager import TranslationManager


class SubCategoryApi(BasePostResource):
    request_parser = sub_category_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='sub_category_api/sub_category_api.log',
        ),
        'name': 'sub_category_api'
    }
    required_token = False

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.listing_type = self.request_args.get('listing_type')
        self.category_id = self.request_args.get('category_id')
        self.locale = self.request_args.get('language')
        self.configs = get_api_configurations(ADR, current_app.config.get('ENV').lower())
        self.lat = self.request_args.get('lat')
        self.lng = self.request_args.get('lng')

    def initialize_class_attributes(self):
        """
        Initializes class attributes
        """
        self.sub_categories = {}
        self.section_items = []
        self.merchant_mapping = []
        self.merchant_ids = []
        self.category_ids = []
        self.sub_category_ids = []
        self.malls = False
        self.hotles = False
        self.more_outlets = []
        self.data = {}

    def get_category(self):
        """
        Gets category against id
        """
        self.parent_category = Category.get_by_id(self.category_id)
        if not self.parent_category:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Invalid 'category_id' provided"
            )
            return self.send_response(self.response, self.status_code)

    def get_merchant_ids_by_categories(self):
        """
        query MerchantMapping model to get merchants with given category
        """
        self.merchant_mapping = MerchantMapping.get_against_category_and_subcategory(
            category_list=[self.parent_category.api_name],
            subcategory_list=self.sub_category_ids
        )
        if self.merchant_mapping:
            for mapping in self.merchant_mapping:
                self.merchant_ids.append(mapping.et_merchant_id)

    def get_malls_or_hotels(self):
        """
        get more outlets by category or subcategory ids based on malls or hotels
        """
        if self.parent_category.name.lower() in self.configs.get(ApiConfiguration.MALLS_CATEGORIES, '').split(','):
            self.malls = True
        if self.parent_category.name.lower() in self.configs.get(ApiConfiguration.HOTELS_CATEGORIES, '').split(','):
            self.hotles = True
        if self.malls or self.hotles:
            self.more_outlets = Outlet.get_malls_or_hotels_by_merchant_ids(self.merchant_ids, self.malls, self.hotles,
                                                                           lat=self.lat, lng=self.lng)

    def get_subcategories(self):
        """
        - query sub_category model by category_id
        - append in section_items as dict
        """
        self.sub_categories = SubCategory.get_sub_categories_by_category_id(self.parent_category.id)
        for category in self.sub_categories:
            self.sub_category_ids.append(category.api_name)
            self.section_items.append(category._asdict())

    def generate_categories_data(self):
        """
        set format for response data
        """
        self.sub_categories_data = {
            'title': self.parent_category.display_name,
            'sections': []
        }
        show_all = {}

        if self.malls:
            show_all['dropdown_type'] = MALLS
            show_all['title'] = ALL_MALLS

        if self.hotles:
            show_all['dropdown_type'] = HOTELS
            show_all['title'] = ALL_HOTELS

        if show_all and self.more_outlets:
            show_all[SECTION_IDENTIFIER] = DROPDOWN
            unique_checker = {}
            drop_down = []
            for outlet in self.more_outlets:
                if not outlet.name:
                    continue
                if not unique_checker.get(outlet.name):
                    drop_down.append(outlet._asdict())
                unique_checker[outlet.name] = True
            if self.lat and self.lng:
                show_all[DROPDOWN_ITEMS] = sorted(drop_down, key=itemgetter('distance'))
                # if self.malls and show_all[DROPDOWN_ITEMS]:
                #     show_all[DROPDOWN_ITEMS].insert(0, {'selected': True, 'name': ALL_MALLS, 'distance': 0})
            else:
                show_all[DROPDOWN_ITEMS] = sorted(drop_down, key=itemgetter('name'))
            self.sub_categories_data['sections'].append(show_all)

        self.sub_categories_data['sections'].append(
                {
                    'title': self.parent_category.display_name,
                    'deeplink': self.parent_category.deep_link,
                    'show_all_offers': 1,
                    SECTION_IDENTIFIER: SUB_CATEGORIES,
                    'section_items': self.section_items
                }
        )
        self.data = self.sub_categories_data

    def get_categories_data(self):
        """
        get all categories by parent_identifier
        """
        self.parent_identifier = self.category_id
        categories = Category.get_all_by_parent_id(self.parent_identifier)
        self.data = {
            'title': self.parent_identifier,
            'sections': [],
        }
        for category in categories:
            self.section_items.append(category._asdict())

        self.data['sections'].append(
            {
                'title': self.parent_identifier,
                'deeplink': '',
                'show_all_offers': 0,
                SECTION_IDENTIFIER: SUB_CATEGORIES,
                'section_items': self.section_items
            }
        )

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        data = self.data
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialize_class_attributes()
        if self.listing_type == LISTING_TYPE_SUBCATEGORY:
            self.get_category()
            if self.send_response_flag:
                return
            self.get_subcategories()
            self.get_merchant_ids_by_categories()
            self.get_malls_or_hotels()
            self.generate_categories_data()
        if self.listing_type == LISTING_TYPE_CATEGORY:
            self.get_categories_data()
        self.set_final_response()
