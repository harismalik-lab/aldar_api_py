"""
Filters API
Returns list of categories and sub categories
"""
from flask import current_app
from requests import codes

from api.v1.filters.utils import get_all_with_subcategories
from api.v1.filters.validation import filter_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.api_utils import get_api_configurations
from common.base_resource import BasePostResource
from common.constants import PUBLIC_CONFIGS, ADR
from models.aldar_app.sub_category import SubCategory
from models.entertainer_web.api_configuration import ApiConfiguration
from utils.translation_manager import TranslationManager


class FiltersAPI(BasePostResource):
    request_parser = filter_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='filters/filters.log',
        ),
        'name': 'filters'
    }
    required_token = False

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.is_earn = self.request_args.get('is_earn')
        self.is_burn = self.request_args.get('is_burn')
        self.environment = current_app.config['ENV']
        self.api_configs = get_api_configurations(ADR, self.environment, PUBLIC_CONFIGS)

    def initialize_local_veriables(self):
        """
        Initializes local veriables
        """
        self.filters = []
        self.trending = []

    def set_filters(self):
        """
        Sets filters list
        """
        self.filters = get_all_with_subcategories(is_earn=self.is_earn, is_burn=self.is_burn)
        trendings = SubCategory.get_trending()
        for trending in trendings:
            self.trending.append({'title': trending.name, 'deeplink': trending.deep_link})

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        data = {
            'filters': self.filters,
            'filters_version': self.api_configs.get(ApiConfiguration.FILTERS_VERSION, 1),
            'trending': self.trending
        }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables()
        self.set_filters()
        self.generate_final_response()
