"""
Filters API Util methods
"""
from collections import OrderedDict

from flask import g

from models.aldar_app.category import Category

cache = g.cache


@cache.memoize(timeout=86400)
def get_all_with_subcategories(is_earn=None, is_burn=None):
    """
    Prepares a list of subcategories under respective categories object
    Returns list:
    """
    categories_dict = OrderedDict()
    for result_row in Category.get_all_with_subcategories_query(is_earn=is_earn, is_burn=is_burn):
        current_row_dict = categories_dict.get(result_row.category_id)
        if not current_row_dict:
            categories_dict[result_row.category_id] = {
                'sub_categories': [],
                'category_description': result_row.category_description,
                'category_icon': result_row.category_icon,
                'category_image': result_row.category_image,
                'category_location_id': result_row.category_location_id,
                'category_name': result_row.category_name,
                'category_id': result_row.category_id,
                'category_api_name': result_row.category_api_name
            }
        if result_row.subcategory_id:
            sub_category_dict = {
                'subcategory_id': result_row.subcategory_id,
                'subcategory_name': result_row.subcategory_name,
                'subcategory_description': result_row.subcategory_description,
                'subcategory_icon': result_row.subcategory_icon,
                'subcategory_image': result_row.subcategory_image,
                'subcategory_location_id': result_row.subcategory_location_id,
                'subcategory_earn_rate': str(result_row.earn_rate),
                'subcategory_burn_rate': str(result_row.burn_rate),
                'subcategory_api_name': result_row.subcategory_api_name
            }
            categories_dict[result_row.category_id]['sub_categories'].append(sub_category_dict)
        if not categories_dict[result_row.category_id]['sub_categories']:
            categories_dict[result_row.category_id]['category_earn_rate'] = str(result_row.earn_rate)
            categories_dict[result_row.category_id]['category_burn_rate'] = str(result_row.burn_rate)
    return list(categories_dict.values())
