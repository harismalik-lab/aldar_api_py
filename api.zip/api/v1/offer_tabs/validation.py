"""
Validation params of app tabs api
"""
from flask_restful import reqparse

from common.constants import EN
from utils.custom_request_parsers import language

app_tabs_parser = reqparse.RequestParser(bundle_errors=True)

app_tabs_parser.add_argument(
    name="language",
    type=language,
    default=EN,
    required=False,
    location='args'
)
app_tabs_parser.add_argument(
    'location_id',
    type=int,
    required=False,
    location='args'
)
