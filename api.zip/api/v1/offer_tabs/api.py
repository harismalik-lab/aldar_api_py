"""
Offer tabs API
"""
from requests import codes

from api.v1.offer_tabs.validation import app_tabs_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from common.constants import ADR, MAX_OUTLETS
from utils.api_utils import get_tabs_cached


class OfferTabsAPI(BasePostResource):
    request_parser = app_tabs_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='offer_tabs_api_api.log',
        ),
        'name': 'login_api'
    }
    required_token = False

    def populate_request_arguments(self):
        self.company = ADR
        self.locale = self.request_args.get('language')

    def get_tabs(self):
        """
        Gets tabs from db
        """
        self.tabs = get_tabs_cached(self.company, self.locale)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = codes.OK
        self.response = {
            'data': {
                'limit': MAX_OUTLETS,
                'tabs': self.tabs,
            },
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.get_tabs()
        self.generate_final_response()
