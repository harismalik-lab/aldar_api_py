"""
Update User Phone validation
"""
from api.v1.register_mobile.validation import register_mobile_parser

update_phone_validation = register_mobile_parser.copy()
update_phone_validation.remove_argument('otp')

update_phone_validation.add_argument(
    'otp',
    type=int,
    required=True,
    location='json'
)
