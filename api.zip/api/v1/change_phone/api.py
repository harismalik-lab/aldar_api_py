"""
Change Mobile Number API
"""
from requests import codes

from api.v1.change_phone.validation import update_phone_validation
from api.v1.register_mobile.api import RegisterMobileAPI
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from models.aldar_app.user import User
from models.entertainer_web.session import Session
from user_authentication.authentication import get_current_customer
from utils.lms_manager import lms_manager


class ChangePhoneAPI(RegisterMobileAPI):
    strict_token = True
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='change_phone_api_api.log',
        ),
        'name': 'change_phone_api'
    }
    request_parser = update_phone_validation

    def initialize_class_attributes(self):
        """
        Initializes class attributes
        """
        self.session_data = get_current_customer()
        self.user_id = self.session_data.get('user_id')
        self.aldar_user_id = self.session_data['aldar_user_id']

    def get_active_user(self):
        """
        Gets active user data
        """
        self.user = User.get_active_by_id(self.aldar_user_id)

    def update_user_phone(self):
        """
        Updates User phone
        """
        lms_manager.update_lms_user_mobile_number(self.user.lms_membership_id, self.msisdn)
        self.user.mobile_no = self.msisdn
        self.user.update_record()

    def deactivate_other_active_sessions(self):
        """
        This method will deactivate user sessions except the current one
        """
        Session.deactivate_other_than_this_auth_token(self.session_data['session_token'], self.user_id)

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        self.response = self.generate_response_dict(
            success_flag=True,
            message="Phone number updated successfully"
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialize_class_attributes()
        self.verify_otp_and_phone()
        if self.send_response_flag:
            return
        self.get_active_user()
        self.update_user_phone()
        self.deactivate_other_active_sessions()
        self.set_final_response()
