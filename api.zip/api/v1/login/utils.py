"""
login api utils
"""
import datetime
from models.consolidation.login_attempt import LoginAttempt


def check_same_device_users_login_attempts(
        enable_rate_limiting, device_id, same_device_login_attempts_check=True
):
    """
    Here we get how many users have attempted to login from the same device within 30 minutes and if it is greater or
    equal to 4 then retuen True otherwise False.
    """
    attempts = 0
    if enable_rate_limiting and same_device_login_attempts_check:
        look_up_date_time = datetime.datetime.now() - datetime.timedelta(minutes=30)
        attempts = LoginAttempt.get_same_device_login_attempts_in_given_time_count(
            device_id,
            look_up_date_time
        )
    if attempts >= LoginAttempt.SAME_DEVICE_ALLOWED_USERS:
        return True
    return False
