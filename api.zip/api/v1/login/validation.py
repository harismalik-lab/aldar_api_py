"""
Login API validation
"""
from flask_restful import reqparse
from flask_restful.inputs import regex

from common.constants import EN
from utils.custom_request_parsers import language, device_list_for_sign_up

login_parser = reqparse.RequestParser(bundle_errors=True)

login_parser.add_argument(
    name="msisdn",
    type=regex(r'^\+(?:[0-9]●?){6,14}[0-9]$'),
    required=True,
    location='json'
)
login_parser.add_argument(
    name='password',
    type=str,
    required=True,
    location='json'
)
login_parser.add_argument(
    'language',
    type=language,
    default=EN,
    location='json'
)
login_parser.add_argument(
    '__platform',
    type=str,
    default='ios',
    location='json'
)
login_parser.add_argument(
    'device_key',
    type=str,
    default='',
    location='json'
)
login_parser.add_argument(
    'app_version',
    type=str,
    default='v1',
    location='json'
)
login_parser.add_argument(
    'captcha_token',
    type=str,
    required=False,
    location='json',
    default=''
)
login_parser.add_argument(
    'platform',
    type=regex('[a-zA-Z]*'),
    required=False,
    location='json'
)
login_parser.add_argument(
    '__platform',
    type=regex('[a-zA-Z]*'),
    required=False,
    location='json'
)
login_parser.add_argument(
    'device_key',
    type=str,
    required=False,
    location='json'
)
login_parser.add_argument(
    'device_os',
    type=device_list_for_sign_up,
    required=False,
    location='json'
)
login_parser.add_argument(
    'device_model',
    type=str,
    required=False,
    location='json'
)
login_parser.add_argument(
    'device_uid',
    type=str,
    required=False,
    location='json'
)
