"""
Login API
"""
import datetime
import time
import uuid

from flask import current_app, request
from jwt import encode
from requests import codes

from api.v1.login.utils import check_same_device_users_login_attempts
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from api.v1.login.validation import login_parser
from common.api_utils import get_diff_in_hours_minutes_seconds, get_api_configurations
from common.base_resource import BasePostResource
from common.constants import ADR, CAPTCHA_FAILED_ERR_CODE
from models.aldar_app.rule import Rule
from models.consolidation.login_attempt import LoginAttempt
from models.entertainer_web.session_addendum import SessionAddendum
from models.entertainer_web.wl_product import WlProduct
from models.entertainer_web.wl_user_group import WlUserGroup
from models.entertainer_web.session import Session
from models.aldar_app.user import User
from models.entertainer_web.wlvalidation import Wlvalidation
from utils.api_utils import get_user_tier_dict
from utils.captcha_v3 import captcha_v3
from utils.translation_manager import TranslationManager
from utils.security import security


class LoginAPI(BasePostResource):
    request_parser = login_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='login_api_api.log',
        ),
        'name': 'login_api'
    }
    required_token = False

    def populate_request_arguments(self):
        self.msisdn = self.request_args.get('msisdn')
        self.password = self.request_args.get('password')
        self.locale = self.request_args.get('language')
        self.app_version = self.request_args.get('app_version')

        # following param deals with captcha_v3
        self.captcha_token = self.request_args.get('captcha_token')

        self.device_id = self.request_args.get('device_uid') or self.request_args.get('device_key')
        self.device_model = self.request_args.get('device_model')
        self.device_os = self.request_args.get('device_os')
        self.platform = self.request_args.get('__platform')
        if not self.platform:
            self.platform = self.request_args.get('platform')
        self.device_key = self.request_args.get('device_key')

    def initialize_class_attributes(self):
        """
        Initializes class attributes
        """
        self.jwt = None
        self.wl_company = ADR
        self.same_device_login_attempts_check = True
        self.enable_rate_limiting = True
        self.create_user_login_attempt = True
        self.delete_login_attempt = True
        self.failed_login_attempts = 0
        self.configs = get_api_configurations(ADR, current_app.config.get('ENV'))
        self.captcha_enabled = self.configs.get(Rule.IS_CAPTCHA_VERIFICATION, False)

    def captcha_validation(self):
        """
        - get `bypass_captcha_token` from request headers.
        - validate key.
        - if validated, set `self.captcha_enabled` False.
        """
        bypass_captcha_token = request.headers.get('bypass_captcha_token')
        if bypass_captcha_token == current_app.config.get('BYPASS_CAPTCHA_TOKEN'):
            self.captcha_enabled = False

    def captcha_verification(self):
        """
        Verify google captcha authentication
            - send token to google's verification url with captcha token
            - returns True/False as verification status
            - if not verified, set `send_response_flag` as `True`
        """
        captcha_verified = False
        if self.captcha_token:
            captcha_verified = captcha_v3.verify_captcha(response=self.captcha_token)
        if not captcha_verified:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message='Bad request please retry',
                custom_code=CAPTCHA_FAILED_ERR_CODE
            )
            return self.send_response(self.response, self.status_code)

    def get_user_by_phone(self):
        """
        - if `msisdn` given, get user by phone number.
        - else get by `email`.
        """
        if self.msisdn:
            self.user = User.get_active_by_phone(self.msisdn)

    def validate_user(self):
        """
        Validates phone number
        """
        if not self.user:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.INVALID_PHONE,
                    self.locale
                )
            )
            return self.send_response(self.response, self.status_code)
        if self.user.password is None:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.INVALID_PHONE,
                    self.locale
                )
            )
            return self.send_response(self.response, self.status_code)

    def check_same_device_users_login_attempts(self):
        """
        Here we check that if 4 users have attempted to login from the same device within 30 minutes then lock device
        access.
        """
        attempts = check_same_device_users_login_attempts(
            self.enable_rate_limiting,
            self.device_id,
            self.same_device_login_attempts_check
        )
        if attempts:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                "message": TranslationManager.get_translation(
                    TranslationManager.DEVICE_BLOCKED_MESSAGE, self.locale
                ),
                "success": False,
                "code": 70,
                "data": []
            }
            return self.send_response(self.response, self.status_code)

    def get_user_login_attempts(self):
        """
        Here we check user number of login attempts.
        """
        if self.enable_rate_limiting:
            look_up_date_time = datetime.datetime.now() - datetime.timedelta(minutes=30)
            attempts = LoginAttempt.get_user_login_attempts_in_given_time(
                self.user.email,
                look_up_date_time
            )
            if attempts:
                # check if user last attempt has lock duration and lock duration unit value set then calculate user lock
                # duration time and if it is less then current time then return lock duration message
                if attempts[0].lock_duration and attempts[0].lock_duration_units:
                    lock_duration = attempts[0].date_created + datetime.timedelta(
                        seconds=attempts[0].lock_duration or 0
                    )
                    current_time = datetime.datetime.now()
                    if current_time < lock_duration:
                        time_diff = lock_duration - current_time
                        time_diff_units = TranslationManager.get_translation(
                            TranslationManager.Time_Difference_Units,
                            self.locale
                        )
                        remaining_time = get_diff_in_hours_minutes_seconds(time_diff, *time_diff_units)
                        if remaining_time:
                            self.create_user_login_attempt = False
                            self.send_response_flag = True
                            self.status_code = 422
                            self.response = {
                                "message": TranslationManager.get_translation(
                                    TranslationManager.Wrong_Password_Login_Failure,
                                    self.locale
                                ).format(time=remaining_time),
                                "success": False,
                                "code": 70,
                                "data": []
                            }
                            return

                # count user consecutive failed login attempts
                for index, attempt in enumerate(attempts):
                    # check if user has success fully logged in or blocked in previous attempts
                    if attempt.is_logged_in or attempt.lock_duration_units:
                        break
                    self.failed_login_attempts += 1
                    if (index + 1) == LoginAttempt.ALLOWED_USER_WRONG_LOGIN_ATTEMPTS:
                        break

    def create_user_login_attempt_record(self):
        """
        Create user login attempt record with is_logged_in value as False.
        """
        if self.enable_rate_limiting and self.create_user_login_attempt:
            data = dict(
                api_version=self.api_version,
                ip=request.remote_addr,
                device_id=self.device_id,
                user_id=self.user.et_user_id,
                email=self.user.email,
                is_logged_in=False,
                company=ADR,
                is_active=1,
                platform=self.device_os,
                date_created=datetime.datetime.now()
            )
            if self.failed_login_attempts == LoginAttempt.ALLOWED_USER_WRONG_LOGIN_ATTEMPTS:
                data.update(lock_duration=LoginAttempt.LOCK_DURATION_30_SECONDS,
                            lock_duration_units=LoginAttempt.LOCK_DURATION_UNIT_SECONDS)
            self.login_attempt_record = LoginAttempt(**data).insert_record()

    def update_user_login_attempt(self):
        """
        Update user login attempt record with is_logged_in value as True and update lock duration and lock duration
        unit value to None if user login attempt is equal to allowed failed login attempts.
        """
        if self.enable_rate_limiting and self.login_attempt_record is not None:
            self.login_attempt_record.is_logged_in = True

            if self.failed_login_attempts == LoginAttempt.ALLOWED_USER_WRONG_LOGIN_ATTEMPTS:
                self.login_attempt_record.lock_duration = None
                self.login_attempt_record.lock_duration_units = None
            self.login_attempt_record.update_record()

    def delete_user_login_attempt(self):
        """
        Delete user login attempt
        """
        if self.enable_rate_limiting and self.delete_login_attempt:
            LoginAttempt.delete_record(self.login_attempt_record.id)

    def login(self):
        """
        Logs user in if password is provided
        """
        if self.password:
            if security.validate_password(self.password, self.user.password) or\
                    security.validate_hash_magento(self.password, self.user.password):
                try:
                    self.user_group_ids = Wlvalidation.get_user_groups(self.wl_company, self.user.et_user_id)
                    user_groups = self.user_group_ids
                    if not user_groups:
                        user_groups = [WlUserGroup.DEFAULT_USER_GROUP]
                    product_ids = WlProduct.get_configured_product_ids(self.wl_company, user_groups)
                    # noinspection PyArgumentList
                    session = Session(
                        session_token=str(uuid.uuid4()),
                        customer_id=self.user.et_user_id,
                        product_ids=','.join(map(str, product_ids)),
                        company=self.wl_company,
                        isagreed=True,
                        date_cached=time.time(),
                        date_agreed=datetime.datetime.now()
                    )
                    session.insert_record()
                    self.session_token = session.session_token
                    if session.id:
                        self.session_id = session.id
                    self.jwt = encode(
                        {
                            'session_token': session.session_token,
                            'api_token': current_app.config['ALDAR_API_TOKEN']
                        }, current_app.config['JWT_SECRET_KEY'], algorithm='HS256'
                    )
                except Exception:
                    self.delete_user_login_attempt()
            else:
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.response = self.generate_response_dict(
                    message=TranslationManager.get_translation(
                        TranslationManager.INVALID_PASSWORD,
                        self.locale
                    )
                )
                return self.send_response(self.response, self.status_code)

    def create_session_addendum(self):
        """
        create session addendum record
        """
        session_addendum = SessionAddendum(
            session_id=self.session_id,
            user_id=self.user.et_user_id,
            device_key=self.device_key,
            device_os=self.platform,
            device_model=self.device_model,
            device_language=self.locale,
            company=self.wl_company,
            is_gdpr_agreed=1,
            is_eula_agreed=1
        )
        session_addendum.insert_record()

    def get_user_profile(self):
        """
        Gets user profile
        """
        self.user_profile = self.user.json()

    def get_user_tier(self):
        """
        Gets user tier
        """
        if self.user and self.user.lms_membership_id:
            self.user_tier = get_user_tier_dict(self.user.lms_membership_id)
        else:
            self.user_tier = {}

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        data = {}
        if self.jwt:
            data = {
                'auth': {
                    'access_token': self.jwt.decode(),
                    'analytics_token': self.session_token
                },
                'user_profile': self.user_profile,
                'user_tier': self.user_tier
            }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialize_class_attributes()
        self.captcha_validation()
        if self.captcha_enabled:
            self.captcha_verification()
            if self.send_response_flag:
                return
        self.get_user_by_phone()
        self.validate_user()
        if self.send_response_flag:
            return
        self.check_same_device_users_login_attempts()
        if self.is_send_response_flag_on():
            return
        self.get_user_login_attempts()
        if self.is_send_response_flag_on():
            return
        self.create_user_login_attempt_record()
        if self.is_send_response_flag_on():
            return
        self.login()
        if self.send_response_flag:
            return
        self.create_session_addendum()
        self.get_user_profile()
        self.get_user_tier()
        self.update_user_login_attempt()
        self.set_final_response()
