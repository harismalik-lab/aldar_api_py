"""
Configs API
"""
from flask import current_app
from requests import codes

from api.v1.configs.validation import configs_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.api_utils import get_api_configurations
from common.base_resource import BasePostResource
from common.constants import PUBLIC_CONFIGS, LOCATION_CONFIGS, ADR, INSTRUCTION_CONFIGS
from utils.translation_manager import TranslationManager


class ConfigsAPI(BasePostResource):
    request_parser = configs_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='configs/configs.log',
        ),
        'name': 'configs'
    }
    required_token = False

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.company = ADR

    def initialize_local_veriables(self):
        """
        Initializes local veriables
        """
        self.environment = current_app.config.get('ENV').lower()
        self.configs = {}
        self.location = {}
        self.instructions_list = []

    def set_config_data(self):
        """
        Sets config data of config api
        """
        self.configs = get_api_configurations(
            self.company,
            self.environment,
            PUBLIC_CONFIGS
        )

    def set_location_data(self):
        for location_config in LOCATION_CONFIGS:
            location_config_key = "location_{}".format(location_config)
            config_value = self.configs.get(location_config_key, None)
            if config_value is not None:
                self.location[location_config] = config_value
            try:
                del self.configs[location_config_key]
            except KeyError:
                pass

    def set_instruction_screen_data(self):
        current_instruction_number = 1
        while True:
            current_instruction_dict = {}
            key_found = True
            for location_config in INSTRUCTION_CONFIGS:
                instruction_config_key = "instruction_screen_{0}_{1}".format(
                    location_config, current_instruction_number
                )
                config_value = self.configs.get(instruction_config_key, None)
                if config_value is not None:
                    current_instruction_dict[location_config] = config_value
                    del self.configs[instruction_config_key]
                else:
                    key_found = False
                    break
            if not key_found:
                break
            self.instructions_list.append(current_instruction_dict)
            current_instruction_number += 1

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        data = {
            'configs': self.configs,
            'location': self.location,
            'instructions_list': self.instructions_list
        }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables()
        self.set_config_data()
        self.set_location_data()
        self.set_instruction_screen_data()
        self.generate_final_response()
