"""
Forget Password API validation
"""

from flask_restful import reqparse
from flask_restful.inputs import regex

from common.constants import EN, ADR
from utils.custom_request_parsers import email, language

forget_password_parser = reqparse.RequestParser(bundle_errors=True)

forget_password_parser.add_argument(
    'email',
    type=email,
    required=True,
    location='json'
)
forget_password_parser.add_argument(
    'language',
    type=language,
    default=EN,
    location='json'
)
forget_password_parser.add_argument(
    'company',
    type=regex(r'[a-zA-Z-_]{2,9}'),
    default=ADR,
    location='json'
)
forget_password_parser.add_argument(
    'captcha_token',
    type=str,
    required=False,
    location='json',
    default=''
)
