"""
Forget Password API
It takes email of the user and create a password reset token and email password reset URL to user
"""
import datetime

from flask import current_app, request
from phpserialize import dumps as php_json_dumps
from requests import codes

from api.v1.forget_password.validation import forget_password_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.api_utils import get_api_configurations
from common.base_resource import BasePostResource
from common.constants import PASSWORD_RESET_EXPIRATION_IN_HOURS, CAPTCHA_FAILED_ERR_CODE, ADR
from models.aldar_app.rule import Rule
from models.aldar_app.user import User
from models.consolidation.ent_send_email import EntSendEmail
from utils.captcha_v3 import captcha_v3
from utils.security import security
from utils.translation_manager import TranslationManager


class ForgetPasswordAPI(BasePostResource):
    request_parser = forget_password_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='forget_password/forget_password.log',
        ),
        'name': 'forget_password'
    }
    required_token = False

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.email = self.request_args.get('email')
        self.locale = self.request_args.get('language')
        self.company = self.request_args.get('company')

        # following param deals with captcha_v3
        self.captcha_token = self.request_args.get('captcha_token')

    def initialize_class_attributes(self):
        """
        Initializes class attributes
        """
        self.configs = get_api_configurations(ADR, current_app.config.get('ENV'))
        self.captcha_enabled = self.configs.get(Rule.IS_CAPTCHA_VERIFICATION, False)

    def captcha_validation(self):
        """
        - get `bypass_captcha_token` from request headers.
        - validate key.
        - if validated, set `self.captcha_enabled` False.
        """
        bypass_captcha_token = request.headers.get('bypass_captcha_token')
        if bypass_captcha_token == current_app.config.get('BYPASS_CAPTCHA_TOKEN'):
            self.captcha_enabled = False

    def captcha_verification(self):
        """
        Verify google captcha authentication
            - send token to google's verification url with captcha token
            - returns True/False as verification status
            - if not verified, set `send_response_flag` as `True`
        """
        captcha_verified = False
        if self.captcha_token:
            captcha_verified = captcha_v3.verify_captcha(response=self.captcha_token)
        if not captcha_verified:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message='Bad request please retry',
                custom_code=CAPTCHA_FAILED_ERR_CODE
            )
            return self.send_response(self.response, self.status_code)

    def set_invalid_email_response(self):
        """
        Sets invalid email response
        """
        self.send_response_flag = True
        self.status_code = codes.UNPROCESSABLE_ENTITY
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.INVALID_EMAIL,
                self.locale
            )
        )
        return self.send_response(self.response, self.status_code)

    def verify_email(self):
        """
        Verifies email
        """
        self.user = User.get_active_by_email(self.email)
        if not self.user:
            return self.set_invalid_email_response()

    def generate_password_reset_token(self):
        """
        Generates password reset token and schedules email to the user for Password Reset URL
        """
        # Generating new random reset token
        password_reset_token = security.generate_random_string(length=20)
        # Updating password reset token and expiry of token
        self.user.password_reset_token = password_reset_token
        self.user.password_reset_expiry = datetime.datetime.now() + datetime.timedelta(
            hours=PASSWORD_RESET_EXPIRATION_IN_HOURS
        )
        self.user.update_record()

        email_data = php_json_dumps({
            "user_id": self.user.et_user_id,
            "{PASSWORD_RESET_URL}": current_app.config['PASSWORD_RESET_URL'].format(password_reset_token)
        })

        ent_send_email = EntSendEmail(
            email_template_type_id=current_app.config['FORGOT_PASSWORD_TEMPLATE_ID'],
            email_template_data=email_data.decode(errors='ignore'),
            email_to=self.email,
            language=self.locale,
            priority=EntSendEmail.PRIORITY_HIGH,
            created_date=datetime.datetime.now(),
            optional_data=php_json_dumps({}).decode(errors='ignore')
        )
        ent_send_email.insert_record()

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.PASSWORD_RESET_EMAIL_SENT,
                self.locale
            ),
            success_flag=True
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_class_attributes()
        self.captcha_validation()
        if self.captcha_enabled:
            self.captcha_verification()
            if self.send_response_flag:
                return
        self.verify_email()
        if self.send_response_flag:
            return
        self.generate_password_reset_token()
        self.generate_final_response()
