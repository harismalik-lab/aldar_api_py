"""
Burn API validation
"""
from flask_restful import reqparse

from utils.custom_request_parsers import check_positive

burn_api_validator = reqparse.RequestParser(bundle_errors=True)

burn_api_validator.add_argument(
    'concept_id',
    type=str,
    required=True,
    location='json'
)
burn_api_validator.add_argument(
    'value',
    type=check_positive,
    required=True,
    location='json'
)
burn_api_validator.add_argument(
    'merchant_pin',
    type=str,
    required=True,
    location='json'
)
