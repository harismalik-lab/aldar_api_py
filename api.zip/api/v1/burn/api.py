"""
Burn API
"""
from requests import codes, RequestException

from api.v1.burn.validation import burn_api_validator
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from common.constants import BURN_NOT_ENABLED_CODE, INVALID_CONCEPT_ID_CODE, NO_MAPPING_FOUND, EN, BURNED_DESCRIPTION
from models.entertainer_web.merchant_mapping import MerchantMapping
from models.entertainer_web.merchant import Merchant
from models.entertainer_web.outlet import Outlet
from user_authentication.authentication import get_current_customer
from utils.api_utils import generate_transaction_id
from utils.lms_manager import lms_manager
from utils.translation_manager import TranslationManager


class BurnAPI(BasePostResource):
    request_parser = burn_api_validator
    strict_token = True
    logger_info = {
        'filename': '{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='burn_api.log',
        ),
        'name': 'burn_api'
    }

    def populate_request_arguments(self):
        self.concept_id = self.request_args.get('concept_id')
        self.value = self.request_args.get('value')
        self.pin = self.request_args.get('merchant_pin')

    def initialise_local_variables(self):
        """
        Initialises local variables
        """
        self.user = get_current_customer()
        self.lms_member_id = self.user['lms_member_id']
        self.aldar_user_id = self.user['aldar_user_id']
        self.business_trigger = None
        self.business_category = None
        self.balance = 0
        self.redemption_reference_code = ''

    def validate_outlet_id(self):
        """
        Validates concept id
        """
        self.outlet = Outlet.get_info_by_concept_id(self.concept_id)
        if not self.outlet:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(custom_code=INVALID_CONCEPT_ID_CODE)
            return
        mapping = MerchantMapping.get_category_info_by_merchant_id(self.outlet.merchant_id)
        if not mapping:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(custom_code=NO_MAPPING_FOUND)
            return
        if not mapping.is_burn_enabled:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(custom_code=BURN_NOT_ENABLED_CODE)
            return
        self.business_trigger = mapping.business_trigger
        self.business_category = mapping.name
        self.merchant = Merchant.get_by_id(self.outlet.merchant_id)
        if not self.pin or not self.merchant or str(self.merchant.pin) != self.pin:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message='Invalid merchant pin')

    def burn(self):
        """
        Burns points
        """
        self.transaction_number = generate_transaction_id(self.concept_id)
        try:
            response = lms_manager.burn_points(
                lms_member_id=self.lms_member_id,
                value=self.value,
                business_trigger=self.business_trigger,
                business_category=self.business_category,
                transaction_id=self.transaction_number,
                concept_id=self.concept_id,
                concept_name=self.outlet.name,
                description=BURNED_DESCRIPTION,
                user_id=self.aldar_user_id
            )
            if response and response.get('status') != 0:
                self.transaction_number = None
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.response = self.generate_response_dict(message=TranslationManager.get_translation(
                    TranslationManager.UNABLE_TO_BURN
                ))
                return
            self.balance = response.get('redemption', {}).get('points_balance')
            self.redemption_reference_code = response.get('redemption', {}).get('redemption_reference_code')

        except RequestException as re:
            self.transaction_number = None
            self.send_response_flag = True
            message = TranslationManager.get_translation(TranslationManager.UNABLE_TO_BURN)
            for error in re.response.json().get('errors', []):
                message = error.get('message', message)
                break
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(message=message)

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        data = {
            'transaction_number': self.redemption_reference_code,
            'balance': self.balance
        }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                EN
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialise_local_variables()
        self.validate_outlet_id()
        if self.send_response_flag:
            return
        self.burn()
        if self.send_response_flag:
            return
        self.set_final_response()
