"""
Get transaction details
"""
from math import ceil, floor

from requests import codes

from api.v1.get_transaction_details.validation import transaction_detail_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from models.aldar_app.clo_transactions import CloTransaction
from models.aldar_app.user import User
from models.entertainer_web.merchant_mapping import MerchantMapping
from models.entertainer_web.outlet import Outlet
from user_authentication.authentication import get_current_customer
from utils.lms_manager import lms_manager


class GetTransactionDetailAPI(BasePostResource):
    request_parser = transaction_detail_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='get_transaction_detail_api.log',
        ),
        'name': 'transaction_detail'
    }
    required_token = True
    strict_token = True

    def populate_request_arguments(self):
        self.transaction_id = self.request_args.get('transaction_id')
        self.merchant_name = ""
        self.points = 0
        self.merchant_id = 0
        self.earn_rate = 0.50
        self.burn_rate = 0.04
        self.customer_id = get_current_customer()['aldar_user_id']
        self.lms_profile = {}

    def get_transaction(self):
        self.transaction = CloTransaction.get_by_id_and_user_id(self.transaction_id, self.customer_id)
        if not self.transaction:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Invalid 'transaction_id'"
            )
            return self.send_response(self.response, self.status_code)
        if self.transaction.resolution_status != CloTransaction.RESOLUTION_PENDING:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Transaction already resolved."
            )
            return self.send_response(self.response, self.status_code)

    def get_outlet(self):
        merchant = Outlet.get_merchant_name_by_concept_id(self.transaction.concept_id)
        if merchant:
            self.merchant_name = merchant.name
            self.merchant_id = merchant.merchant_id

    def get_points(self):
        if self.merchant_id:
            category_info = MerchantMapping.get_category_info_by_merchant_id(self.merchant_id)
            if category_info:
                self.earn_rate = category_info.earn_rate
                self.burn_rate = category_info.burn_rate
                user = User.get_active_by_id(self.customer_id)
                self.lms_profile = lms_manager.get_user_points(user.lms_membership_id, category_info.business_trigger,
                                                               category_info.name)

    def final_response(self):
        self.send_response_flag = True
        data = {
            "transaction_data": {
                "transaction_id": self.transaction_id,
                "title": "Thank you for shopping at {}".format(self.merchant_name),
                "transaction_datetime": str(self.transaction.transaction_datetime),
                "amount": str(self.transaction.amount_in_aed),
                "earn_rate": str(self.earn_rate),
                "burn_rate": str(self.burn_rate),
                "resolution_status": self.transaction.resolution_status,
                "earn_text": "{} Darna Pts. will be added to your balance".format(
                    ceil(self.transaction.amount_in_aed * self.earn_rate)
                ),
                "burn_text": "Redeem {} Darna Pts. and get AED {} Cashback".format(
                    floor(self.transaction.amount_in_aed * self.burn_rate),
                    self.transaction.amount_in_aed
                ),
                "rewards_text": "Your rewards balance {:,} Darna Pts.".format(
                    ceil(self.lms_profile.get('total_available_points', 0))
                )
            }
        }
        self.response = self.generate_response_dict(data=data)
        self.status_code = codes.ok

    def process_request(self, *args, **kwargs):
        self.get_transaction()
        if self.send_response_flag:
            return
        self.get_outlet()
        self.get_points()
        self.final_response()
