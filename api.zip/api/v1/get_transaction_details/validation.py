"""
Get transaction details API
"""
from flask_restful import reqparse

transaction_detail_parser = reqparse.RequestParser(bundle_errors=True)

transaction_detail_parser.add_argument(
    name="transaction_id",
    type=int,
    required=True,
    location='json'
)
