"""
Tiers API
    - get current_customer/aldar_user info
    - get user tier info (profile data) from lms
        - set common info to append in tiers list
        - set tier specific data
    - generate final response
"""
from requests import codes

from api.v1.tiers.validation import tiers_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from common.constants import (
    USER_INACTIVE,
    TIER_CONFIGS,
    TIER_BRONZE,
    TIER_NAME_BRONZE,
    TIER_NAME_SILVER,
    TIER_SILVER,
    TIER_NAME_GOLD,
    TIER_GOLD,
    AED,
    UPGRADE_TEXT,
    TIER_CATEGORY_BENEFITS,
    TIER_NAME_PLATINUM,
    TIER_PLATINUM
)
from models.aldar_app.earn import Earn
from models.aldar_app.user import User
from user_authentication.authentication import get_current_customer
from utils.api_utils import get_user_tier_dict
from utils.lms_manager import lms_manager
from utils.translation_manager import TranslationManager


class TiersApi(BasePostResource):
    request_parser = tiers_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='tiers_api/tiers_api.log',
        ),
        'name': 'tiers_api'
    }
    strict_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')

    def initialize_class_attributes(self):
        """
        Initializes class attributes
        """
        self.session_data = get_current_customer()
        self.customer_id = self.session_data.get('aldar_user_id', 0)
        self.user_tier = {}
        self.lms_tier_dict = {}

    def get_aldar_user(self):
        """
        get user by `aldar_user_id`.
        """
        self.user = User.get_active_by_id(self.customer_id)
        if not self.user:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.USER_INACTIVE,
                    self.locale
                ),
                custom_code=USER_INACTIVE
            )
            return self.send_response(self.response, self.status_code)

    def get_lms_tiers_info(self):
        """
        get user tier info from lms
        """
        lms_configs = lms_manager.get_lms_configs()
        lms_tier_list = lms_configs.get('tiers')
        for tier in lms_tier_list:
            self.lms_tier_dict[tier['tier_title']] = tier

    def get_tiers_info(self):
        """
        get user tier info from lms
        """
        self.user_tier = get_user_tier_dict(self.user.lms_membership_id)
        amount_spent = Earn.get_current_spend_aed(self.customer_id)
        # get common info to use in all tiers
        self.tier_common_info = {
            'card_id': self.user_tier['card_id'],
            "current_points": self.user_tier['current_balance'],
            "amount_spent":  amount_spent,
            "currency": AED,
            "is_current": False,
            "show_bar": False
        }

    def generate_tiers_data(self):
        """
        generates all tiers data
        - set all tiers list
        - append common tier info in all tiers
        - set current tier specific info
        - add category benefits into current tier
        """
        self.tier_list = [
            {
                "tier_name": TIER_NAME_BRONZE,
                "tier_image": TIER_CONFIGS.get(TIER_BRONZE)['card_url'],
                "end_range": TIER_CONFIGS.get(TIER_BRONZE)['range']
            },
            {
                "tier_name": TIER_NAME_SILVER,
                "tier_image": TIER_CONFIGS.get(TIER_SILVER)['card_url'],
                "end_range": TIER_CONFIGS.get(TIER_SILVER)['range']
            },
            {
                "tier_name": TIER_NAME_GOLD,
                "tier_image": TIER_CONFIGS.get(TIER_GOLD)['card_url'],
                "end_range": TIER_CONFIGS.get(TIER_GOLD)['range']
            }
        ]
        if self.user_tier.get('current_tier').lower() == TIER_NAME_PLATINUM.lower():
            self.tier_list.append(
                {
                    "tier_name": TIER_NAME_PLATINUM,
                    "tier_image": TIER_CONFIGS.get(TIER_PLATINUM)['card_url'],
                    "end_range": TIER_CONFIGS.get(TIER_PLATINUM)['range']
                }
            )
        for tier in self.tier_list:
            # update end_range from lms tier data
            lms_tier = self.lms_tier_dict.get(tier['tier_name'])
            if lms_tier:
                tier['end_range'] = lms_tier['range_to']

            # set common info    in each tier
            tier.update(self.tier_common_info)

            # set current tier info
            if tier['tier_name'].lower() == self.user_tier['current_tier'].lower():
                tier["is_current"] = True

            if self.user_tier['current_tier'].lower() == TIER_BRONZE:
                # set upgrade text as per tier
                if tier['tier_name'].lower() == TIER_NAME_BRONZE.lower():
                    tier[UPGRADE_TEXT] = "You are AED {} away from {} tier".format(
                        '{:,}'.format(int(tier['end_range'] - tier['amount_spent'])),
                        TIER_NAME_SILVER
                    )
                    tier["show_bar"] = True
                if tier['tier_name'].lower() == TIER_NAME_SILVER.lower():
                    tier[UPGRADE_TEXT] = "You are AED {} away from {} tier".format(
                        '{:,}'.format(int(tier['end_range'] - tier['amount_spent'])),
                        TIER_NAME_GOLD
                    )
                    tier["show_bar"] = True
            elif self.user_tier['current_tier'].lower() == TIER_SILVER:
                if tier['tier_name'].lower() == TIER_NAME_SILVER.lower():
                    tier[UPGRADE_TEXT] = "You are AED {} away from {} tier".format(
                        '{:,}'.format(int(tier['end_range'] - tier['amount_spent'])),
                        TIER_NAME_GOLD
                    )
                    tier["show_bar"] = True

            # adding category benefits
            tier['categories'] = TIER_CATEGORY_BENEFITS.get(tier['tier_name'].lower())
            # start loop from second element to add benefits into first `all` list
            tier['categories'][0]['benefits'] = []
            for i in tier['categories'][1:]:
                tier['categories'][0]['benefits'].extend(i['benefits'])

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        data = {
            'tiers': self.tier_list
        }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialize_class_attributes()
        self.get_aldar_user()
        if self.send_response_flag:
            return
        self.get_lms_tiers_info()
        self.get_tiers_info()
        self.generate_tiers_data()
        self.set_final_response()
