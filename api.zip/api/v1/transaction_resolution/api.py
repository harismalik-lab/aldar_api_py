"""
Transaction Resolution API
Resolves pending transaction with accrual/redemption
"""
import datetime
from math import floor, ceil

from requests import codes

from api.v1.transaction_resolution.validation import transaction_resolution_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from models.aldar_app.clo_transactions import CloTransaction
from models.aldar_app.user import User
from models.entertainer_web.merchant_mapping import MerchantMapping
from models.entertainer_web.outlet import Outlet
from user_authentication.authentication import get_current_customer
from utils.lms_manager import lms_manager
from utils.loyalty_facts_manager import LoyaltyFactsManager
from utils.translation_manager import TranslationManager


class TransactionResolutionAPI(BasePostResource):
    request_parser = transaction_resolution_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='transaction_resolution/transaction_resolution.log',
        ),
        'name': 'transaction_resolution'
    }
    strict_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.transaction_id = self.request_args.get('transaction_id')
        self.resolution_status = int(self.request_args.get('resolution_status'))

    def initialize_local_veriables(self):
        """
        Initializes local veriables
        """
        self.session_data = get_current_customer()
        self.customer_id = self.session_data.get('aldar_user_id', 0)
        self.earn_rate = 0
        self.burn_rate = 0
        self.balance = 0

    def set_pending_transaction(self):
        """
        Sets pending clo transaction
        """
        self.pending_clo_transaction = CloTransaction.get_pending_transaction_by_id_and_user_id(
            self.transaction_id, self.customer_id
        )
        if not self.pending_clo_transaction:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="No pending transaction found against id={}!".format(self.transaction_id)
            )

    def resolve_loyalty_facts_transaction(self):
        """
        Resolves pending transaction
        """
        self.resolution_response = LoyaltyFactsManager.transaction_resolution(
            self.pending_clo_transaction.clo_transaction_id, self.resolution_status
        )
        if not self.resolution_response or self.resolution_response["statusCode"] != 0:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=self.resolution_response["status_msg"] if self.resolution_response else "Something went wrong."
            )

    def update_pending_transaction(self):
        """
        Updates pending clo transaction
        """
        self.pending_clo_transaction.resolution_status = self.resolution_status
        self.pending_clo_transaction.resolution_datetime = datetime.datetime.now()
        self.pending_clo_transaction.update_record()

    def get_earn_burn_rate(self):
        outlet = Outlet.get_by_concept_id(self.pending_clo_transaction.concept_id)
        if outlet:
            mapping = MerchantMapping.get_category_info_by_merchant_id(outlet.merchant_id)
            if mapping:
                self.earn_rate = mapping.earn_rate
                self.burn_rate = mapping.burn_rate
                user = User.get_active_by_id(self.customer_id)
                balance = {}
                try:
                    balance = lms_manager.get_user_points(user.lms_membership_id, mapping.business_trigger,
                                                          mapping.name)
                except:
                    pass
                if balance:
                    self.balance = balance.get('total_available_points', 0)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        if self.resolution_status == CloTransaction.RESOLUTION_REDEEM:
            redeemed_points = floor(self.pending_clo_transaction.amount_in_aed * self.burn_rate)
            self.balance -= redeemed_points
            success_message = "You've successfully burned {} Pts.".format(redeemed_points)
        else:
            earned_points = ceil(self.pending_clo_transaction.amount_in_aed * self.earn_rate)
            self.balance += earned_points
            success_message = "You've successfully earned {} Pts. It will reflect to your account in {} days".format(
                earned_points,
                self.pending_clo_transaction.points_availability_after_days or 15
            )
        data = {
            "success_message": success_message,
            "balance_message": "Your new points balance is {:,} Darna Pts.".format(ceil(self.balance))
        }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables()
        self.set_pending_transaction()
        if self.send_response_flag:
            return
        self.resolve_loyalty_facts_transaction()
        if self.send_response_flag:
            return
        self.update_pending_transaction()
        self.get_earn_burn_rate()
        self.generate_final_response()
