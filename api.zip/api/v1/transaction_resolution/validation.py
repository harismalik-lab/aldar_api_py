"""
Transaction Resolution API API validation
"""

from flask_restful import reqparse
from flask_restful.inputs import regex

from common.constants import EN
from utils.custom_request_parsers import language, resolution_status

transaction_resolution_parser = reqparse.RequestParser(bundle_errors=True)

transaction_resolution_parser.add_argument(
    'language',
    type=language,
    default=EN,
    location='json'
)
transaction_resolution_parser.add_argument(
    'transaction_id',
    type=int,
    required=True,
    location='json'
)
transaction_resolution_parser.add_argument(
    'resolution_status',
    type=resolution_status,
    required=True,
    location='json'
)
