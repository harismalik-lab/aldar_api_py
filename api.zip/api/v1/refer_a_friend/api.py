"""
Refer a friend api
"""
from flask import current_app
from requests import codes

from api.v1.refer_a_friend.validation import refer_a_friend_api_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.api_utils import get_api_configurations
from common.base_resource import BasePostResource
from common.constants import REFER_A_FRIEND_SHARE_LINK, REFER_A_FRIEND_IMAGE, ADR
from models.entertainer_web.api_configuration import ApiConfiguration
from user_authentication.authentication import get_current_customer
from utils.translation_manager import TranslationManager


class ReferFriendApi(BasePostResource):
    """
    Setting the api arg_parser and log file path
    """
    request_parser = refer_a_friend_api_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='refer_a_friend.log',
        ),
        'name': 'refer_a_friend'
    }
    required_token = True
    strict_token = True

    def populate_request_arguments(self):
        """
        Setting the arguments
        """
        self.user_lms_member_id = get_current_customer().get('lms_member_id', 0)
        self.locale = self.request_args.get('language')
        self.configs = get_api_configurations(ADR, current_app.config.get('ENV').lower())

    def getting_referral_messages(self):
        """
        Get referral messages
        """
        self.friend_referral_message = TranslationManager.get_translation(
            TranslationManager.REFERRAL_SECTION_MESSAGE,
            self.locale
        )
        self.friend_referral_button_title = TranslationManager.get_translation(
            TranslationManager.SHARE_BUTTON_TITLE,
            self.locale
        )

    def setting_referral_section(self):
        """
        Setting referral section
        """
        self.referral_section = {
            'referral_section': {
                'share_link': self.configs.get(
                    ApiConfiguration.REFER_A_FRIEND_LINK, ""
                ).format(self.user_lms_member_id),
                'image_url': self.configs.get(ApiConfiguration.REFER_A_FRIEND_IMAGE, ""),
                'message': self.configs.get(ApiConfiguration.REFER_A_FRIEND_MESSAGE, ""),
                'share_button_title': self.configs.get(ApiConfiguration.REFER_A_FRIEND_BUTTON_TITLE, ""),
                'share_text': self.configs.get(ApiConfiguration.REFER_A_FRIEND_SHARE_TEXT, "")
            }
        }

    def generate_final_response(self):
        """
        Generate final response
        """
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale,
            ),
            success_flag=True,
            data=self.referral_section,
            custom_code=codes.OK
        )
        self.send_response_flag = True
        self.status_code = codes.OK

    def process_request(self, *args, **kwargs):
        """
        Process the request
        :return: Response
        """
        self.getting_referral_messages()
        self.setting_referral_section()
        self.generate_final_response()
