"""
refer a friend API params validator
"""

from flask_restful import reqparse

from common.constants import EN
from utils.custom_request_parsers import language

refer_a_friend_api_parser = reqparse.RequestParser(bundle_errors=True)

refer_a_friend_api_parser.add_argument(
    name="language",
    required=False,
    default=EN,
    type=language,
    location='args'
)
