"""
Reset Password API
It resets password using password reset token
"""
import datetime

from requests import codes

from api.v1.reset_password.validation import reset_password_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from models.aldar_app.user import User
from models.aldar_app.users_password_history import UsersPasswordHistory
from models.entertainer_web.session import Session
from utils.api_utils import is_password_previously_used
from utils.security import security
from utils.translation_manager import TranslationManager


class ResetPasswordAPI(BasePostResource):
    request_parser = reset_password_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='reset_password/reset_password.log',
        ),
        'name': 'reset_password'
    }
    required_token = False

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.password_token = self.request_args.get('password_token')
        self.password = self.request_args.get('password')
        self.confirm_password = self.request_args.get('confirm_password')
        self.locale = self.request_args.get('language')
        self.company = self.request_args.get('company')

    def return_error_response(self, status_code, message):
        """
        Generates error response and returns
        :param int status_code:
        :param str message:
        """
        self.status_code = status_code
        self.send_response_flag = True
        self.response = {
            "message": message,
            "code": status_code,
            "success": False
        }
        return self.send_response(self.response, self.status_code)

    def verify_password_token(self):
        """
        Verifies password token and its expiry
        """
        self.user = User.get_by_password_reset_token(self.password_token)
        if not self.password_token or not self.user:
            return self.return_error_response(
                codes.UNPROCESSABLE_ENTITY,
                TranslationManager.get_translation(
                    TranslationManager.INVALID_PASSWORD_RESET_TOKEN,
                    self.locale
                )
            )
        if self.user.password_reset_expiry < datetime.datetime.now():
            return self.return_error_response(
                codes.UNPROCESSABLE_ENTITY,
                TranslationManager.get_translation(
                    TranslationManager.EXPIRED_PASSWORD_RESET_TOKEN,
                    self.locale
                )
            )

    def compare_passwords(self):
        """
        Compares password and confirm password
        """
        if self.password and self.password != self.confirm_password:
            # Sending error code in case new and confirm password don't match
            return self.return_error_response(
                codes.UNPROCESSABLE_ENTITY,
                TranslationManager.get_translation(
                    TranslationManager.MISMATCH_PASSWORDS,
                    self.locale
                )
            )
        elif is_password_previously_used(self.password, self.user.id):
            # Sending error message in case of any of two previous passwords matches with the
            return self.return_error_response(
                codes.UNPROCESSABLE_ENTITY,
                TranslationManager.get_translation(
                    TranslationManager.ALREADY_USED_PASSWORD,
                    self.locale
                )
            )

    def set_new_password(self):
        """
        Sets new password, add password in user password history and deactivates existing session
        """
        # updating user object with new password and resetting password reset token and expiry
        self.user.password = security.generate_password_hash(self.password)
        self.user.password_reset_token = None
        self.user.password_reset_expiry = None
        self.user.update_record()
        # adding new password record into user password history
        insert_user_password_history = UsersPasswordHistory(
            user_id=self.user.id,
            email=self.user.email,
            password=self.user.password
        )
        insert_user_password_history.insert_record()
        # deactivating existing sessions
        Session.deactivate_sessions(self.company, self.user.et_user_id)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        data = {}
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.verify_password_token()
        if self.send_response_flag:
            return
        self.compare_passwords()
        if self.send_response_flag:
            return
        self.set_new_password()
        self.generate_final_response()
