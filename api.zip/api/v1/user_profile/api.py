"""
User Profile API
Returns user profile and user tier information
"""

from requests import codes

from api.v1.user_profile.validation import user_profile_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from models.aldar_app.user import User
from user_authentication.authentication import get_current_customer
from utils.api_utils import get_user_tier_dict
from utils.translation_manager import TranslationManager


class UserProfileAPI(BasePostResource):
    request_parser = user_profile_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='user_profile/user_profile.log',
        ),
        'name': 'user_profile'
    }
    strict_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')

    def initialize_local_veriables(self):
        """
        Initializes local veriables
        """
        self.session_data = get_current_customer()
        self.customer_id = self.session_data.get('aldar_user_id', 0)
        self.user_tier = {}
        self.user_profile = {}

    def set_user_profile(self):
        """
        Sets user profile
        """
        self.user = User.get_active_by_id(self.customer_id)
        self.user_profile = self.user.json()

    def set_user_tier(self):
        """
        Sets user tier
        """
        self.user_tier = get_user_tier_dict(self.user.lms_membership_id)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        data = {
            'user_tier': self.user_tier,
            'user_profile': self.user_profile
        }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables()
        self.set_user_profile()
        self.set_user_tier()
        self.generate_final_response()
