"""
Home API utils
"""
from flask import g

from common.constants import CATEGORIES_WITHOUT_CHILDREN
from models.aldar_app.category import Category

cache = g.cache


@cache.memoize(timeout=1800)
def get_categories_section_cached():
    categories = Category.get_all()
    category_items = []
    for category in categories:
        category_items.append({
            "id": category.id,
            "title": category.name,
            "image_url": category.image,
            "deeplink": category.deep_link,
            "api_name": category.api_name,
            "has_subcategories": False if category.name.lower() in CATEGORIES_WITHOUT_CHILDREN else True
        })
    return category_items
