"""
Home API
"""
from datetime import datetime
from random import randint

from requests import codes
from phpserialize import dumps as php_json_dumps

from api.v1.home.utils import get_categories_section_cached
from api.v1.home.validation import home_api_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from common.constants import ADR, TIERS_LINK, USER_GROUP_CHANGE_TEMPLATES
from models.aldar_app.clo_transactions import CloTransaction
from models.aldar_app.user import User
from models.consolidation.ent_send_email import EntSendEmail
from models.entertainer_web.session import Session
from models.entertainer_web.wl_user_group import WlUserGroup
from models.entertainer_web.wlvalidation import Wlvalidation
from user_authentication.authentication import get_current_customer
from utils.api_utils import get_home_screen_conf, get_home_screen_tiles
from utils.lms_manager import lms_manager


class HomeAPI(BasePostResource):
    request_parser = home_api_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='home_api_api.log',
        ),
        'name': 'home_api'
    }
    required_token = False

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.location_id = self.request_args.get('location_id')
        self.currency = self.request_args.get('currency')
        self.locale = self.request_args.get('language')

    def initialize_class_attributes(self):
        """
        Initializes class attributes
        """
        self.customer = get_current_customer()
        self.company = self.customer['company']
        self.customer_id = self.customer.get('user_id')
        self.aldar_user_id = self.customer.get('aldar_user_id', 0)
        self.user_group = 0
        self.sections = []
        self.pending_transaction_deeplink = ""

    def get_lms_points(self):
        """
        Gets LMS points against user
        """
        if self.customer.get('aldar_user_id') and self.customer.get('lms_member_id'):
            points_section = {
                "current_balance": "0",
                "current_tier": "Bronze Tier",
                "current_tier_name": "Bronze",
                "total_earned": "0",
                "total_spent": "0"
            }
            try:
                self.lms_user = lms_manager.get_lms_user_profile(self.customer['lms_member_id']) or {}
                points_section = {
                    "current_balance": "{:.2f}".format(self.lms_user.get('total_available_points', 0)),
                    "current_tier": "{} Tier".format(self.lms_user.get('member_tier', 'BRONZE').title()),
                    "current_tier_name": self.lms_user.get('member_tier', 'BRONZE').title(),
                    # "total_earned": "{:.2f}".format(self.lms_user.get('used_points', 0) +
                    #                                 self.lms_user.get('total_available_points', 0)),
                    "total_earned": "{:.2f}".format(self.lms_user.get('lifetime_total_points', 0)),
                    "total_spent": "{:.2f}".format(self.lms_user.get('used_points', 0))
                }
            except Exception as r_e:
                self.logger.exception("Error occurred while getting LMS profile: {}".format(r_e))
            self.sections.append(
                {
                    "section_identifier": "reward_balance",
                    "balance_detail": points_section
                }
            )

    def update_user_groups_by_tier(self):
        """
        - checks if user tier assigned user_group found in db. Otherwise bind it.
        - deactivates previous active user group
        """
        if self.customer_id:
            current_user_group = WlUserGroup.get_by_name(self.lms_user.get('member_tier', 'BRONZE').title(),
                                                         self.company)
            self.user_group = current_user_group.user_group
            user_groups = Wlvalidation.get_user_groups(self.company, self.customer_id)
            if current_user_group.user_group not in user_groups:
                # Changing lms_tier field in db
                if self.lms_user.get('member_tier'):
                    User.update_tier(self.lms_user.get('member_tier'), self.aldar_user_id)
                template_pickup_key = 'upgrade'
                if user_groups and max(user_groups) > current_user_group.user_group:
                    template_pickup_key = 'downgrade'
                template = USER_GROUP_CHANGE_TEMPLATES.get(current_user_group.user_group)
                if template and template.get(template_pickup_key):
                    try:
                        self.email_data_optional = {'{FIRST_NAME}': ''}
                        self.email_data = {}
                        ent_send_email = EntSendEmail(
                            email_to=self.customer.get('email'),
                            email_template_type_id=template.get(template_pickup_key),
                            email_template_data=php_json_dumps(self.email_data).decode(errors="ignore"),
                            optional_data=php_json_dumps(self.email_data_optional).decode(errors="ignore"),
                            language=self.locale,
                            priority=EntSendEmail.PRIORITY_HIGH
                        )
                        ent_send_email.insert_record()
                    except Exception as e:
                        self.logger.exception('Unable to send Tier Email: {}'.format(e))
                        pass
                bind_group = Wlvalidation(
                    wl_company=self.company,
                    wl_key="{}{}".format(self.company, randint(100000, 999999)),
                    email=self.lms_user['email'],
                    customer_id=self.customer['user_id'],
                    isused=1,
                    existing=1,
                    active=1,
                    user_group=current_user_group.user_group,
                    activation_date=datetime.now()
                )
                old_tiers = TIERS_LINK.get(self.lms_user.get('member_tier').lower())
                old_user_groups = WlUserGroup.get_by_name(old_tiers, self.company) or []
                old_user_groups = [old_user_group.user_group for old_user_group in old_user_groups]
                if old_user_groups:
                    Wlvalidation.deactivate_user_group(old_user_groups, self.customer_id)
                bind_group.insert_record()
                # refresh session token
                Session.update_all_sessions_for_customer(self.customer_id, '', ADR)

    def set_card_section(self):
        """
        Sets link a card section if not linked already
        """
        if self.customer.get('aldar_user_id'):
            self.sections.append(
                {
                    "section_identifier": "link_card",
                    "description": "Start earning points every time you pay with your linked cards while shopping across your favorite brands.", # noqa
                    "title": "Link your payment card",
                    "deeplink": "adrentertainer://linkcard"
                }
            )

    def get_categories(self):
        """
        Gets categories
        """
        category_items = get_categories_section_cached()
        category_section = {
            "section_identifier": 'categories',
            "title": 'Earn and Spend Darna Points',
            'section_items': category_items
        }
        self.sections.append(category_section)

    def get_dynamic_sections(self):
        """
        Sets dynamic sections from db
        """
        sections = get_home_screen_conf(self.location_id, self.user_group, self.company, self.locale)
        section_ids, tiles_hash = [], {}
        for section in sections:
            section_ids.append(section.section_identifier)
        tiles = get_home_screen_tiles(
            self.locale,
            self.location_id,
            ADR,
            self.user_group,
        )
        for tile in tiles:
            tile_dict = {
                "id": tile.id,
                "title": tile.title,
                "image_url": tile.image_url,
                "deeplink": tile.deep_link,
                "is_external_link": tile.is_external_link
            }
            if tiles_hash.get(tile.section_identifier):
                tiles_hash[tile.section_identifier].append(tile_dict)
            else:
                tiles_hash[tile.section_identifier] = [tile_dict]

        for section in sections:
            self.sections.append(
                {
                    "section_identifier": section.section_identifier,
                    "title": section.title,
                    "section_items": tiles_hash.get(section.section_identifier, []),
                }
            )

    def get_pending_transaction(self):
        if self.aldar_user_id:
            transaction = CloTransaction.get_pending_by_user_id(self.aldar_user_id)
            if transaction:
                self.pending_transaction_deeplink = 'adrentertainer://clotransaction?trans_id={}'.format(transaction.id)

    def generate_final_response(self):
        self.response = self.generate_response_dict(
            data={
                'sections': self.sections,
                'pending_transaction_deeplink': self.pending_transaction_deeplink
            }
        )
        self.send_response_flag = True
        self.status_code = codes.OK

    def process_request(self, *args, **kwargs):
        self.initialize_class_attributes()
        self.get_lms_points()
        self.update_user_groups_by_tier()
        self.set_card_section()
        # self.get_categories()
        self.get_dynamic_sections()
        self.get_pending_transaction()
        self.generate_final_response()
