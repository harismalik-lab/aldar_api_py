"""
Home API params validator
"""

from flask_restful import reqparse

from common.constants import EN, USD
from utils.custom_request_parsers import currency, language

home_api_parser = reqparse.RequestParser(bundle_errors=True)

home_api_parser.add_argument(
    name="location_id",
    type=int,
    required=True,
    location='json'
)
home_api_parser.add_argument(
    name="currency",
    type=currency,
    default=USD,
    location='args'
)
home_api_parser.add_argument(
    name="language",
    required=False,
    default=EN,
    type=language,
    location='args'
)
