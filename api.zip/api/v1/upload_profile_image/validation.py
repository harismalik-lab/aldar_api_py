"""
Profile image API Validation
"""
import werkzeug
from flask_restful import reqparse

upload_image_parser = reqparse.RequestParser(bundle_errors=True)

upload_image_parser.add_argument(
    'profile_image',
    type=werkzeug.datastructures.FileStorage,
    location='files'
)
