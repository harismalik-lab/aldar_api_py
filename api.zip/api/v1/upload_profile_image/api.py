"""
Upload Profile Image API
    - get user data from session
    - get user profile
        - if not found return error response
    - Upload profile image to S3 bucket
        - get image_name by concatenating random str
        - upload to s3 bucket
        - get image url from success response
    - update `user_profile.image_url` in `user_profile` obj
    - return final response

"""
from requests import codes

from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from api.v1.upload_profile_image.validation import upload_image_parser
from common.constants import USER_INACTIVE
from common.base_resource import BasePostResource
from models.aldar_app.user import User
from user_authentication.authentication import get_current_customer
from utils.api_utils import generate_random_string
from utils.aws_manager import aws_manager
from utils.translation_manager import TranslationManager


class UploadProfileImageApi(BasePostResource):
    """
    @api {post} /v1/upload/profile/image POST | Upload user's profile image.

    @apiName UploadProfileImageApi
    @apiGroup AuthService

    @apiParam {Files}             [profile_image]                   user profile image
    """
    request_parser = upload_image_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='auth_service/upload_profile_image_api.log',
        ),
        'name': 'upload_profile_image_api'
    }
    required_token = True
    strict_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.profile_image = self.request_args.get('profile_image')

    def initialize_class_attributes(self):
        """
        Initializes class attributes
        """
        self.session_data = get_current_customer()
        self.user_id = self.session_data.get('aldar_user_id', 0)
        self.profile_image_name = ''
        self.user_profile = None
        self.locale= 'en'

    def get_user_profile(self):
        """
        - get `user_profile` obj
            - if not found return error response
        """
        self.user_profile = User.get_active_by_id(self.user_id)
        if not self.user_profile:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.USER_INACTIVE,
                    self.locale
                ),
                custom_code=USER_INACTIVE
            )
            return self.send_response(self.response, self.status_code)

    def set_profile_image(self):
        """
        Upload user profile image. If upload successful set `self.profile_image_name` as image url.
        """
        self.response_message = self.upload_profile_image()
        if self.response_message.get("code", 0) == aws_manager.RESPONSE_CODE_BAD_REQUEST:
            self.send_response_flag = True
            self.status_code = 400
            self.response = {
                "message": self.response_message.get("message", ''),
                "data": {'status': False},
                "success": False,
                "code": 400
            }
            return self.send_response(self.response, self.status_code)
        self.profile_image_url = self.response_message.get("url", '')

    def upload_profile_image(self):
        """
        Upload user profile image
        """
        response_message = {}
        if self.profile_image and self.user_profile:
            response_message['code'] = aws_manager.RESPONSE_CODE_BAD_REQUEST
            try:
                ext = self.profile_image.filename.split(".")
                image_name = "{user_id}_{md5}.{digit}".format(
                    user_id=self.user_id,
                    md5=generate_random_string(),
                    digit=ext[-1]
                )
                response_message = aws_manager._put_object(
                    file=self.profile_image,
                    image_name=image_name,
                )
            except:
                pass
            return response_message

    def update_user_profile(self):
        """
        - if not `profile_image_url`
            - return error response
        - update `user_profile.image_url`
        """
        if self.profile_image_url:
            self.user_profile.profile_image = self.profile_image_url
            self.user_profile.update_record()

        else:
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.send_response_flag = True
            self.response = {
                "message": self.response_message.get('message', ''),
                "success": False,
                "data": []
            }

            return self.send_response(self.response, self.status_code)

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        data = dict(image_url=self.profile_image_url)

        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialize_class_attributes()
        self.get_user_profile()
        if self.send_response_flag:
            return
        self.set_profile_image()
        if self.send_response_flag:
            return
        self.update_user_profile()
        if self.send_response_flag:
            return
        self.set_final_response()
