"""
Change Password API validation
"""

from flask_restful import reqparse
from flask_restful.inputs import regex

from common.constants import EN, ADR
from utils.custom_request_parsers import language

change_password_parser = reqparse.RequestParser(bundle_errors=True)

change_password_parser.add_argument(
    'language',
    type=language,
    default=EN,
    location='json'
)
change_password_parser.add_argument(
    'company',
    type=regex(r'[a-zA-Z-_]{2,9}'),
    default=ADR,
    location='json'
)
change_password_parser.add_argument(
    'password',
    type=str,
    required=True,
    location='json'
)
change_password_parser.add_argument(
    'confirm_password',
    type=str,
    required=True,
    location='json'
)
