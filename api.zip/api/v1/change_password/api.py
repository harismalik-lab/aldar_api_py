"""
Change Password API
"""
import datetime

from requests import codes

from api.v1.change_password.validation import change_password_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from models.aldar_app.user import User
from models.aldar_app.users_password_history import UsersPasswordHistory
from user_authentication.authentication import get_current_customer
from utils.api_utils import is_password_previously_used
from utils.security import security
from models.entertainer_web.session import Session
from utils.translation_manager import TranslationManager


class ChangePasswordAPI(BasePostResource):
    strict_token = True
    request_parser = change_password_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='change_password/change_password.log',
        ),
        'name': 'change_password'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.password = self.request_args.get('password')
        self.confirm_password = self.request_args.get('confirm_password')
        self.locale = self.request_args.get('language')
        self.company = self.request_args.get('company')

    def initialize_class_attributes(self):
        """
        Initializes class attributes
        """
        self.session_data = get_current_customer()
        self.aldar_user_id = self.session_data.get('aldar_user_id')
        self.user_id = self.session_data['customer_id']

    def return_error_response(self, status_code, message):
        """
        Generates error response and returns
        :param int status_code:
        :param str message:
        """
        self.status_code = status_code
        self.send_response_flag = True
        self.response = {
            "message": message,
            "code": status_code,
            "success": False
        }
        return self.send_response(self.response, self.status_code)

    def compare_passwords(self):
        """
        Compares password and confirm password
        """
        if self.aldar_user_id:
            self.user = User.get_active_by_id(self.aldar_user_id)
        if self.password and self.password != self.confirm_password:
            # Sending error code in case new and confirm password don't match.
            return self.return_error_response(
                codes.UNPROCESSABLE_ENTITY,
                TranslationManager.get_translation(
                    TranslationManager.MISMATCH_PASSWORDS,
                    self.locale
                )
            )
        elif is_password_previously_used(self.password, self.aldar_user_id):
            # Sending error message in case of any of two previous passwords matches with the
            return self.return_error_response(
                codes.UNPROCESSABLE_ENTITY,
                TranslationManager.get_translation(
                    TranslationManager.ALREADY_USED_PASSWORD,
                    self.locale
                )
            )

    def set_new_password(self):
        """
        Sets new password in user and password history table
        """
        self.user.password = security.generate_password_hash(self.password)
        insert_user_password_history = UsersPasswordHistory(
            user_id=self.aldar_user_id,
            email=self.user.email,
            password=self.user.password,
            created_at=datetime.datetime.now()
        )
        insert_user_password_history.insert_record()
        self.user.update_record()
        Session.deactivate_other_than_this_auth_token(self.session_data['session_token'], self.user_id)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        data = {}
        self.response = self.generate_response_dict(
            message='You have successfully reset your password.',
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_class_attributes()
        self.compare_passwords()
        if self.send_response_flag:
            return
        self.set_new_password()
        self.generate_final_response()
