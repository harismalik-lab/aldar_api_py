"""
Points History API validation
"""

from flask_restful import reqparse

from common.constants import EN
from utils.custom_request_parsers import language

points_history_parser = reqparse.RequestParser(bundle_errors=True)

points_history_parser.add_argument(
    'language',
    type=language,
    default=EN,
    location='json'
)
