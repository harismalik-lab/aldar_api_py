"""
Points History Util methods
"""
import datetime

from common.api_utils import get_iso_formatted_date
from common.constants import LMS_DATE_FORMAT, EARN_TRANSACTIONS_KEY, BURN_TRANSACTIONS_KEY
from models.entertainer_web.outlet import Outlet


def get_sections_data(lms_transactions):
    """
    Return sections data according to transaction type data points and also calculates total points
    :param dict lms_transactions:
    :return dict:
    """
    transaction_types_keys = (EARN_TRANSACTIONS_KEY, BURN_TRANSACTIONS_KEY)
    section_data = {
        'section_earn_list': [], 'section_burn_list': [], 'total_earn_points': 0.0, 'total_burn_points': 0.0
    }
    transactions_list = []
    concept_ids = []
    for transaction_type in transaction_types_keys:
        lms_transaction_list = lms_transactions.get(transaction_type, [])
        for lms_transaction in lms_transaction_list:

            current_transaction = {}
            if transaction_type == EARN_TRANSACTIONS_KEY:
                transaction_id = lms_transaction['earn_transaction_id']
                created_date_str = lms_transaction['creation_date']
                current_transaction['points'] = lms_transaction['earned_points']
                is_pending_points = False  # TODO dependent on more lms data
                current_transaction['is_pending_points'] = is_pending_points
                if is_pending_points:
                    current_transaction['clearance_date'] = get_iso_formatted_date(datetime.datetime.strptime(
                        '2020-06-21 21:56:30', LMS_DATE_FORMAT)
                    )  # TODO dependent on more lms data

            else:
                transaction_id = lms_transaction['redemption_reference_code']
                created_date_str = lms_transaction['date_created']
                current_transaction['points'] = lms_transaction['points']

            current_transaction['date'] = get_iso_formatted_date(datetime.datetime.strptime(
                created_date_str, LMS_DATE_FORMAT)
            )
            current_transaction['transaction_id'] = transaction_id
            current_transaction['concept_id'] = lms_transaction['concept_id']
            current_transaction['transaction_type'] = transaction_type
            transactions_list.append(current_transaction)
            concept_ids.append(lms_transaction['concept_id'])

    # Getting all outlets information by list of concept_ids
    outlets_info = Outlet.get_info_by_concept_ids(list(set(concept_ids)))
    # Preparing outlets data by concept id in dictionary
    outlets_by_concept_ids = {}
    for outlet_info in outlets_info:
        outlet_info_dict = outlet_info._asdict()
        outlets_by_concept_ids[outlet_info_dict['concept_id']] = outlet_info_dict

    for transaction_dict in transactions_list:
        outlet_info = outlets_by_concept_ids.get(transaction_dict['concept_id'], {})
        if outlet_info:
            # Adding outlet info to the transaction on base of concept id
            transaction_dict = {**transaction_dict, **outlet_info}
            # Adding updated transaction object to transaction type list
            if transaction_dict['transaction_type'] == EARN_TRANSACTIONS_KEY:
                section_data['total_earn_points'] += transaction_dict['points']
                section_data['section_earn_list'].append(transaction_dict)
            else:
                section_data['total_burn_points'] += transaction_dict['points']
                section_data['section_burn_list'].append(transaction_dict)

    return section_data
