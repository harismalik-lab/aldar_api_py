"""
Points History API
Returns total earned and burned points along with transactions
"""

from requests import codes

from api.v1.points_history.utils import get_sections_data
from api.v1.points_history.validation import points_history_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from user_authentication.authentication import get_current_customer
from utils.lms_manager import lms_manager
from utils.translation_manager import TranslationManager


class PointsHistoryAPI(BasePostResource):
    request_parser = points_history_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='points_history/points_history.log',
        ),
        'name': 'points_history'
    }
    strict_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')

    def initialize_local_veriables(self):
        """
        Initializes local veriables
        """
        self.session_data = get_current_customer()
        self.customer_id = self.session_data.get('aldar_user_id', 0)
        self.lms_membership_id = self.session_data.get('lms_member_id')
        self.lms_transactions = {}
        self.total_earned = 0
        self.total_spent = 0
        self.earned_section_list = []
        self.spent_section_list = []


    def get_lms_transactions(self):
        """
        Gets lms transactions
        """
        self.lms_transactions = lms_manager.get_lms_user_transactions(self.lms_membership_id)

    def set_earned_and_spent_sections_data(self):
        """
        Set earned and burn sections data dictionary
        """
        self.sections_data_dict = get_sections_data(self.lms_transactions)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        data = {
            'total_earned': self.sections_data_dict['total_earn_points'],
            'total_spent': self.sections_data_dict['total_burn_points'],
            'earned_section': self.sections_data_dict['section_earn_list'],
            'spent_section': self.sections_data_dict['section_burn_list']
        }
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables()
        self.get_lms_transactions()
        self.set_earned_and_spent_sections_data()
        self.generate_final_response()
