"""
Redemption History API
"""
from flask import current_app
from requests import codes

from api.v1.redemption_history.validation import redemption_history_parser
from app_configurations.settings import ALDAR_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from common.constants import AED, ADR
from user_authentication.authentication import get_current_customer
from utils.communicator import communicator
from utils.translation_manager import TranslationManager


class RedemptionHistoryAPI(BasePostResource):
    request_parser = redemption_history_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ALDAR_SERVICES_LOG_PATH,
            file_path='redemption_history/redemption_history.log',
        ),
        'name': 'redemption_history'
    }
    required_token = True
    strict_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')

    def initialize_local_veriables(self):
        """
        Initializes local veriables
        """
        self.session_data = get_current_customer()

    def get_redemption_history(self):
        """
        Gets redemption History
        """
        session_token = self.session_data['session_token']
        response = communicator.communicate(
            current_app.config['ET_REDEMPTION_HISTORY_URL'],
            'POST',
            payload={
                'session_token': session_token,
                'company': ADR,
                'currency': AED
            },
            headers={
                'authorizationToken': current_app.config['ET_AWS_AUTH_TOKEN']
            }
        )
        self.redemption_history = response.json()['data']

    def set_total_monthly_savings(self):
        """
        Sets total monthly savings
        """
        month_wise_redemptions = self.redemption_history.get('month_wise_redemmptions')
        for month_wise_redemption in month_wise_redemptions:
            redemptions = month_wise_redemption.get('redemptions')
            monthly_total_savings = 0.0
            for redemption in redemptions:
                saving = redemption.get('savings', 0.0)
                monthly_total_savings += saving
            month_wise_redemption['monthly_total_savings'] = monthly_total_savings

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        data = self.redemption_history
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.SUCCESS,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Processes the request
        """
        self.initialize_local_veriables()
        self.get_redemption_history()
        self.set_total_monthly_savings()
        self.generate_final_response()
